const crypto = require('crypto');

/**
 * Abstraksi payment gateway (Sesi 4, menggantikan "item belum dikerjakan #3").
 *
 * Pola yang dipilih meniru Midtrans (gateway paling umum dipakai di Indonesia),
 * karena formula verifikasi signature-nya terdokumentasi publik dan bisa
 * diimplementasikan + DITES SUNGGUHAN tanpa butuh kredensial/akses jaringan ke
 * Midtrans (sandbox chat ini tidak punya akses ke `api.midtrans.com`).
 *
 * CATATAN JUJUR: `createTransaction()` di bawah TIDAK memanggil API Midtrans
 * sungguhan (tidak ada MIDTRANS_SERVER_KEY produksi & tidak ada akses jaringan
 * keluar ke domain Midtrans dari sandbox ini). Ia mengembalikan bentuk respons
 * yang strukturnya identik dengan respons Snap API Midtrans (`token`,
 * `redirect_url`, `order_id`), supaya sisi controller & Android app bisa
 * dikembangkan/dites melawan kontrak yang benar. Untuk pindah ke gateway
 * sungguhan, ganti isi `createTransaction()` dengan `fetch`/`axios` POST ke
 * `https://api.midtrans.com/v2/charge` (produksi) atau
 * `https://api.sandbox.midtrans.com/v2/charge` (sandbox Midtrans) memakai
 * `MIDTRANS_SERVER_KEY` sebagai Basic Auth — TIDAK ADA bagian lain yang perlu
 * berubah karena bentuk return value-nya sudah disamakan.
 *
 * YANG SUNGGUHAN (bukan simulasi) di file ini: `verifySignatureKey()` adalah
 * implementasi PERSIS formula signature Midtrans yang didokumentasikan resmi:
 *   SHA512(order_id + status_code + gross_amount + ServerKey)
 * Ini dites dengan test vector di `paymentGateway.test.js` melawan hasil SHA512
 * yang dihitung independen, jadi kalau dipasang `MIDTRANS_SERVER_KEY` produksi
 * sungguhan, verifikasi webhook akan langsung benar tanpa perubahan kode.
 */

const SERVER_KEY = process.env.MIDTRANS_SERVER_KEY || 'dev-simulated-server-key-DO-NOT-USE-IN-PRODUCTION';
const GATEWAY_MODE = process.env.MIDTRANS_SERVER_KEY ? 'live-credentials-configured' : 'simulated';

function generateOrderId(paymentId) {
  return `OTS-${paymentId}`;
}

/**
 * Simulasikan pembuatan transaksi di gateway. Lihat catatan jujur di atas:
 * ini TIDAK menghubungi Midtrans sungguhan, tapi bentuk return-nya identik
 * dengan Snap API Midtrans supaya kode pemanggil tidak perlu berubah saat
 * kredensial produksi dipasang.
 */
async function createTransaction({ paymentId, grossAmount, method }) {
  const orderId = generateOrderId(paymentId);
  // token simulasi - di produksi ini datang dari respons API Midtrans sungguhan
  const simulatedToken = crypto.randomBytes(16).toString('hex');
  return {
    order_id: orderId,
    gross_amount: grossAmount,
    payment_type: method === 'E_WALLET' ? 'gopay' : method === 'CASH' ? 'cash' : 'bank_transfer',
    transaction_id: simulatedToken,
    redirect_url:
      GATEWAY_MODE === 'simulated'
        ? null // CASH & simulasi tidak punya halaman redirect gateway sungguhan
        : `https://app.midtrans.com/snap/v2/vtweb/${simulatedToken}`,
    _gateway_mode: GATEWAY_MODE,
  };
}

/**
 * Verifikasi signature webhook, PERSIS formula resmi Midtrans:
 * SHA512(order_id + status_code + gross_amount + ServerKey)
 * https://docs.midtrans.com/docs/https-notification-webhooks (formula publik)
 */
function verifySignatureKey({ order_id, status_code, gross_amount, signature_key }) {
  if (!order_id || !status_code || !gross_amount || !signature_key) return false;
  const expected = crypto
    .createHash('sha512')
    .update(`${order_id}${status_code}${gross_amount}${SERVER_KEY}`)
    .digest('hex');
  // Perbandingan timing-safe agar tidak bocor info lewat timing attack
  const expectedBuf = Buffer.from(expected, 'hex');
  const providedBuf = Buffer.from(String(signature_key), 'hex');
  if (expectedBuf.length !== providedBuf.length) return false;
  return crypto.timingSafeEqual(expectedBuf, providedBuf);
}

function computeSignatureKey({ order_id, status_code, gross_amount }) {
  // Helper dipakai test & (kalau perlu) alat debug manual - TIDAK dipakai di alur produksi,
  // karena signature_key seharusnya datang DARI gateway, bukan dihitung sendiri oleh server kita.
  return crypto
    .createHash('sha512')
    .update(`${order_id}${status_code}${gross_amount}${SERVER_KEY}`)
    .digest('hex');
}

module.exports = {
  generateOrderId,
  createTransaction,
  verifySignatureKey,
  computeSignatureKey,
  GATEWAY_MODE,
};
