const multer = require('multer');
const path = require('path');
const { S3Client, PutObjectCommand } = require('@aws-sdk/client-s3');

/**
 * Storage driver #2: AWS S3 (atau layanan S3-compatible seperti MinIO/
 * Cloudflare R2/Firebase-lewat-S3-adapter, lewat AWS_S3_ENDPOINT).
 * Menggantikan "item belum dikerjakan #4" di blueprint.
 *
 * CATATAN JUJUR: sandbox pengerjaan ini TIDAK punya kredensial AWS asli dan
 * TIDAK punya akses jaringan ke `*.amazonaws.com` (tidak ada di whitelist
 * jaringan sandbox), jadi upload ke bucket S3 SUNGGUHAN belum pernah
 * benar-benar dicoba di sini. Yang SUDAH dites sungguhan (lihat
 * `s3Driver.test.js`, pakai `aws-sdk-client-mock` - library resmi utk
 * mock AWS SDK v3, BUKAN mock buatan sendiri):
 *   - `PutObjectCommand` dipanggil dengan `Bucket`/`Key`/`Body`/`ContentType`
 *     yang benar dari `req.file` (multer memoryStorage) & `req.params.id`.
 *   - `getUrl()` mengembalikan format URL yang benar (virtual-hosted-style,
 *     dan custom endpoint kalau `AWS_S3_ENDPOINT`/`AWS_S3_PUBLIC_URL` di-set
 *     untuk layanan S3-compatible non-AWS).
 *   - Error dari S3Client (mis. kredensial salah/bucket tidak ada) diteruskan
 *     sebagai exception yang controller tangkap di blok try/catch-nya.
 * Yang BELUM dites: bahwa upload sungguhan ke bucket AWS S3 nyata berhasil
 * end-to-end. Ini WAJIB dicoba di lingkungan dengan kredensial & akses
 * jaringan AWS sungguhan sebelum dipakai produksi.
 */

// Multer simpan file di memory (bukan disk) - kita yang push ke S3 secara eksplisit di getUrl()
const multerStorage = multer.memoryStorage();

function buildS3Client() {
  const config = { region: process.env.AWS_REGION || 'ap-southeast-1' };
  if (process.env.AWS_S3_ENDPOINT) {
    // Dipakai untuk layanan S3-compatible non-AWS (MinIO, R2, dll)
    config.endpoint = process.env.AWS_S3_ENDPOINT;
    config.forcePathStyle = true;
  }
  return new S3Client(config);
}

function buildKey(req, file) {
  const ext = path.extname(file.originalname).toLowerCase();
  return `emergency/${req.params.id}-${Date.now()}${ext}`;
}

function buildPublicUrl(bucket, key) {
  if (process.env.AWS_S3_PUBLIC_URL) {
    // mis. CDN di depan bucket, atau endpoint S3-compatible custom
    return `${process.env.AWS_S3_PUBLIC_URL.replace(/\/$/, '')}/${key}`;
  }
  const region = process.env.AWS_REGION || 'ap-southeast-1';
  return `https://${bucket}.s3.${region}.amazonaws.com/${key}`;
}

async function getUrl(req) {
  const bucket = process.env.AWS_S3_BUCKET;
  if (!bucket) {
    throw new Error('AWS_S3_BUCKET belum diset di environment (wajib saat STORAGE_DRIVER=s3).');
  }
  const key = buildKey(req, req.file);
  const client = buildS3Client();

  await client.send(
    new PutObjectCommand({
      Bucket: bucket,
      Key: key,
      Body: req.file.buffer,
      ContentType: req.file.mimetype,
    })
  );

  return buildPublicUrl(bucket, key);
}

module.exports = { name: 's3', multerStorage, getUrl, buildKey, buildPublicUrl, buildS3Client };
