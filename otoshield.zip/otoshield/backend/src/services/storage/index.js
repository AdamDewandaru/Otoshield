/**
 * Pemilih storage driver - default 'local' (perilaku lama, tidak berubah
 * bagi siapa pun yang tidak set env var baru ini), atau 's3' kalau
 * `STORAGE_DRIVER=s3` di-set (lihat s3Driver.js untuk catatan jujur soal
 * apa yang sudah/belum dites).
 */
function getDriver() {
  const driverName = process.env.STORAGE_DRIVER || 'local';
  if (driverName === 's3') {
    return require('./s3Driver');
  }
  return require('./localDriver');
}

module.exports = { getDriver };
