const multer = require('multer');
const path = require('path');
const fs = require('fs');

/**
 * Storage driver #1: disk lokal server. Ini perilaku yang SUDAH ADA sejak
 * Sesi 2, sekarang dibungkus di interface seragam `{ multerStorage, getUrl }`
 * supaya bisa dipertukarkan dengan driver S3 lewat `STORAGE_DRIVER` env var
 * tanpa controller/route perlu tahu driver mana yang dipakai.
 */

const uploadDir = path.join(__dirname, '..', '..', '..', 'uploads', 'emergency');
fs.mkdirSync(uploadDir, { recursive: true });

const multerStorage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, uploadDir),
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase();
    const unique = `${req.params.id}-${Date.now()}${ext}`;
    cb(null, unique);
  },
});

// Dengan diskStorage, multer SUDAH menulis file ke disk sebelum controller
// jalan - getUrl tinggal membentuk URL relatif dari nama file yang dipakai.
async function getUrl(req) {
  return `/uploads/emergency/${req.file.filename}`;
}

module.exports = { name: 'local', multerStorage, getUrl };
