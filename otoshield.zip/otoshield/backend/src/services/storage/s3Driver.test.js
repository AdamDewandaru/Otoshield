const { mockClient } = require('aws-sdk-client-mock');
const { S3Client, PutObjectCommand } = require('@aws-sdk/client-s3');
const s3Driver = require('./s3Driver');

// s3Driver.js membaca process.env di DALAM setiap pemanggilan fungsi (bukan
// saat require), jadi test ini aman ganti env var per-test tanpa perlu
// jest.resetModules() - resetModules justru menyebabkan S3Client yang
// di-mock berbeda instance dengan yang dipakai s3Driver internal (module
// registry berbeda), yang bikin mock tidak pernah kena (client asli dipanggil
// dan gagal karena tidak ada kredensial AWS sungguhan di sandbox ini).
const s3Mock = mockClient(S3Client);

describe('s3Driver', () => {
  beforeEach(() => {
    s3Mock.reset();
    process.env.AWS_S3_BUCKET = 'otoshield-test-bucket';
    process.env.AWS_REGION = 'ap-southeast-1';
    delete process.env.AWS_S3_ENDPOINT;
    delete process.env.AWS_S3_PUBLIC_URL;
  });

  afterEach(() => {
    delete process.env.AWS_S3_BUCKET;
    delete process.env.AWS_REGION;
    delete process.env.AWS_S3_ENDPOINT;
    delete process.env.AWS_S3_PUBLIC_URL;
  });

  function buildFakeReq(overrides = {}) {
    return {
      params: { id: 'emergency-uuid-123' },
      file: {
        originalname: 'kerusakan.jpg',
        mimetype: 'image/jpeg',
        buffer: Buffer.from('fake-image-bytes'),
        ...overrides,
      },
    };
  }

  test('memanggil PutObjectCommand dengan Bucket/Key/Body/ContentType yang benar', async () => {
    s3Mock.on(PutObjectCommand).resolves({});
    const req = buildFakeReq();

    await s3Driver.getUrl(req);

    const calls = s3Mock.commandCalls(PutObjectCommand);
    expect(calls).toHaveLength(1);
    const input = calls[0].args[0].input;
    expect(input.Bucket).toBe('otoshield-test-bucket');
    expect(input.Key).toMatch(/^emergency\/emergency-uuid-123-\d+\.jpg$/);
    expect(input.Body).toEqual(Buffer.from('fake-image-bytes'));
    expect(input.ContentType).toBe('image/jpeg');
  });

  test('mengembalikan URL virtual-hosted-style S3 standar saat tidak ada AWS_S3_PUBLIC_URL', async () => {
    s3Mock.on(PutObjectCommand).resolves({});
    const req = buildFakeReq();

    const url = await s3Driver.getUrl(req);

    expect(url).toMatch(
      /^https:\/\/otoshield-test-bucket\.s3\.ap-southeast-1\.amazonaws\.com\/emergency\/emergency-uuid-123-\d+\.jpg$/
    );
  });

  test('mengembalikan URL custom (CDN/S3-compatible) saat AWS_S3_PUBLIC_URL di-set', async () => {
    process.env.AWS_S3_PUBLIC_URL = 'https://cdn.otoshield.example.com';
    s3Mock.on(PutObjectCommand).resolves({});

    const url = await s3Driver.getUrl(buildFakeReq());

    expect(url).toMatch(/^https:\/\/cdn\.otoshield\.example\.com\/emergency\/emergency-uuid-123-\d+\.jpg$/);
  });

  test('melempar error jelas jika AWS_S3_BUCKET belum diset', async () => {
    delete process.env.AWS_S3_BUCKET;

    await expect(s3Driver.getUrl(buildFakeReq())).rejects.toThrow(/AWS_S3_BUCKET/);
  });

  test('meneruskan error dari S3Client (mis. kredensial salah/bucket tidak ada) ke pemanggil', async () => {
    s3Mock.on(PutObjectCommand).rejects(new Error('Access Denied'));
    const req = buildFakeReq();

    await expect(s3Driver.getUrl(req)).rejects.toThrow('Access Denied');
  });

  test('ekstensi file dipertahankan dengan benar untuk PNG', async () => {
    s3Mock.on(PutObjectCommand).resolves({});
    const req = buildFakeReq({ originalname: 'foto.PNG', mimetype: 'image/png' });

    const url = await s3Driver.getUrl(req);
    expect(url).toMatch(/\.png$/);
  });

  test('memakai forcePathStyle & endpoint custom saat AWS_S3_ENDPOINT di-set (mis. MinIO)', async () => {
    process.env.AWS_S3_ENDPOINT = 'http://localhost:9000';
    s3Mock.on(PutObjectCommand).resolves({});

    // Tidak error = client berhasil dibuat dengan endpoint custom & PutObjectCommand terkirim ke mock
    await expect(s3Driver.getUrl(buildFakeReq())).resolves.toBeDefined();
    expect(s3Mock.commandCalls(PutObjectCommand)).toHaveLength(1);
  });
});
