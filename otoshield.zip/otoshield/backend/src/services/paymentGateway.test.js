const crypto = require('crypto');

// SERVER_KEY dev-default dipakai module saat MIDTRANS_SERVER_KEY tidak di-set (lihat paymentGateway.js)
const DEV_SERVER_KEY = 'dev-simulated-server-key-DO-NOT-USE-IN-PRODUCTION';

// Hitung signature "independen" (tidak lewat kode yang sedang dites) sebagai test vector,
// meniru persis cara webhook Midtrans sungguhan menghitungnya di sisi mereka.
function independentSignature({ order_id, status_code, gross_amount, serverKey }) {
  return crypto
    .createHash('sha512')
    .update(`${order_id}${status_code}${gross_amount}${serverKey}`)
    .digest('hex');
}

describe('paymentGateway', () => {
  let gateway;

  beforeEach(() => {
    jest.resetModules();
    delete process.env.MIDTRANS_SERVER_KEY;
    gateway = require('./paymentGateway');
  });

  describe('verifySignatureKey', () => {
    test('menerima signature yang benar (dihitung independen dengan formula resmi Midtrans)', () => {
      const payload = { order_id: 'OTS-abc123', status_code: '200', gross_amount: '150000.00' };
      const validSignature = independentSignature({ ...payload, serverKey: DEV_SERVER_KEY });

      const result = gateway.verifySignatureKey({ ...payload, signature_key: validSignature });
      expect(result).toBe(true);
    });

    test('menolak signature yang salah/dipalsukan', () => {
      const payload = { order_id: 'OTS-abc123', status_code: '200', gross_amount: '150000.00' };
      const fakeSignature = 'a'.repeat(128); // panjang SHA512 hex benar, isinya salah

      const result = gateway.verifySignatureKey({ ...payload, signature_key: fakeSignature });
      expect(result).toBe(false);
    });

    test('menolak signature yang dihitung dengan ServerKey berbeda (mis. gateway lain/palsu)', () => {
      const payload = { order_id: 'OTS-abc123', status_code: '200', gross_amount: '150000.00' };
      const wrongKeySignature = independentSignature({ ...payload, serverKey: 'server-key-yang-salah' });

      const result = gateway.verifySignatureKey({ ...payload, signature_key: wrongKeySignature });
      expect(result).toBe(false);
    });

    test('menolak jika order_id di body beda dengan yang dipakai menghitung signature', () => {
      const validSignature = independentSignature({
        order_id: 'OTS-original',
        status_code: '200',
        gross_amount: '150000.00',
        serverKey: DEV_SERVER_KEY,
      });

      const result = gateway.verifySignatureKey({
        order_id: 'OTS-diganti-attacker',
        status_code: '200',
        gross_amount: '150000.00',
        signature_key: validSignature,
      });
      expect(result).toBe(false);
    });

    test('menolak jika gross_amount diubah (mis. attacker coba turunkan jumlah bayar)', () => {
      const validSignature = independentSignature({
        order_id: 'OTS-abc123',
        status_code: '200',
        gross_amount: '150000.00',
        serverKey: DEV_SERVER_KEY,
      });

      const result = gateway.verifySignatureKey({
        order_id: 'OTS-abc123',
        status_code: '200',
        gross_amount: '1000.00', // diubah jadi jauh lebih kecil
        signature_key: validSignature,
      });
      expect(result).toBe(false);
    });

    test('menolak jika field wajib hilang', () => {
      expect(gateway.verifySignatureKey({ order_id: 'OTS-1', status_code: '200', gross_amount: '1000' })).toBe(
        false
      );
      expect(gateway.verifySignatureKey({ status_code: '200', gross_amount: '1000', signature_key: 'x' })).toBe(
        false
      );
    });

    test('menghormati MIDTRANS_SERVER_KEY dari environment jika di-set', () => {
      jest.resetModules();
      process.env.MIDTRANS_SERVER_KEY = 'server-key-produksi-rahasia';
      const gatewayWithEnvKey = require('./paymentGateway');

      const payload = { order_id: 'OTS-xyz', status_code: '200', gross_amount: '500000.00' };
      const sigWithEnvKey = independentSignature({ ...payload, serverKey: 'server-key-produksi-rahasia' });
      const sigWithDevKey = independentSignature({ ...payload, serverKey: DEV_SERVER_KEY });

      expect(gatewayWithEnvKey.verifySignatureKey({ ...payload, signature_key: sigWithEnvKey })).toBe(true);
      expect(gatewayWithEnvKey.verifySignatureKey({ ...payload, signature_key: sigWithDevKey })).toBe(false);

      delete process.env.MIDTRANS_SERVER_KEY;
    });
  });

  describe('createTransaction', () => {
    test('menghasilkan order_id yang mengandung paymentId (agar tertelusur balik ke tabel payments)', async () => {
      const tx = await gateway.createTransaction({ paymentId: 'payment-uuid-123', grossAmount: 200000, method: 'VIRTUAL_ACCOUNT' });
      expect(tx.order_id).toBe('OTS-payment-uuid-123');
      expect(tx.gross_amount).toBe(200000);
    });

    test('mode simulasi (tanpa MIDTRANS_SERVER_KEY) tidak menghasilkan redirect_url gateway sungguhan', async () => {
      const tx = await gateway.createTransaction({ paymentId: 'p1', grossAmount: 50000, method: 'E_WALLET' });
      expect(tx._gateway_mode).toBe('simulated');
      expect(tx.redirect_url).toBeNull();
    });

    test('payment_type disesuaikan dengan method', async () => {
      const va = await gateway.createTransaction({ paymentId: 'p1', grossAmount: 1000, method: 'VIRTUAL_ACCOUNT' });
      const ew = await gateway.createTransaction({ paymentId: 'p2', grossAmount: 1000, method: 'E_WALLET' });
      const cash = await gateway.createTransaction({ paymentId: 'p3', grossAmount: 1000, method: 'CASH' });
      expect(va.payment_type).toBe('bank_transfer');
      expect(ew.payment_type).toBe('gopay');
      expect(cash.payment_type).toBe('cash');
    });
  });
});
