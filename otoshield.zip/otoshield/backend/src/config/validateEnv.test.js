const { checkEnv } = require('./validateEnv');

/**
 * Test murni untuk `checkEnv()` (fungsi pure, tidak menyentuh `process.env`
 * asli ataupun memanggil `process.exit` - lihat parameter `env` yang
 * diinjeksi di `validateEnv.js`). `validateEnvOrExit()` sendiri (yang
 * memanggil `process.exit`) sengaja TIDAK dites di sini karena akan
 * menghentikan proses Jest itu sendiri - perilakunya sudah diverifikasi
 * manual lewat `node src/server.js` dengan berbagai kombinasi env
 * (lihat catatan #memory Sesi 9 di blueprint untuk skenario yang dicoba).
 */
describe('validateEnv - checkEnv', () => {
  const validEnv = {
    NODE_ENV: 'development',
    DATABASE_URL: 'postgres://user:pass@localhost:5432/db',
    JWT_SECRET: 'a-reasonably-long-random-secret-value',
    ADMIN_API_KEY: 'another-reasonably-long-random-key',
  };

  test('env lengkap & valid di development -> tidak ada error, tidak ada warning', () => {
    const { errors, warnings } = checkEnv(validEnv);
    expect(errors).toEqual([]);
    expect(warnings).toEqual([]);
  });

  test('DATABASE_URL kosong -> error', () => {
    const { errors } = checkEnv({ ...validEnv, DATABASE_URL: '' });
    expect(errors.some((e) => e.startsWith('DATABASE_URL'))).toBe(true);
  });

  test('JWT_SECRET tidak ada sama sekali -> error', () => {
    const env = { ...validEnv };
    delete env.JWT_SECRET;
    const { errors } = checkEnv(env);
    expect(errors.some((e) => e.startsWith('JWT_SECRET'))).toBe(true);
  });

  test('ADMIN_API_KEY kosong -> error', () => {
    const { errors } = checkEnv({ ...validEnv, ADMIN_API_KEY: '   ' });
    expect(errors.some((e) => e.startsWith('ADMIN_API_KEY'))).toBe(true);
  });

  test('JWT_SECRET masih placeholder .env.example di production -> error (blocker)', () => {
    const { errors } = checkEnv({
      ...validEnv,
      NODE_ENV: 'production',
      JWT_SECRET: 'change_this_to_a_long_random_secret',
    });
    expect(errors.some((e) => e.includes('masih nilai contoh'))).toBe(true);
  });

  test('JWT_SECRET masih placeholder .env.example di development -> cuma warning, bukan error', () => {
    const { errors, warnings } = checkEnv({
      ...validEnv,
      NODE_ENV: 'development',
      JWT_SECRET: 'change_this_to_a_long_random_secret',
    });
    expect(errors).toEqual([]);
    expect(warnings.some((w) => w.includes('masih nilai contoh'))).toBe(true);
  });

  test('ADMIN_API_KEY masih placeholder .env.example di production -> error (blocker)', () => {
    const { errors } = checkEnv({
      ...validEnv,
      NODE_ENV: 'production',
      ADMIN_API_KEY: 'change_this_to_a_long_random_admin_key',
    });
    expect(errors.some((e) => e.includes('masih nilai contoh'))).toBe(true);
  });

  test('JWT_SECRET pendek (<16 karakter) di production -> error', () => {
    const { errors } = checkEnv({ ...validEnv, NODE_ENV: 'production', JWT_SECRET: 'pendek123' });
    expect(errors.some((e) => e.includes('minimal 16 karakter'))).toBe(true);
  });

  test('JWT_SECRET pendek (<16 karakter) di development -> cuma warning', () => {
    const { errors, warnings } = checkEnv({ ...validEnv, NODE_ENV: 'development', JWT_SECRET: 'pendek123' });
    expect(errors).toEqual([]);
    expect(warnings.some((w) => w.includes('minimal 16 karakter'))).toBe(true);
  });

  test('CORS_ORIGIN kosong/"*" di production -> warning (bukan blocker)', () => {
    const { errors, warnings } = checkEnv({ ...validEnv, NODE_ENV: 'production', CORS_ORIGIN: '*' });
    expect(errors).toEqual([]);
    expect(warnings.some((w) => w.includes('CORS_ORIGIN'))).toBe(true);
  });

  test('CORS_ORIGIN diisi domain spesifik di production -> tidak ada warning CORS', () => {
    const { warnings } = checkEnv({
      ...validEnv,
      NODE_ENV: 'production',
      CORS_ORIGIN: 'https://otoshield.app',
    });
    expect(warnings.some((w) => w.includes('CORS_ORIGIN'))).toBe(false);
  });

  test('semua wajib kosong sekaligus -> error untuk masing-masing, bukan cuma yang pertama', () => {
    const { errors } = checkEnv({ NODE_ENV: 'development' });
    expect(errors).toHaveLength(3);
  });
});
