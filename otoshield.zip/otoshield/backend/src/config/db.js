const { Pool } = require('pg');
require('dotenv').config();

// Koneksi pool ke PostgreSQL. Semua query di aplikasi ini menggunakan
// pool.query() agar koneksi otomatis dikembalikan ke pool setelah dipakai.
const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
});

pool.on('error', (err) => {
  console.error('Unexpected error pada koneksi PostgreSQL', err);
  process.exit(-1);
});

module.exports = pool;
