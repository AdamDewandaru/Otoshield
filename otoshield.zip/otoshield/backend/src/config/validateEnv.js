/**
 * Validasi environment variable saat startup (Sesi 9 - production hardening).
 *
 * LATAR BELAKANG: sebelum ada file ini, server akan tetap `listen()` sukses
 * walau `JWT_SECRET`/`DATABASE_URL`/`ADMIN_API_KEY` kosong atau masih nilai
 * placeholder dari `.env.example` - baru ketahuan salah saat request pertama
 * gagal (mis. `jwt.sign(payload, undefined)` melempar error yang membingungkan).
 * Modul ini membuat kesalahan konfigurasi ketahuan SAAT BOOT, bukan saat
 * user pertama mencoba pakai aplikasi.
 *
 * CATATAN JUJUR: ini validasi environment variable, BUKAN validasi bahwa
 * kredensial itu VALID/aktif (mis. `MIDTRANS_SERVER_KEY` yang formatnya benar
 * tapi sudah revoked tetap lolos di sini - itu di luar jangkauan validasi
 * startup, cuma ketahuan saat gateway sungguhan menolak request).
 */

const REQUIRED_VARS = ['DATABASE_URL', 'JWT_SECRET', 'ADMIN_API_KEY'];

// Nilai contoh persis dari `.env.example` - kalau masih ini di production,
// hampir pasti developer lupa menggantinya sebelum deploy.
const KNOWN_PLACEHOLDERS = {
  JWT_SECRET: 'change_this_to_a_long_random_secret',
  ADMIN_API_KEY: 'change_this_to_a_long_random_admin_key',
};

const MIN_SECRET_LENGTH = 16;

/**
 * @param {NodeJS.ProcessEnv} env - diinjeksi supaya bisa ditest tanpa mengubah process.env asli.
 * @returns {{ errors: string[], warnings: string[] }}
 */
function checkEnv(env) {
  const errors = [];
  const warnings = [];
  const isProduction = env.NODE_ENV === 'production';

  for (const key of REQUIRED_VARS) {
    if (!env[key] || String(env[key]).trim() === '') {
      errors.push(`${key} wajib diisi (lihat backend/.env.example).`);
    }
  }

  for (const [key, placeholder] of Object.entries(KNOWN_PLACEHOLDERS)) {
    if (env[key] === placeholder) {
      const message = `${key} masih nilai contoh dari .env.example ("${placeholder}") - ganti dengan nilai acak milik sendiri sebelum deploy.`;
      if (isProduction) {
        errors.push(message);
      } else {
        warnings.push(message);
      }
    }
  }

  if (env.JWT_SECRET && env.JWT_SECRET.length < MIN_SECRET_LENGTH && !errors.some((e) => e.startsWith('JWT_SECRET'))) {
    const message = `JWT_SECRET sebaiknya minimal ${MIN_SECRET_LENGTH} karakter (saat ini ${env.JWT_SECRET.length}) agar tidak mudah ditebak.`;
    if (isProduction) {
      errors.push(message);
    } else {
      warnings.push(message);
    }
  }

  if (isProduction && (!env.CORS_ORIGIN || env.CORS_ORIGIN === '*')) {
    warnings.push(
      'CORS_ORIGIN belum diset ke domain spesifik di production (masih mengizinkan semua origin) - lihat backend/.env.example.'
    );
  }

  return { errors, warnings };
}

/**
 * Dipanggil sekali saat boot (`server.js`). Melempar error (menghentikan
 * proses) kalau ada `errors`, sekadar `console.warn` kalau cuma `warnings`.
 * Sengaja TIDAK dipanggil dari `app.js`/`createApp()` supaya test integrasi
 * (yang sengaja pakai `JWT_SECRET` pendek untuk kecepatan) tidak ikut gagal -
 * lihat `test-helpers/integrationSetup.js`.
 */
function validateEnvOrExit(env = process.env) {
  const { errors, warnings } = checkEnv(env);

  for (const warning of warnings) {
    console.warn(`[config] PERINGATAN: ${warning}`);
  }

  if (errors.length > 0) {
    console.error('[config] Gagal start server - konfigurasi environment tidak valid:');
    for (const error of errors) {
      console.error(`  - ${error}`);
    }
    process.exit(1);
  }
}

module.exports = { checkEnv, validateEnvOrExit };
