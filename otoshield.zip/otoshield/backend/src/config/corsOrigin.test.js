const { resolveCorsOrigin } = require('./corsOrigin');

describe('resolveCorsOrigin', () => {
  test('CORS_ORIGIN tidak diset sama sekali -> "*"', () => {
    expect(resolveCorsOrigin({})).toBe('*');
  });

  test('CORS_ORIGIN string kosong -> "*"', () => {
    expect(resolveCorsOrigin({ CORS_ORIGIN: '' })).toBe('*');
  });

  test('CORS_ORIGIN cuma spasi -> "*"', () => {
    expect(resolveCorsOrigin({ CORS_ORIGIN: '   ' })).toBe('*');
  });

  test('CORS_ORIGIN eksplisit "*" -> "*"', () => {
    expect(resolveCorsOrigin({ CORS_ORIGIN: '*' })).toBe('*');
  });

  test('CORS_ORIGIN satu domain -> array berisi satu domain itu', () => {
    expect(resolveCorsOrigin({ CORS_ORIGIN: 'https://otoshield.app' })).toEqual(['https://otoshield.app']);
  });

  test('CORS_ORIGIN beberapa domain dipisah koma -> array berisi semuanya, trimmed', () => {
    expect(
      resolveCorsOrigin({ CORS_ORIGIN: 'https://otoshield.app, https://admin.otoshield.app ,https://x.com' })
    ).toEqual(['https://otoshield.app', 'https://admin.otoshield.app', 'https://x.com']);
  });

  test('CORS_ORIGIN dengan koma trailing/entry kosong -> entry kosong dibuang', () => {
    expect(resolveCorsOrigin({ CORS_ORIGIN: 'https://otoshield.app,,' })).toEqual(['https://otoshield.app']);
  });
});
