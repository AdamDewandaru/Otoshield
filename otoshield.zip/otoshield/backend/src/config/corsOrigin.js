/**
 * Resolusi origin CORS dari env var `CORS_ORIGIN` (Sesi 9 - production hardening).
 *
 * SEBELUM ini, `app.js` memakai `cors()` tanpa argumen (mengizinkan SEMUA origin)
 * dan `server.js` memakai `{ cors: { origin: '*' } }` untuk Socket.IO - cocok untuk
 * development/testing tapi berisiko di production (API + realtime SOS bisa dipanggil
 * dari domain manapun). Modul ini dipakai oleh KEDUANYA (`app.js` & `server.js`) agar
 * konsisten satu sumber kebenaran.
 *
 * Format `CORS_ORIGIN` di .env: kosong/`*` -> izinkan semua (default, cocok untuk
 * development/testing lokal); daftar domain dipisah koma -> whitelist, mis.
 * `CORS_ORIGIN=https://otoshield.app,https://admin.otoshield.app`.
 */
function resolveCorsOrigin(env = process.env) {
  const raw = env.CORS_ORIGIN;
  if (!raw || raw.trim() === '' || raw.trim() === '*') {
    return '*';
  }
  const origins = raw
    .split(',')
    .map((o) => o.trim())
    .filter(Boolean);
  return origins.length > 0 ? origins : '*';
}

module.exports = { resolveCorsOrigin };
