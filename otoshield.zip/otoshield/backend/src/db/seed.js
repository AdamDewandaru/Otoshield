/**
 * Script untuk mengisi data contoh (seed.sql) ke database.
 * Jalankan dengan: npm run seed
 */
const fs = require('fs');
const path = require('path');
const pool = require('../config/db');

async function seed() {
  try {
    const seedSql = fs.readFileSync(path.join(__dirname, 'seed.sql'), 'utf8');
    await pool.query(seedSql);
    console.log('Seed data berhasil dimasukkan.');
    process.exit(0);
  } catch (err) {
    console.error('Seed gagal:', err);
    process.exit(1);
  }
}

seed();
