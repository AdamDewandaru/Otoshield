-- =========================================================
-- OtoShield - Data Contoh (Seed)
-- =========================================================

INSERT INTO workshops (name, address, latitude, longitude, phone, is_verified, rating, rating_count, offers_towing)
VALUES
('Bengkel Jaya Motor', 'Jl. Sudirman No. 12, Jakarta Pusat', -6.2088, 106.8456, '081234567890', TRUE, 4.7, 128, TRUE),
('AutoCare Pro', 'Jl. Gatot Subroto No. 45, Jakarta Selatan', -6.2297, 106.8253, '081298765432', TRUE, 4.5, 89, TRUE),
('Bengkel Sumber Rejeki', 'Jl. Ahmad Yani No. 8, Jember', -8.1844, 113.6681, '081345678901', TRUE, 4.8, 210, TRUE),
('Speedy Garage', 'Jl. Diponegoro No. 22, Jember', -8.1720, 113.7040, '081356781234', FALSE, 3.9, 34, FALSE);

INSERT INTO workshop_services (workshop_id, service_name, labor_fee_min, labor_fee_max, part_price_min, part_price_max)
SELECT id, 'Ganti Oli Mesin', 30000, 50000, 45000, 120000 FROM workshops WHERE name = 'Bengkel Jaya Motor';
INSERT INTO workshop_services (workshop_id, service_name, labor_fee_min, labor_fee_max, part_price_min, part_price_max)
SELECT id, 'Ganti Kampas Rem', 40000, 75000, 60000, 250000 FROM workshops WHERE name = 'Bengkel Jaya Motor';
INSERT INTO workshop_services (workshop_id, service_name, labor_fee_min, labor_fee_max, part_price_min, part_price_max)
SELECT id, 'Servis AC Mobil', 100000, 200000, 150000, 800000 FROM workshops WHERE name = 'AutoCare Pro';
INSERT INTO workshop_services (workshop_id, service_name, labor_fee_min, labor_fee_max, part_price_min, part_price_max)
SELECT id, 'Ganti Aki', 20000, 40000, 450000, 1200000 FROM workshops WHERE name = 'Bengkel Sumber Rejeki';

-- Basis pengetahuan estimator biaya (kata kunci bahasa Indonesia sehari-hari)
INSERT INTO cost_estimate_rules (keyword, issue_category, estimated_min, estimated_max) VALUES
('rem berdecit', 'Kampas Rem Aus', 100000, 350000),
('rem bunyi', 'Kampas Rem Aus', 100000, 350000),
('mesin getar ac nyala', 'Kompresor AC / Mounting Mesin', 300000, 1500000),
('ac tidak dingin', 'Freon Habis / Kompresor AC', 150000, 900000),
('mesin overheat', 'Radiator / Water Pump', 300000, 2000000),
('susah starter', 'Aki Lemah / Dinamo Starter', 200000, 1500000),
('ban bocor', 'Tambal Ban / Ganti Ban', 20000, 800000),
('mobil bergetar saat jalan', 'Balancing & Spooring Roda', 150000, 500000),
('bau bensin', 'Kebocoran Selang Bahan Bakar', 200000, 800000),
('lampu indikator mesin menyala', 'Diagnosa ECU / Sensor', 100000, 600000);
