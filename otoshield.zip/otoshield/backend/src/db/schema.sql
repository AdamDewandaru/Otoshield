-- =========================================================
-- OtoShield - Skema Database PostgreSQL
-- Sesuai blueprint (Bagian 4) + tabel tambahan yang dibutuhkan
-- agar keempat fitur utama benar-benar berfungsi end-to-end.
-- =========================================================

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

CREATE TABLE IF NOT EXISTS users (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name VARCHAR(150) NOT NULL,
  phone VARCHAR(20) UNIQUE NOT NULL,
  email VARCHAR(150) UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS vehicles (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  brand VARCHAR(50) NOT NULL,
  model VARCHAR(50) NOT NULL,
  year INT,
  license_plate VARCHAR(20),
  current_kilometer INT NOT NULL DEFAULT 0,
  last_service_km INT NOT NULL DEFAULT 0,
  last_service_date DATE,
  created_at TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS workshops (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name VARCHAR(150) NOT NULL,
  address TEXT,
  latitude DECIMAL(10, 7) NOT NULL,
  longitude DECIMAL(10, 7) NOT NULL,
  phone VARCHAR(20),
  is_verified BOOLEAN NOT NULL DEFAULT FALSE,
  rating FLOAT NOT NULL DEFAULT 0,
  rating_count INT NOT NULL DEFAULT 0,
  offers_towing BOOLEAN NOT NULL DEFAULT FALSE,
  created_at TIMESTAMP NOT NULL DEFAULT NOW()
);

-- Daftar harga jasa (labor fee) transparan per bengkel -> Fitur 2
CREATE TABLE IF NOT EXISTS workshop_services (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  workshop_id UUID NOT NULL REFERENCES workshops(id) ON DELETE CASCADE,
  service_name VARCHAR(150) NOT NULL,
  labor_fee_min INT NOT NULL,
  labor_fee_max INT NOT NULL,
  part_price_min INT,
  part_price_max INT
);

CREATE TABLE IF NOT EXISTS reviews (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  workshop_id UUID NOT NULL REFERENCES workshops(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  rating INT NOT NULL CHECK (rating BETWEEN 1 AND 5),
  comment TEXT,
  created_at TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS emergency_requests (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  workshop_id UUID REFERENCES workshops(id),
  status VARCHAR(20) NOT NULL DEFAULT 'PENDING'
    CHECK (status IN ('PENDING','ACCEPTED','ON_THE_WAY','COMPLETED','CANCELLED')),
  issue_description TEXT,
  latitude DECIMAL(10, 7) NOT NULL,
  longitude DECIMAL(10, 7) NOT NULL,
  mechanic_latitude DECIMAL(10, 7),
  mechanic_longitude DECIMAL(10, 7),
  estimated_cost_min INT,
  estimated_cost_max INT,
  photo_url TEXT,
  created_at TIMESTAMP NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMP NOT NULL DEFAULT NOW()
);

-- Jaga-jaga jika tabel emergency_requests sudah ada dari sesi sebelumnya
-- (sebelum kolom photo_url ditambahkan) -> migrasi aditif, aman dijalankan ulang.
ALTER TABLE emergency_requests ADD COLUMN IF NOT EXISTS photo_url TEXT;

-- Pembayaran digital (Bagian 5 blueprint, langkah 6 user flow SOS).
-- CATATAN: status PAID di sini disimulasikan lewat endpoint PUT /:id/pay.
-- Untuk produksi, ganti dengan integrasi payment gateway (mis. Midtrans/Xendit)
-- yang mengonfirmasi pembayaran lewat webhook bertanda tangan, bukan endpoint publik.
CREATE TABLE IF NOT EXISTS payments (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  emergency_request_id UUID REFERENCES emergency_requests(id) ON DELETE SET NULL,
  workshop_id UUID REFERENCES workshops(id) ON DELETE SET NULL,
  amount INT NOT NULL CHECK (amount > 0),
  method VARCHAR(30) NOT NULL DEFAULT 'VIRTUAL_ACCOUNT'
    CHECK (method IN ('VIRTUAL_ACCOUNT', 'E_WALLET', 'CASH')),
  status VARCHAR(20) NOT NULL DEFAULT 'PENDING'
    CHECK (status IN ('PENDING', 'PAID', 'FAILED', 'CANCELLED')),
  payment_reference VARCHAR(100),
  created_at TIMESTAMP NOT NULL DEFAULT NOW(),
  paid_at TIMESTAMP
);

-- Basis pengetahuan Smart Cost Estimator: cocokkan kata kunci gejala -> kisaran biaya wajar
CREATE TABLE IF NOT EXISTS cost_estimate_rules (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  keyword VARCHAR(100) NOT NULL,
  issue_category VARCHAR(100) NOT NULL,
  estimated_min INT NOT NULL,
  estimated_max INT NOT NULL
);

CREATE TABLE IF NOT EXISTS service_history (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  vehicle_id UUID NOT NULL REFERENCES vehicles(id) ON DELETE CASCADE,
  workshop_id UUID REFERENCES workshops(id),
  service_type VARCHAR(100) NOT NULL,
  odometer INT NOT NULL,
  cost INT,
  notes TEXT,
  service_date DATE NOT NULL DEFAULT CURRENT_DATE
);

-- Akun staf bengkel/mekanik/operator (Sesi 3 - menggantikan ADMIN_API_KEY tunggal
-- di admin.middleware.js, lihat catatan "belum dikerjakan" #2 di otoshield_blueprint.md).
-- Setiap staf punya login sendiri (phone+password) dan role, sehingga aksi di
-- dashboard /mechanic bisa dilacak per-orang, bukan berbagi satu shared key.
CREATE TABLE IF NOT EXISTS staff_accounts (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  workshop_id UUID REFERENCES workshops(id) ON DELETE SET NULL,
  name VARCHAR(150) NOT NULL,
  phone VARCHAR(20) UNIQUE NOT NULL,
  email VARCHAR(150),
  password_hash VARCHAR(255) NOT NULL,
  role VARCHAR(20) NOT NULL DEFAULT 'MECHANIC'
    CHECK (role IN ('ADMIN', 'WORKSHOP_STAFF', 'MECHANIC')),
  is_active BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_workshops_location ON workshops (latitude, longitude);
CREATE INDEX IF NOT EXISTS idx_emergency_status ON emergency_requests (status);
CREATE INDEX IF NOT EXISTS idx_service_history_vehicle ON service_history (vehicle_id);
CREATE INDEX IF NOT EXISTS idx_payments_user ON payments (user_id);
