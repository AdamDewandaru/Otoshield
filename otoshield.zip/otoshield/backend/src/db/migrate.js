/**
 * Script sederhana untuk menjalankan schema.sql ke database.
 * Jalankan dengan: npm run migrate
 */
const fs = require('fs');
const path = require('path');
const pool = require('../config/db');

async function migrate() {
  try {
    const schema = fs.readFileSync(path.join(__dirname, 'schema.sql'), 'utf8');
    await pool.query(schema);
    console.log('Migrasi schema.sql berhasil dijalankan.');
    process.exit(0);
  } catch (err) {
    console.error('Migrasi gagal:', err);
    process.exit(1);
  }
}

migrate();
