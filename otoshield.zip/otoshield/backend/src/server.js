require('dotenv').config();

// Validasi environment variable SEBELUM apa pun lain di-require - kalau ada
// yang wajib tapi kosong/masih placeholder, proses berhenti di sini dengan
// pesan jelas, bukan gagal samar-samar nanti saat request pertama masuk
// (Sesi 9 - production hardening). Sengaja hanya dipanggil di sini
// (entry point boot sungguhan), BUKAN di app.js, supaya test integrasi yang
// require('./app') langsung tidak ikut divalidasi/exit - lihat catatan di
// config/validateEnv.js.
const { validateEnvOrExit } = require('./config/validateEnv');
validateEnvOrExit();

const http = require('http');
const { Server } = require('socket.io');
const createApp = require('./app');
const pool = require('./config/db');
const { resolveCorsOrigin } = require('./config/corsOrigin');
const registerEmergencySocket = require('./sockets/emergency.socket');

const app = createApp();
const server = http.createServer(app);
// Origin sama dengan REST API (lihat app.js) - satu sumber kebenaran lewat
// config/corsOrigin.js, bukan dua konfigurasi CORS yang bisa saling berbeda.
const io = new Server(server, { cors: { origin: resolveCorsOrigin() } });

app.set('io', io); // agar bisa diakses lewat req.app.get('io') di routes/controllers

registerEmergencySocket(io);

const PORT = process.env.PORT || 4000;
server.listen(PORT, () => {
  console.log(`OtoShield backend berjalan di http://localhost:${PORT}`);
});

/**
 * Graceful shutdown (Sesi 9 - production hardening).
 *
 * SEBELUM ini, `SIGTERM`/`SIGINT` (dikirim orkestrator container, `docker
 * stop`, atau Ctrl+C) langsung membunuh proses paksa - koneksi HTTP yang
 * sedang berlangsung terputus mendadak, dan koneksi ke pool PostgreSQL tidak
 * ditutup rapi. Ini penting untuk deployment tanpa downtime (rolling deploy
 * di container orchestrator mengirim SIGTERM lalu menunggu proses berhenti
 * sendiri sebelum "memaksa" dengan SIGKILL).
 */
let isShuttingDown = false;
function shutdown(signal) {
  if (isShuttingDown) return;
  isShuttingDown = true;
  console.log(`\n[server] Menerima ${signal}, mematikan server dengan rapi...`);

  const forceExitTimer = setTimeout(() => {
    console.error('[server] Timeout menunggu koneksi selesai, keluar paksa.');
    process.exit(1);
  }, 10_000);
  forceExitTimer.unref();

  server.close(() => {
    console.log('[server] Server HTTP berhenti menerima koneksi baru.');
    io.close(() => {
      pool.end(() => {
        console.log('[server] Koneksi PostgreSQL ditutup. Sampai jumpa.');
        clearTimeout(forceExitTimer);
        process.exit(0);
      });
    });
  });
}

process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('SIGINT', () => shutdown('SIGINT'));
