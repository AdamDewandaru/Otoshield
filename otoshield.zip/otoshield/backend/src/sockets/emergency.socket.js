/**
 * Socket.io namespace untuk fitur SOS realtime.
 * Client (app pengguna maupun app mekanik) join room "emergency:<id>"
 * agar hanya menerima update terkait permintaan SOS tersebut.
 */
function registerEmergencySocket(io) {
  io.on('connection', (socket) => {
    socket.on('emergency:join', (emergencyId) => {
      socket.join(`emergency:${emergencyId}`);
    });

    // Mekanik mengirim update posisi GPS secara berkala saat menuju lokasi
    socket.on('emergency:location:update', ({ emergencyId, latitude, longitude }) => {
      io.to(`emergency:${emergencyId}`).emit('emergency:mechanic_location', { latitude, longitude });
    });

    socket.on('disconnect', () => {
      // tidak ada cleanup khusus untuk MVP ini
    });
  });
}

module.exports = registerEmergencySocket;
