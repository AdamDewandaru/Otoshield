const pool = require('../config/db');
const gateway = require('../services/paymentGateway');

/**
 * Pembayaran digital (Bagian 5 blueprint, User Flow SOS langkah 6).
 *
 * Sesi 4: diganti dari simulasi manual (endpoint publik `PUT /:id/pay` yang
 * bisa dipanggil siapa saja) jadi pola gateway sungguhan (Midtrans-style):
 *   1. createPayment memanggil `paymentGateway.createTransaction()` untuk
 *      dapat `order_id` & `redirect_url` dari gateway.
 *   2. Status pembayaran metode VIRTUAL_ACCOUNT/E_WALLET SEKARANG HANYA bisa
 *      berubah jadi PAID lewat webhook (`POST /api/payments/webhook/midtrans`)
 *      yang memverifikasi signature - lihat `paymentGateway.js` untuk catatan
 *      jujur soal apa yang sungguhan vs disimulasikan.
 *   3. Metode CASH (bayar tunai ke mekanik/bengkel, tidak lewat gateway apa
 *      pun) tetap punya jalur konfirmasi manual: `PUT /:id/confirm-cash`,
 *      TAPI hanya berlaku untuk `method === 'CASH'` (VA/E-WALLET akan ditolak
 *      403 di endpoint ini, harus lewat webhook).
 */

const validMethods = ['VIRTUAL_ACCOUNT', 'E_WALLET', 'CASH'];

// POST /api/payments - buat tagihan pembayaran baru + transaksi di gateway
async function createPayment(req, res) {
  const { emergency_request_id, workshop_id, amount, method } = req.body;

  if (!amount || amount <= 0) {
    return res.status(400).json({ message: 'amount wajib diisi dan lebih dari 0.' });
  }
  if (method && !validMethods.includes(method)) {
    return res.status(400).json({ message: 'method tidak valid.' });
  }
  if (!emergency_request_id && !workshop_id) {
    return res.status(400).json({ message: 'emergency_request_id atau workshop_id wajib diisi.' });
  }

  try {
    if (emergency_request_id) {
      const check = await pool.query(
        'SELECT id, user_id FROM emergency_requests WHERE id = $1',
        [emergency_request_id]
      );
      if (check.rows.length === 0) {
        return res.status(404).json({ message: 'Permintaan SOS tidak ditemukan.' });
      }
      if (check.rows[0].user_id !== req.user.id) {
        return res.status(403).json({ message: 'Permintaan SOS ini bukan milik Anda.' });
      }
    }

    const finalMethod = method || 'VIRTUAL_ACCOUNT';

    // Insert dulu (butuh payment.id sebagai dasar order_id gateway agar tertelusur & unik)
    const inserted = await pool.query(
      `INSERT INTO payments (user_id, emergency_request_id, workshop_id, amount, method)
       VALUES ($1, $2, $3, $4, $5) RETURNING *`,
      [req.user.id, emergency_request_id || null, workshop_id || null, amount, finalMethod]
    );
    const payment = inserted.rows[0];

    const gatewayTx = await gateway.createTransaction({
      paymentId: payment.id,
      grossAmount: amount,
      method: finalMethod,
    });

    const updated = await pool.query(
      `UPDATE payments SET payment_reference = $1 WHERE id = $2 RETURNING *`,
      [gatewayTx.order_id, payment.id]
    );

    res.status(201).json({
      ...updated.rows[0],
      gateway_redirect_url: gatewayTx.redirect_url,
      gateway_mode: gatewayTx._gateway_mode,
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Gagal membuat tagihan pembayaran.' });
  }
}

// GET /api/payments/:id
async function getPayment(req, res) {
  const { id } = req.params;
  try {
    const { rows } = await pool.query('SELECT * FROM payments WHERE id = $1 AND user_id = $2', [
      id,
      req.user.id,
    ]);
    if (rows.length === 0) return res.status(404).json({ message: 'Pembayaran tidak ditemukan.' });
    res.json(rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Gagal mengambil data pembayaran.' });
  }
}

// GET /api/payments - riwayat pembayaran milik pengguna yang login
async function listMyPayments(req, res) {
  try {
    const { rows } = await pool.query(
      'SELECT * FROM payments WHERE user_id = $1 ORDER BY created_at DESC',
      [req.user.id]
    );
    res.json(rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Gagal mengambil riwayat pembayaran.' });
  }
}

// PUT /api/payments/:id/confirm-cash - konfirmasi manual KHUSUS metode CASH
// (bayar tunai langsung ke mekanik, tidak ada gateway yang terlibat sama sekali)
async function confirmCashPayment(req, res) {
  const { id } = req.params;
  try {
    const existing = await pool.query('SELECT * FROM payments WHERE id = $1 AND user_id = $2', [
      id,
      req.user.id,
    ]);
    if (existing.rows.length === 0) {
      return res.status(404).json({ message: 'Pembayaran tidak ditemukan.' });
    }
    if (existing.rows[0].method !== 'CASH') {
      return res.status(403).json({
        message: 'Pembayaran non-tunai hanya bisa dikonfirmasi lewat webhook gateway, bukan endpoint ini.',
      });
    }
    if (existing.rows[0].status === 'PAID') {
      return res.status(409).json({ message: 'Pembayaran ini sudah lunas.' });
    }

    const { rows } = await pool.query(
      `UPDATE payments SET status = 'PAID', paid_at = NOW() WHERE id = $1 RETURNING *`,
      [id]
    );
    res.json(rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Gagal memproses konfirmasi pembayaran tunai.' });
  }
}

// POST /api/payments/webhook/midtrans - dipanggil OLEH GATEWAY, bukan client.
// TIDAK pakai auth.middleware (gateway tidak punya JWT user) - keamanan datang
// dari verifikasi signature_key, bukan dari siapa yang memanggil.
async function handleMidtransWebhook(req, res) {
  const { order_id, status_code, gross_amount, signature_key, transaction_status } = req.body;

  const isValid = gateway.verifySignatureKey({ order_id, status_code, gross_amount, signature_key });
  if (!isValid) {
    return res.status(403).json({ message: 'Signature tidak valid.' });
  }

  try {
    const existing = await pool.query('SELECT * FROM payments WHERE payment_reference = $1', [order_id]);
    if (existing.rows.length === 0) {
      // Tetap balas 200 - konvensi webhook gateway: gateway akan retry terus kalau non-2xx,
      // dan order_id yang tidak dikenal bukan sesuatu yang perlu di-retry.
      return res.status(200).json({ message: 'order_id tidak dikenal, diabaikan.' });
    }

    let newStatus = null;
    if (['settlement', 'capture'].includes(transaction_status)) {
      newStatus = 'PAID';
    } else if (['deny', 'cancel', 'expire'].includes(transaction_status)) {
      newStatus = 'FAILED';
    }

    if (newStatus && existing.rows[0].status !== 'PAID') {
      if (newStatus === 'PAID') {
        await pool.query(
          `UPDATE payments SET status = $1, paid_at = NOW() WHERE payment_reference = $2`,
          [newStatus, order_id]
        );
      } else {
        await pool.query(`UPDATE payments SET status = $1 WHERE payment_reference = $2`, [
          newStatus,
          order_id,
        ]);
      }
    }

    res.status(200).json({ message: 'Webhook diterima.' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Gagal memproses webhook.' });
  }
}

module.exports = {
  createPayment,
  getPayment,
  listMyPayments,
  confirmCashPayment,
  handleMidtransWebhook,
};
