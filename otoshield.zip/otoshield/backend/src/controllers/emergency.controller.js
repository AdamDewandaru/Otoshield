const pool = require('../config/db');
const { haversineDistanceKm } = require('../utils/haversine');
const { estimateCost } = require('../utils/estimatorRules');
const { getDriver: getStorageDriver } = require('../services/storage');

// POST /api/emergency - buat permintaan SOS baru
async function createEmergency(req, res, io) {
  const { latitude, longitude, issue_description } = req.body;
  if (latitude === undefined || longitude === undefined) {
    return res.status(400).json({ message: 'latitude dan longitude wajib diisi.' });
  }

  try {
    // Estimasi biaya awal otomatis dari deskripsi kerusakan (jika ada)
    let estimated_cost_min = null;
    let estimated_cost_max = null;
    if (issue_description) {
      const est = await estimateCost(issue_description);
      if (est.matched) {
        estimated_cost_min = est.estimated_min;
        estimated_cost_max = est.estimated_max;
      }
    }

    const { rows } = await pool.query(
      `INSERT INTO emergency_requests
         (user_id, latitude, longitude, issue_description, estimated_cost_min, estimated_cost_max)
       VALUES ($1, $2, $3, $4, $5, $6) RETURNING *`,
      [req.user.id, latitude, longitude, issue_description || null, estimated_cost_min, estimated_cost_max]
    );
    const emergency = rows[0];

    // Cari mekanik/bengkel dengan layanan towing terdekat dalam radius 5km (sesuai user flow blueprint)
    const workshopsResult = await pool.query(
      'SELECT * FROM workshops WHERE offers_towing = TRUE OR is_verified = TRUE'
    );
    const nearby = workshopsResult.rows
      .map((w) => ({
        ...w,
        distance_km: haversineDistanceKm(latitude, longitude, parseFloat(w.latitude), parseFloat(w.longitude)),
      }))
      .filter((w) => w.distance_km <= 5)
      .sort((a, b) => a.distance_km - b.distance_km)
      .slice(0, 5);

    // Broadcast realtime ke room SOS agar dashboard mekanik/operator bisa melihat permintaan baru
    if (io) io.to(`emergency:${emergency.id}`).emit('emergency:created', emergency);

    res.status(201).json({ emergency, nearby_workshops: nearby });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Gagal membuat permintaan SOS.' });
  }
}

// GET /api/emergency/:id - status permintaan SOS (untuk polling dari app)
async function getEmergency(req, res) {
  const { id } = req.params;
  try {
    const { rows } = await pool.query('SELECT * FROM emergency_requests WHERE id = $1', [id]);
    if (rows.length === 0) return res.status(404).json({ message: 'Permintaan SOS tidak ditemukan.' });
    res.json(rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Gagal mengambil status SOS.' });
  }
}

// PUT /api/emergency/:id/status - update status (dipakai oleh sisi mekanik/operator)
async function updateStatus(req, res, io) {
  const { id } = req.params;
  const { status, workshop_id, mechanic_latitude, mechanic_longitude } = req.body;
  const validStatuses = ['PENDING', 'ACCEPTED', 'ON_THE_WAY', 'COMPLETED', 'CANCELLED'];
  if (status && !validStatuses.includes(status)) {
    return res.status(400).json({ message: 'status tidak valid.' });
  }

  try {
    const { rows } = await pool.query(
      `UPDATE emergency_requests SET
         status = COALESCE($1, status),
         workshop_id = COALESCE($2, workshop_id),
         mechanic_latitude = COALESCE($3, mechanic_latitude),
         mechanic_longitude = COALESCE($4, mechanic_longitude),
         updated_at = NOW()
       WHERE id = $5 RETURNING *`,
      [status || null, workshop_id || null, mechanic_latitude || null, mechanic_longitude || null, id]
    );
    if (rows.length === 0) return res.status(404).json({ message: 'Permintaan SOS tidak ditemukan.' });

    const updated = rows[0];
    // Kirim update realtime ke pengguna yang sedang menunggu (dipakai untuk tracking ETA & posisi mekanik)
    if (io) io.to(`emergency:${id}`).emit('emergency:updated', updated);

    res.json(updated);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Gagal memperbarui status SOS.' });
  }
}

// POST /api/emergency/:id/photo - upload foto kerusakan kendaraan (multipart/form-data, field "photo")
async function uploadPhoto(req, res, io) {
  const { id } = req.params;
  if (!req.file) {
    return res.status(400).json({ message: 'File foto wajib disertakan (field "photo").' });
  }

  try {
    // Sesi 4: URL didapat lewat abstraksi storage driver (local disk atau S3,
    // tergantung STORAGE_DRIVER) - lihat services/storage/index.js
    const storageDriver = getStorageDriver();
    const photoUrl = await storageDriver.getUrl(req);
    const { rows } = await pool.query(
      `UPDATE emergency_requests SET photo_url = $1, updated_at = NOW()
       WHERE id = $2 AND user_id = $3 RETURNING *`,
      [photoUrl, id, req.user.id]
    );
    if (rows.length === 0) {
      return res.status(404).json({ message: 'Permintaan SOS tidak ditemukan.' });
    }

    const updated = rows[0];
    if (io) io.to(`emergency:${id}`).emit('emergency:updated', updated);

    res.json(updated);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Gagal mengunggah foto.' });
  }
}

// GET /api/admin/emergency?status= - daftar semua permintaan SOS (dipakai dashboard mekanik/operator)
async function listEmergencies(req, res) {
  const { status } = req.query;
  try {
    let query = `
      SELECT e.*, u.name AS user_name, u.phone AS user_phone
      FROM emergency_requests e
      JOIN users u ON u.id = e.user_id`;
    const params = [];
    if (status) {
      query += ' WHERE e.status = $1';
      params.push(status);
    }
    query += ' ORDER BY e.created_at DESC LIMIT 100';

    const { rows } = await pool.query(query, params);
    res.json(rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Gagal mengambil daftar permintaan SOS.' });
  }
}

module.exports = { createEmergency, getEmergency, updateStatus, uploadPhoto, listEmergencies };
