const pool = require('../config/db');

// GET /api/vehicles - daftar kendaraan milik user yang login
async function listVehicles(req, res) {
  try {
    const { rows } = await pool.query(
      'SELECT * FROM vehicles WHERE user_id = $1 ORDER BY created_at DESC',
      [req.user.id]
    );
    res.json(rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Gagal mengambil data kendaraan.' });
  }
}

// POST /api/vehicles - tambah kendaraan baru
async function addVehicle(req, res) {
  const { brand, model, year, license_plate, current_kilometer } = req.body;
  if (!brand || !model) {
    return res.status(400).json({ message: 'brand dan model wajib diisi.' });
  }
  try {
    const { rows } = await pool.query(
      `INSERT INTO vehicles (user_id, brand, model, year, license_plate, current_kilometer)
       VALUES ($1, $2, $3, $4, $5, $6) RETURNING *`,
      [req.user.id, brand, model, year || null, license_plate || null, current_kilometer || 0]
    );
    res.status(201).json(rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Gagal menambahkan kendaraan.' });
  }
}

// PUT /api/vehicles/:id - edit data kendaraan (item "belum dikerjakan" #8: manajemen kendaraan)
async function updateVehicle(req, res) {
  const { id } = req.params;
  const { brand, model, year, license_plate } = req.body;
  if (!brand && !model && year === undefined && license_plate === undefined) {
    return res.status(400).json({ message: 'Isi minimal satu field untuk diperbarui.' });
  }
  try {
    const { rows } = await pool.query(
      `UPDATE vehicles SET
         brand = COALESCE($1, brand),
         model = COALESCE($2, model),
         year = COALESCE($3, year),
         license_plate = COALESCE($4, license_plate)
       WHERE id = $5 AND user_id = $6 RETURNING *`,
      [brand || null, model || null, year ?? null, license_plate ?? null, id, req.user.id]
    );
    if (rows.length === 0) return res.status(404).json({ message: 'Kendaraan tidak ditemukan.' });
    res.json(rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Gagal memperbarui kendaraan.' });
  }
}

// DELETE /api/vehicles/:id - hapus kendaraan (item "belum dikerjakan" #8)
async function deleteVehicle(req, res) {
  const { id } = req.params;
  try {
    const { rows } = await pool.query(
      'DELETE FROM vehicles WHERE id = $1 AND user_id = $2 RETURNING id',
      [id, req.user.id]
    );
    if (rows.length === 0) return res.status(404).json({ message: 'Kendaraan tidak ditemukan.' });
    res.status(204).send();
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Gagal menghapus kendaraan.' });
  }
}

// PUT /api/vehicles/:id/odometer - update kilometer terkini (Digital Service Book)
async function updateOdometer(req, res) {
  const { id } = req.params;
  const { current_kilometer } = req.body;
  if (current_kilometer === undefined) {
    return res.status(400).json({ message: 'current_kilometer wajib diisi.' });
  }
  try {
    const { rows } = await pool.query(
      `UPDATE vehicles SET current_kilometer = $1
       WHERE id = $2 AND user_id = $3 RETURNING *`,
      [current_kilometer, id, req.user.id]
    );
    if (rows.length === 0) return res.status(404).json({ message: 'Kendaraan tidak ditemukan.' });
    res.json(rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Gagal memperbarui odometer.' });
  }
}

// GET /api/vehicles/:id/reminders - pengingat servis berkala berdasarkan odometer
async function getReminders(req, res) {
  const { id } = req.params;
  try {
    const { rows } = await pool.query(
      'SELECT * FROM vehicles WHERE id = $1 AND user_id = $2',
      [id, req.user.id]
    );
    if (rows.length === 0) return res.status(404).json({ message: 'Kendaraan tidak ditemukan.' });
    const vehicle = rows[0];

    // Aturan sederhana pengingat servis berkala
    const kmSinceService = vehicle.current_kilometer - vehicle.last_service_km;
    const reminders = [];

    if (kmSinceService >= 5000) {
      reminders.push({
        type: 'Ganti Oli Mesin',
        message: `Sudah ${kmSinceService} km sejak servis terakhir. Segera ganti oli.`,
        urgent: kmSinceService >= 7000,
      });
    } else if (kmSinceService >= 4000) {
      reminders.push({
        type: 'Ganti Oli Mesin',
        message: `Sisa ${5000 - kmSinceService} km lagi menuju jadwal ganti oli.`,
        urgent: false,
      });
    }

    if (kmSinceService >= 10000) {
      reminders.push({
        type: 'Cek Kampas Rem',
        message: 'Kampas rem disarankan diperiksa setiap 10.000 km.',
        urgent: kmSinceService >= 15000,
      });
    }

    if (vehicle.last_service_date) {
      const monthsSince =
        (Date.now() - new Date(vehicle.last_service_date).getTime()) / (1000 * 60 * 60 * 24 * 30);
      if (monthsSince >= 18) {
        reminders.push({
          type: 'Cek Kondisi Aki',
          message: 'Aki umumnya bertahan 1.5-2 tahun. Sudah waktunya diperiksa.',
          urgent: monthsSince >= 24,
        });
      }
    }

    res.json({ vehicle, reminders });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Gagal mengambil pengingat servis.' });
  }
}

// GET /api/vehicles/:id/history - riwayat servis kendaraan
async function getServiceHistory(req, res) {
  const { id } = req.params;
  try {
    const owned = await pool.query('SELECT id FROM vehicles WHERE id = $1 AND user_id = $2', [
      id,
      req.user.id,
    ]);
    if (owned.rows.length === 0) return res.status(404).json({ message: 'Kendaraan tidak ditemukan.' });

    const { rows } = await pool.query(
      'SELECT * FROM service_history WHERE vehicle_id = $1 ORDER BY service_date DESC',
      [id]
    );
    res.json(rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Gagal mengambil riwayat servis.' });
  }
}

// POST /api/vehicles/:id/history - catat servis baru (sekaligus update last_service_km/date)
async function addServiceHistory(req, res) {
  const { id } = req.params;
  const { workshop_id, service_type, odometer, cost, notes, service_date } = req.body;
  if (!service_type || odometer === undefined) {
    return res.status(400).json({ message: 'service_type dan odometer wajib diisi.' });
  }
  try {
    const owned = await pool.query('SELECT id FROM vehicles WHERE id = $1 AND user_id = $2', [
      id,
      req.user.id,
    ]);
    if (owned.rows.length === 0) return res.status(404).json({ message: 'Kendaraan tidak ditemukan.' });

    const { rows } = await pool.query(
      `INSERT INTO service_history (vehicle_id, workshop_id, service_type, odometer, cost, notes, service_date)
       VALUES ($1, $2, $3, $4, $5, $6, COALESCE($7, CURRENT_DATE)) RETURNING *`,
      [id, workshop_id || null, service_type, odometer, cost || null, notes || null, service_date || null]
    );

    await pool.query(
      `UPDATE vehicles SET last_service_km = $1, last_service_date = COALESCE($2, CURRENT_DATE), current_kilometer = GREATEST(current_kilometer, $1)
       WHERE id = $3`,
      [odometer, service_date || null, id]
    );

    res.status(201).json(rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Gagal mencatat riwayat servis.' });
  }
}

module.exports = {
  listVehicles,
  addVehicle,
  updateVehicle,
  deleteVehicle,
  updateOdometer,
  getReminders,
  getServiceHistory,
  addServiceHistory,
};
