process.env.JWT_SECRET = 'test-secret-key-for-unit-tests';

// Item "belum dikerjakan" #6: controller yang butuh Postgres belum ada test
// integrasinya karena sandbox tidak punya Postgres sungguhan. Pendekatan di
// sini adalah MOCK `pool.query` (bukan test integrasi ke Postgres asli),
// supaya logika controller (validasi, status code, bentuk response) tetap
// bisa diverifikasi otomatis tanpa database. Ini BUKAN pengganti test
// integrasi sungguhan (mis. dengan Postgres di container CI atau `pg-mem`)
// yang disebutkan sebagai langkah lanjutan di otoshield_blueprint.md.
jest.mock('../config/db', () => ({ query: jest.fn() }));
const pool = require('../config/db');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { register, login, getProfile, updateProfile } = require('./auth.controller');

function mockRes() {
  const res = {};
  res.status = jest.fn().mockReturnValue(res);
  res.json = jest.fn().mockReturnValue(res);
  res.send = jest.fn().mockReturnValue(res);
  return res;
}

beforeEach(() => {
  pool.query.mockReset();
});

describe('auth.controller register', () => {
  test('menolak jika field wajib kosong', async () => {
    const req = { body: { name: 'Budi' } };
    const res = mockRes();

    await register(req, res);

    expect(res.status).toHaveBeenCalledWith(400);
    expect(pool.query).not.toHaveBeenCalled();
  });

  test('menolak jika nomor telepon sudah terdaftar', async () => {
    pool.query.mockResolvedValueOnce({ rows: [{ id: 'existing-id' }] });
    const req = { body: { name: 'Budi', phone: '0812', password: 'rahasia123' } };
    const res = mockRes();

    await register(req, res);

    expect(res.status).toHaveBeenCalledWith(409);
  });

  test('berhasil mendaftar dan mengembalikan token JWT bertipe user', async () => {
    pool.query
      .mockResolvedValueOnce({ rows: [] }) // cek nomor belum ada
      .mockResolvedValueOnce({
        rows: [{ id: 'user-1', name: 'Budi', phone: '0812', email: null, created_at: new Date() }],
      });
    const req = { body: { name: 'Budi', phone: '0812', password: 'rahasia123' } };
    const res = mockRes();

    await register(req, res);

    expect(res.status).toHaveBeenCalledWith(201);
    const payload = res.json.mock.calls[0][0];
    expect(payload.user.id).toBe('user-1');
    const decoded = jwt.verify(payload.token, process.env.JWT_SECRET);
    expect(decoded).toMatchObject({ id: 'user-1', type: 'user' });
  });
});

describe('auth.controller login', () => {
  test('menolak jika pengguna tidak ditemukan', async () => {
    pool.query.mockResolvedValueOnce({ rows: [] });
    const req = { body: { phone: '0812', password: 'rahasia123' } };
    const res = mockRes();

    await login(req, res);

    expect(res.status).toHaveBeenCalledWith(401);
  });

  test('menolak jika password salah', async () => {
    const hash = await bcrypt.hash('password-benar', 10);
    pool.query.mockResolvedValueOnce({ rows: [{ id: 'user-1', phone: '0812', password_hash: hash }] });
    const req = { body: { phone: '0812', password: 'password-salah' } };
    const res = mockRes();

    await login(req, res);

    expect(res.status).toHaveBeenCalledWith(401);
  });

  test('berhasil login dengan password benar', async () => {
    const hash = await bcrypt.hash('password-benar', 10);
    pool.query.mockResolvedValueOnce({ rows: [{ id: 'user-1', phone: '0812', password_hash: hash }] });
    const req = { body: { phone: '0812', password: 'password-benar' } };
    const res = mockRes();

    await login(req, res);

    expect(res.status).not.toHaveBeenCalledWith(401);
    const payload = res.json.mock.calls[0][0];
    expect(payload.token).toBeDefined();
    expect(payload.user.password_hash).toBeUndefined();
  });
});

describe('auth.controller getProfile / updateProfile', () => {
  test('getProfile mengembalikan 404 jika pengguna tidak ada', async () => {
    pool.query.mockResolvedValueOnce({ rows: [] });
    const req = { user: { id: 'user-x' } };
    const res = mockRes();

    await getProfile(req, res);

    expect(res.status).toHaveBeenCalledWith(404);
  });

  test('getProfile mengembalikan data profil', async () => {
    pool.query.mockResolvedValueOnce({ rows: [{ id: 'user-1', name: 'Budi' }] });
    const req = { user: { id: 'user-1' } };
    const res = mockRes();

    await getProfile(req, res);

    expect(res.json).toHaveBeenCalledWith({ id: 'user-1', name: 'Budi' });
  });

  test('updateProfile menolak jika tidak ada field yang diisi', async () => {
    const req = { user: { id: 'user-1' }, body: {} };
    const res = mockRes();

    await updateProfile(req, res);

    expect(res.status).toHaveBeenCalledWith(400);
    expect(pool.query).not.toHaveBeenCalled();
  });

  test('updateProfile menolak jika nomor telepon baru sudah dipakai user lain', async () => {
    pool.query.mockResolvedValueOnce({ rows: [{ id: 'user-2' }] });
    const req = { user: { id: 'user-1' }, body: { phone: '0899' } };
    const res = mockRes();

    await updateProfile(req, res);

    expect(res.status).toHaveBeenCalledWith(409);
  });

  test('updateProfile berhasil memperbarui nama', async () => {
    pool.query.mockResolvedValueOnce({
      rows: [{ id: 'user-1', name: 'Budi Baru', phone: '0812', email: null }],
    });
    const req = { user: { id: 'user-1' }, body: { name: 'Budi Baru' } };
    const res = mockRes();

    await updateProfile(req, res);

    expect(res.status).not.toHaveBeenCalledWith(400);
    expect(res.json).toHaveBeenCalledWith(
      expect.objectContaining({ name: 'Budi Baru' })
    );
  });
});
