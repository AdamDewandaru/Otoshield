const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const pool = require('../config/db');
require('dotenv').config();

// POST /api/auth/register
async function register(req, res) {
  const { name, phone, email, password } = req.body;
  if (!name || !phone || !password) {
    return res.status(400).json({ message: 'name, phone, dan password wajib diisi.' });
  }

  try {
    const existing = await pool.query('SELECT id FROM users WHERE phone = $1', [phone]);
    if (existing.rows.length > 0) {
      return res.status(409).json({ message: 'Nomor telepon sudah terdaftar.' });
    }

    const passwordHash = await bcrypt.hash(password, 10);
    const result = await pool.query(
      `INSERT INTO users (name, phone, email, password_hash)
       VALUES ($1, $2, $3, $4) RETURNING id, name, phone, email, created_at`,
      [name, phone, email || null, passwordHash]
    );

    const user = result.rows[0];
    const token = jwt.sign({ id: user.id, phone: user.phone, type: 'user' }, process.env.JWT_SECRET, {
      expiresIn: process.env.JWT_EXPIRES_IN || '7d',
    });

    res.status(201).json({ user, token });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Gagal mendaftarkan pengguna.' });
  }
}

// POST /api/auth/login
async function login(req, res) {
  const { phone, password } = req.body;
  if (!phone || !password) {
    return res.status(400).json({ message: 'phone dan password wajib diisi.' });
  }

  try {
    const result = await pool.query('SELECT * FROM users WHERE phone = $1', [phone]);
    const user = result.rows[0];
    if (!user) {
      return res.status(401).json({ message: 'Nomor telepon atau password salah.' });
    }

    const validPassword = await bcrypt.compare(password, user.password_hash);
    if (!validPassword) {
      return res.status(401).json({ message: 'Nomor telepon atau password salah.' });
    }

    const token = jwt.sign({ id: user.id, phone: user.phone, type: 'user' }, process.env.JWT_SECRET, {
      expiresIn: process.env.JWT_EXPIRES_IN || '7d',
    });

    delete user.password_hash;
    res.json({ user, token });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Gagal login.' });
  }
}

// GET /api/auth/me - lihat profil pengguna yang sedang login (item "belum dikerjakan" #8)
async function getProfile(req, res) {
  try {
    const { rows } = await pool.query(
      'SELECT id, name, phone, email, created_at FROM users WHERE id = $1',
      [req.user.id]
    );
    if (rows.length === 0) return res.status(404).json({ message: 'Pengguna tidak ditemukan.' });
    res.json(rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Gagal mengambil profil.' });
  }
}

// PUT /api/auth/me - edit nama/email/telepon (item "belum dikerjakan" #8)
async function updateProfile(req, res) {
  const { name, email, phone } = req.body;
  if (!name && !email && !phone) {
    return res.status(400).json({ message: 'Isi minimal satu field: name, email, atau phone.' });
  }

  try {
    if (phone) {
      const existing = await pool.query('SELECT id FROM users WHERE phone = $1 AND id != $2', [
        phone,
        req.user.id,
      ]);
      if (existing.rows.length > 0) {
        return res.status(409).json({ message: 'Nomor telepon sudah dipakai pengguna lain.' });
      }
    }

    const { rows } = await pool.query(
      `UPDATE users SET
         name = COALESCE($1, name),
         email = COALESCE($2, email),
         phone = COALESCE($3, phone)
       WHERE id = $4
       RETURNING id, name, phone, email, created_at`,
      [name || null, email || null, phone || null, req.user.id]
    );
    if (rows.length === 0) return res.status(404).json({ message: 'Pengguna tidak ditemukan.' });
    res.json(rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Gagal memperbarui profil.' });
  }
}

module.exports = { register, login, getProfile, updateProfile };
