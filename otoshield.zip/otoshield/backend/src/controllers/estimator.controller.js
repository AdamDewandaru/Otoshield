const { estimateCost } = require('../utils/estimatorRules');

// POST /api/estimator/estimate  { symptom_text: "rem bunyi berdecit" }
async function estimate(req, res) {
  const { symptom_text } = req.body;
  if (!symptom_text || symptom_text.trim().length < 3) {
    return res.status(400).json({ message: 'symptom_text wajib diisi (minimal 3 karakter).' });
  }
  try {
    const result = await estimateCost(symptom_text);
    res.json(result);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Gagal menghitung estimasi biaya.' });
  }
}

module.exports = { estimate };
