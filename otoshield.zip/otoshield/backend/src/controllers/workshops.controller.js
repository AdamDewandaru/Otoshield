const pool = require('../config/db');
const { haversineDistanceKm } = require('../utils/haversine');

// GET /api/workshops?lat=&lng=&radius=&verified_only=true
async function listWorkshops(req, res) {
  const { lat, lng, radius, verified_only } = req.query;
  try {
    let query = 'SELECT * FROM workshops';
    const conditions = [];
    const params = [];

    if (verified_only === 'true') {
      conditions.push('is_verified = TRUE');
    }
    if (conditions.length) query += ' WHERE ' + conditions.join(' AND ');
    query += ' ORDER BY rating DESC';

    const { rows } = await pool.query(query, params);

    let result = rows;
    if (lat && lng) {
      const userLat = parseFloat(lat);
      const userLng = parseFloat(lng);
      const radiusKm = radius ? parseFloat(radius) : 10;

      result = rows
        .map((w) => ({
          ...w,
          distance_km: haversineDistanceKm(userLat, userLng, parseFloat(w.latitude), parseFloat(w.longitude)),
        }))
        .filter((w) => w.distance_km <= radiusKm)
        .sort((a, b) => a.distance_km - b.distance_km);
    }

    res.json(result);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Gagal mengambil daftar bengkel.' });
  }
}

// GET /api/workshops/:id - detail bengkel + daftar harga jasa + review
async function getWorkshopDetail(req, res) {
  const { id } = req.params;
  try {
    const workshopResult = await pool.query('SELECT * FROM workshops WHERE id = $1', [id]);
    if (workshopResult.rows.length === 0) {
      return res.status(404).json({ message: 'Bengkel tidak ditemukan.' });
    }

    const servicesResult = await pool.query(
      'SELECT * FROM workshop_services WHERE workshop_id = $1 ORDER BY service_name',
      [id]
    );
    const reviewsResult = await pool.query(
      `SELECT r.id, r.rating, r.comment, r.created_at, u.name AS user_name
       FROM reviews r JOIN users u ON u.id = r.user_id
       WHERE r.workshop_id = $1 ORDER BY r.created_at DESC LIMIT 20`,
      [id]
    );

    res.json({
      ...workshopResult.rows[0],
      services: servicesResult.rows,
      reviews: reviewsResult.rows,
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Gagal mengambil detail bengkel.' });
  }
}

// POST /api/workshops/:id/reviews - beri rating & ulasan (butuh login)
async function addReview(req, res) {
  const { id } = req.params;
  const { rating, comment } = req.body;
  if (!rating || rating < 1 || rating > 5) {
    return res.status(400).json({ message: 'rating wajib diisi (1-5).' });
  }
  try {
    const { rows } = await pool.query(
      `INSERT INTO reviews (workshop_id, user_id, rating, comment)
       VALUES ($1, $2, $3, $4) RETURNING *`,
      [id, req.user.id, rating, comment || null]
    );

    // update rating rata-rata bengkel
    await pool.query(
      `UPDATE workshops SET
         rating = (SELECT AVG(rating) FROM reviews WHERE workshop_id = $1),
         rating_count = (SELECT COUNT(*) FROM reviews WHERE workshop_id = $1)
       WHERE id = $1`,
      [id]
    );

    res.status(201).json(rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Gagal menambahkan ulasan.' });
  }
}

module.exports = { listWorkshops, getWorkshopDetail, addReview };
