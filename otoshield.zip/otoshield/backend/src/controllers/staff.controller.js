const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const pool = require('../config/db');
require('dotenv').config();

const VALID_ROLES = ['ADMIN', 'WORKSHOP_STAFF', 'MECHANIC'];

function signStaffToken(staff) {
  return jwt.sign(
    { id: staff.id, phone: staff.phone, role: staff.role, workshop_id: staff.workshop_id, type: 'staff' },
    process.env.JWT_SECRET,
    { expiresIn: process.env.JWT_EXPIRES_IN || '7d' }
  );
}

// POST /api/staff/login
async function loginStaff(req, res) {
  const { phone, password } = req.body;
  if (!phone || !password) {
    return res.status(400).json({ message: 'phone dan password wajib diisi.' });
  }

  try {
    const result = await pool.query('SELECT * FROM staff_accounts WHERE phone = $1', [phone]);
    const staff = result.rows[0];
    if (!staff || !staff.is_active) {
      return res.status(401).json({ message: 'Nomor telepon atau password salah.' });
    }

    const validPassword = await bcrypt.compare(password, staff.password_hash);
    if (!validPassword) {
      return res.status(401).json({ message: 'Nomor telepon atau password salah.' });
    }

    const token = signStaffToken(staff);
    delete staff.password_hash;
    res.json({ staff, token });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Gagal login staf.' });
  }
}

// POST /api/staff - buat akun staf baru (hanya oleh ADMIN atau shared admin key lama)
async function createStaff(req, res) {
  const { name, phone, email, password, role, workshop_id } = req.body;
  if (!name || !phone || !password) {
    return res.status(400).json({ message: 'name, phone, dan password wajib diisi.' });
  }
  const finalRole = role || 'MECHANIC';
  if (!VALID_ROLES.includes(finalRole)) {
    return res.status(400).json({ message: `role harus salah satu dari: ${VALID_ROLES.join(', ')}` });
  }

  try {
    const existing = await pool.query('SELECT id FROM staff_accounts WHERE phone = $1', [phone]);
    if (existing.rows.length > 0) {
      return res.status(409).json({ message: 'Nomor telepon staf sudah terdaftar.' });
    }

    const passwordHash = await bcrypt.hash(password, 10);
    const { rows } = await pool.query(
      `INSERT INTO staff_accounts (name, phone, email, password_hash, role, workshop_id)
       VALUES ($1, $2, $3, $4, $5, $6)
       RETURNING id, name, phone, email, role, workshop_id, is_active, created_at`,
      [name, phone, email || null, passwordHash, finalRole, workshop_id || null]
    );

    res.status(201).json(rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Gagal membuat akun staf.' });
  }
}

// GET /api/staff - daftar staf (untuk manajemen oleh ADMIN)
async function listStaff(req, res) {
  try {
    const { rows } = await pool.query(
      `SELECT id, name, phone, email, role, workshop_id, is_active, created_at
       FROM staff_accounts ORDER BY created_at DESC`
    );
    res.json(rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Gagal mengambil daftar staf.' });
  }
}

module.exports = { loginStaff, createStaff, listStaff };
