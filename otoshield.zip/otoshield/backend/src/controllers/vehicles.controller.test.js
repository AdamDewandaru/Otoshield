jest.mock('../config/db', () => ({ query: jest.fn() }));
const pool = require('../config/db');
const { listVehicles, addVehicle, updateVehicle, deleteVehicle } = require('./vehicles.controller');

function mockRes() {
  const res = {};
  res.status = jest.fn().mockReturnValue(res);
  res.json = jest.fn().mockReturnValue(res);
  res.send = jest.fn().mockReturnValue(res);
  return res;
}

beforeEach(() => {
  pool.query.mockReset();
});

test('listVehicles mengembalikan kendaraan milik user yang login', async () => {
  pool.query.mockResolvedValueOnce({ rows: [{ id: 'v1' }] });
  const req = { user: { id: 'user-1' } };
  const res = mockRes();

  await listVehicles(req, res);

  expect(pool.query).toHaveBeenCalledWith(expect.any(String), ['user-1']);
  expect(res.json).toHaveBeenCalledWith([{ id: 'v1' }]);
});

test('addVehicle menolak jika brand/model kosong', async () => {
  const req = { user: { id: 'user-1' }, body: { model: 'Avanza' } };
  const res = mockRes();

  await addVehicle(req, res);

  expect(res.status).toHaveBeenCalledWith(400);
  expect(pool.query).not.toHaveBeenCalled();
});

test('addVehicle berhasil menambah kendaraan baru', async () => {
  pool.query.mockResolvedValueOnce({ rows: [{ id: 'v1', brand: 'Toyota', model: 'Avanza' }] });
  const req = {
    user: { id: 'user-1' },
    body: { brand: 'Toyota', model: 'Avanza', year: 2020, license_plate: 'B 1234 XYZ', current_kilometer: 15000 },
  };
  const res = mockRes();

  await addVehicle(req, res);

  expect(res.status).toHaveBeenCalledWith(201);
});

test('updateVehicle mengembalikan 404 jika kendaraan bukan milik user / tidak ada', async () => {
  pool.query.mockResolvedValueOnce({ rows: [] });
  const req = { user: { id: 'user-1' }, params: { id: 'v-x' }, body: { brand: 'Honda' } };
  const res = mockRes();

  await updateVehicle(req, res);

  expect(res.status).toHaveBeenCalledWith(404);
});

test('updateVehicle menolak jika tidak ada field yang diisi', async () => {
  const req = { user: { id: 'user-1' }, params: { id: 'v1' }, body: {} };
  const res = mockRes();

  await updateVehicle(req, res);

  expect(res.status).toHaveBeenCalledWith(400);
  expect(pool.query).not.toHaveBeenCalled();
});

test('deleteVehicle mengembalikan 204 jika berhasil', async () => {
  pool.query.mockResolvedValueOnce({ rows: [{ id: 'v1' }] });
  const req = { user: { id: 'user-1' }, params: { id: 'v1' } };
  const res = mockRes();

  await deleteVehicle(req, res);

  expect(res.status).toHaveBeenCalledWith(204);
});

test('deleteVehicle mengembalikan 404 jika kendaraan tidak ditemukan', async () => {
  pool.query.mockResolvedValueOnce({ rows: [] });
  const req = { user: { id: 'user-1' }, params: { id: 'v-x' } };
  const res = mockRes();

  await deleteVehicle(req, res);

  expect(res.status).toHaveBeenCalledWith(404);
});
