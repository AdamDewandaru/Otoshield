process.env.JWT_SECRET = 'test-secret-key-for-unit-tests';

jest.mock('../config/db', () => ({ query: jest.fn() }));
const pool = require('../config/db');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { loginStaff, createStaff, listStaff } = require('./staff.controller');

function mockRes() {
  const res = {};
  res.status = jest.fn().mockReturnValue(res);
  res.json = jest.fn().mockReturnValue(res);
  return res;
}

beforeEach(() => {
  pool.query.mockReset();
});

describe('staff.controller loginStaff', () => {
  test('menolak jika staf tidak ditemukan', async () => {
    pool.query.mockResolvedValueOnce({ rows: [] });
    const req = { body: { phone: '0812', password: 'rahasia123' } };
    const res = mockRes();

    await loginStaff(req, res);

    expect(res.status).toHaveBeenCalledWith(401);
  });

  test('menolak jika akun staf nonaktif', async () => {
    const hash = await bcrypt.hash('rahasia123', 10);
    pool.query.mockResolvedValueOnce({
      rows: [{ id: 'staff-1', phone: '0812', password_hash: hash, is_active: false, role: 'MECHANIC' }],
    });
    const req = { body: { phone: '0812', password: 'rahasia123' } };
    const res = mockRes();

    await loginStaff(req, res);

    expect(res.status).toHaveBeenCalledWith(401);
  });

  test('berhasil login dan token berisi claim type: staff + role', async () => {
    const hash = await bcrypt.hash('rahasia123', 10);
    pool.query.mockResolvedValueOnce({
      rows: [
        {
          id: 'staff-1',
          phone: '0812',
          password_hash: hash,
          is_active: true,
          role: 'ADMIN',
          workshop_id: null,
        },
      ],
    });
    const req = { body: { phone: '0812', password: 'rahasia123' } };
    const res = mockRes();

    await loginStaff(req, res);

    const payload = res.json.mock.calls[0][0];
    const decoded = jwt.verify(payload.token, process.env.JWT_SECRET);
    expect(decoded).toMatchObject({ id: 'staff-1', role: 'ADMIN', type: 'staff' });
    expect(payload.staff.password_hash).toBeUndefined();
  });
});

describe('staff.controller createStaff', () => {
  test('menolak jika field wajib kosong', async () => {
    const req = { body: { name: 'Andi' } };
    const res = mockRes();

    await createStaff(req, res);

    expect(res.status).toHaveBeenCalledWith(400);
  });

  test('menolak role yang tidak valid', async () => {
    const req = { body: { name: 'Andi', phone: '0812', password: 'rahasia123', role: 'SUPERUSER' } };
    const res = mockRes();

    await createStaff(req, res);

    expect(res.status).toHaveBeenCalledWith(400);
    expect(pool.query).not.toHaveBeenCalled();
  });

  test('menolak jika nomor telepon staf sudah terdaftar', async () => {
    pool.query.mockResolvedValueOnce({ rows: [{ id: 'staff-existing' }] });
    const req = { body: { name: 'Andi', phone: '0812', password: 'rahasia123' } };
    const res = mockRes();

    await createStaff(req, res);

    expect(res.status).toHaveBeenCalledWith(409);
  });

  test('berhasil membuat staf baru dengan role default MECHANIC', async () => {
    pool.query
      .mockResolvedValueOnce({ rows: [] })
      .mockResolvedValueOnce({ rows: [{ id: 'staff-1', name: 'Andi', role: 'MECHANIC' }] });
    const req = { body: { name: 'Andi', phone: '0812', password: 'rahasia123' } };
    const res = mockRes();

    await createStaff(req, res);

    expect(res.status).toHaveBeenCalledWith(201);
  });
});

describe('staff.controller listStaff', () => {
  test('mengembalikan daftar staf', async () => {
    pool.query.mockResolvedValueOnce({ rows: [{ id: 'staff-1' }, { id: 'staff-2' }] });
    const req = {};
    const res = mockRes();

    await listStaff(req, res);

    expect(res.json).toHaveBeenCalledWith([{ id: 'staff-1' }, { id: 'staff-2' }]);
  });
});
