const express = require('express');
const router = express.Router();
const auth = require('../middleware/auth.middleware');
const { emergencyCreateLimiter } = require('../middleware/rateLimit.middleware');
const { uploadEmergencyPhoto } = require('../middleware/upload.middleware');
const { createEmergency, getEmergency, updateStatus, uploadPhoto } = require('../controllers/emergency.controller');

// io (socket.io instance) disimpan di app.locals oleh server.js,
// diteruskan ke controller agar bisa broadcast realtime.
// emergencyCreateLimiter (Sesi 9) - cegah spam permintaan SOS palsu yang
// membebani mekanik/bengkel sungguhan (lihat middleware/rateLimit.middleware.js).
router.post('/', auth, emergencyCreateLimiter, (req, res) => createEmergency(req, res, req.app.get('io')));
router.get('/:id', auth, getEmergency);
router.put('/:id/status', auth, (req, res) => updateStatus(req, res, req.app.get('io')));
router.post(
  '/:id/photo',
  auth,
  (req, res, next) => {
    // Bug ditemukan Sesi 4 lewat test integrasi: tanpa wrapper ini, error dari
    // fileFilter/limits multer (mis. tipe file salah, ukuran > 5MB) jatuh ke
    // error handler umum di app.js dan balik sebagai 500 "Terjadi kesalahan
    // pada server" - padahal ini kesalahan INPUT pengguna (400), bukan
    // kegagalan server. Wrapper ini menangkap error multer secara spesifik
    // dan membalasnya sebagai 400 dengan pesan yang jelas.
    uploadEmergencyPhoto.single('photo')(req, res, (err) => {
      if (err) {
        return res.status(400).json({ message: err.message || 'Gagal mengunggah file.' });
      }
      next();
    });
  },
  (req, res) => uploadPhoto(req, res, req.app.get('io'))
);

module.exports = router;
