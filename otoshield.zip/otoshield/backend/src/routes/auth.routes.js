const express = require('express');
const router = express.Router();
const auth = require('../middleware/auth.middleware');
const { authLimiter } = require('../middleware/rateLimit.middleware');
const { register, login, getProfile, updateProfile } = require('../controllers/auth.controller');

// authLimiter (Sesi 9) - mencegah brute-force password lewat percobaan login
// bertubi-tubi; skipSuccessfulRequests membuat login yang benar tidak ikut
// dihitung, jadi pengguna sah tidak akan pernah kena limit ini.
router.post('/register', authLimiter, register);
router.post('/login', authLimiter, login);

// Profil pengguna (item "belum dikerjakan" #8: edit nama/email/telepon)
router.get('/me', auth, getProfile);
router.put('/me', auth, updateProfile);

module.exports = router;
