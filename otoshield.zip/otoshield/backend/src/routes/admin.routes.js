const express = require('express');
const router = express.Router();
// Sesi 3: diganti dari admin.middleware.js (hanya shared key) ke adminOrStaff.middleware.js
// (menerima shared key LAMA *atau* token staf JWT baru) supaya dashboard tetap kompatibel
// sambil menambah audit trail "siapa mengubah apa" untuk staf yang sudah login individual.
const adminAuth = require('../middleware/adminOrStaff.middleware');
const { listEmergencies, updateStatus } = require('../controllers/emergency.controller');
const { listWorkshops } = require('../controllers/workshops.controller');

// Dipakai oleh dashboard mekanik/operator statis di /mechanic (lihat public/mechanic-dashboard)
router.get('/emergency', adminAuth, listEmergencies);
router.put('/emergency/:id/status', adminAuth, (req, res) => updateStatus(req, res, req.app.get('io')));
router.get('/workshops', adminAuth, listWorkshops);

module.exports = router;
