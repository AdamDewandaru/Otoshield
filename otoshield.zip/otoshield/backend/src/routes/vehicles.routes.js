const express = require('express');
const router = express.Router();
const auth = require('../middleware/auth.middleware');
const {
  listVehicles,
  addVehicle,
  updateVehicle,
  deleteVehicle,
  updateOdometer,
  getReminders,
  getServiceHistory,
  addServiceHistory,
} = require('../controllers/vehicles.controller');

router.use(auth); // semua endpoint kendaraan butuh login

router.get('/', listVehicles);
router.post('/', addVehicle);
router.put('/:id', updateVehicle);
router.delete('/:id', deleteVehicle);
router.put('/:id/odometer', updateOdometer);
router.get('/:id/reminders', getReminders);
router.get('/:id/history', getServiceHistory);
router.post('/:id/history', addServiceHistory);

module.exports = router;
