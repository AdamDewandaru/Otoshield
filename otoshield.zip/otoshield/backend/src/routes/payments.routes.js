const express = require('express');
const router = express.Router();
const auth = require('../middleware/auth.middleware');
const {
  createPayment,
  getPayment,
  listMyPayments,
  confirmCashPayment,
  handleMidtransWebhook,
} = require('../controllers/payments.controller');

// Webhook TANPA auth middleware - dipanggil oleh gateway, diamankan lewat
// verifikasi signature_key di dalam handleMidtransWebhook (lihat controller).
router.post('/webhook/midtrans', handleMidtransWebhook);

router.post('/', auth, createPayment);
router.get('/', auth, listMyPayments);
router.get('/:id', auth, getPayment);
router.put('/:id/confirm-cash', auth, confirmCashPayment);

module.exports = router;
