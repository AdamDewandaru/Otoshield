const express = require('express');
const router = express.Router();
const auth = require('../middleware/auth.middleware');
const { listWorkshops, getWorkshopDetail, addReview } = require('../controllers/workshops.controller');

router.get('/', listWorkshops);              // publik, tidak perlu login
router.get('/:id', getWorkshopDetail);       // publik
router.post('/:id/reviews', auth, addReview); // butuh login

module.exports = router;
