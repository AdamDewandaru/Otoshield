const express = require('express');
const router = express.Router();
const adminOrStaff = require('../middleware/adminOrStaff.middleware');
const { authLimiter } = require('../middleware/rateLimit.middleware');
const { loginStaff, createStaff, listStaff } = require('../controllers/staff.controller');

// Publik: staf login pakai phone+password, dapat token JWT bertipe 'staff'
// authLimiter (Sesi 9) - sama alasannya dengan auth.routes.js: cegah brute-force.
router.post('/login', authLimiter, loginStaff);

// Membuat & melihat daftar staf hanya boleh oleh ADMIN (atau shared ADMIN_API_KEY lama,
// dipakai untuk "bootstrap" akun ADMIN pertama sebelum ada staf sama sekali).
router.post('/', adminOrStaff, (req, res, next) => {
  if (req.staff && req.staff.role !== 'ADMIN') {
    return res.status(403).json({ message: 'Hanya staf role ADMIN yang boleh membuat akun staf baru.' });
  }
  next();
}, createStaff);

router.get('/', adminOrStaff, (req, res, next) => {
  if (req.staff && req.staff.role !== 'ADMIN') {
    return res.status(403).json({ message: 'Hanya staf role ADMIN yang boleh melihat daftar staf.' });
  }
  next();
}, listStaff);

module.exports = router;
