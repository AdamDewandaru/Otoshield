const express = require('express');
const router = express.Router();
const { estimate } = require('../controllers/estimator.controller');

// Estimator bisa diakses tanpa login supaya calon pengguna juga bisa coba
router.post('/estimate', estimate);

module.exports = router;
