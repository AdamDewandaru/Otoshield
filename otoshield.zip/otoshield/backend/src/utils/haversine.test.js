const { haversineDistanceKm } = require('./haversine');

describe('haversineDistanceKm', () => {
  test('jarak titik yang sama adalah 0', () => {
    expect(haversineDistanceKm(-6.2, 106.8, -6.2, 106.8)).toBeCloseTo(0, 5);
  });

  test('jarak Jakarta ke Bandung sekitar 115-125 km', () => {
    // Monas (-6.1754, 106.8272) -> Gedung Sate Bandung (-6.9024, 107.6186)
    const distance = haversineDistanceKm(-6.1754, 106.8272, -6.9024, 107.6186);
    expect(distance).toBeGreaterThan(110);
    expect(distance).toBeLessThan(130);
  });

  test('jarak bersifat simetris (A->B sama dengan B->A)', () => {
    const ab = haversineDistanceKm(-6.2, 106.8, -7.25, 112.75);
    const ba = haversineDistanceKm(-7.25, 112.75, -6.2, 106.8);
    expect(ab).toBeCloseTo(ba, 8);
  });

  test('jarak dekat (radius pencarian bengkel/mekanik) terhitung wajar dalam km', () => {
    // dua titik yang hanya berjarak sekitar 0.01 derajat lintang (~1.1 km)
    const distance = haversineDistanceKm(-6.2, 106.8, -6.21, 106.8);
    expect(distance).toBeGreaterThan(0.5);
    expect(distance).toBeLessThan(2);
  });
});
