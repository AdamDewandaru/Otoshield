const pool = require('../config/db');

/**
 * Smart Cost Estimator - mesin pencocokan kata kunci sederhana.
 * Mencocokkan teks gejala yang diketik pengguna terhadap tabel
 * cost_estimate_rules, lalu mengembalikan kisaran biaya wajar.
 *
 * Pendekatan: normalisasi teks lalu cek apakah setiap keyword
 * referensi menjadi substring dari teks gejala (atau sebaliknya).
 * Jika ada beberapa kecocokan, kembalikan yang paling relevan
 * (jumlah kata yang cocok terbanyak) dan sertakan alternatif lain.
 */
/**
 * Fungsi murni (pure function) - tidak menyentuh database, sehingga mudah
 * di-unit-test dengan data tiruan (lihat estimatorRules.test.js).
 * Menerima teks gejala + daftar rules, mengembalikan kecocokan terbaik.
 */
function matchRules(symptomText, rules) {
  const normalized = (symptomText || '').toLowerCase().trim();

  const matches = rules
    .map((rule) => {
      const keywordWords = rule.keyword.toLowerCase().split(' ');
      const matchedWordsCount = keywordWords.filter((w) => normalized.includes(w)).length;
      return { rule, score: matchedWordsCount / keywordWords.length };
    })
    .filter((m) => m.score > 0)
    .sort((a, b) => b.score - a.score);

  if (matches.length === 0) {
    return {
      matched: false,
      message:
        'Gejala belum dikenali sistem. Coba deskripsikan dengan kata kunci lain (contoh: "rem berdecit", "mesin overheat").',
      alternatives: [],
    };
  }

  const best = matches[0].rule;
  const alternatives = matches.slice(1, 4).map((m) => ({
    issue_category: m.rule.issue_category,
    estimated_min: m.rule.estimated_min,
    estimated_max: m.rule.estimated_max,
  }));

  return {
    matched: true,
    issue_category: best.issue_category,
    estimated_min: best.estimated_min,
    estimated_max: best.estimated_max,
    alternatives,
  };
}

/**
 * Wrapper yang mengambil rules dari database lalu memanggil matchRules().
 * Dipakai oleh controller (butuh koneksi DB asli).
 */
async function estimateCost(symptomText) {
  const { rows } = await pool.query('SELECT * FROM cost_estimate_rules');
  return matchRules(symptomText, rows);
}

module.exports = { estimateCost, matchRules };
