const { matchRules } = require('./estimatorRules');

const sampleRules = [
  { keyword: 'rem berdecit', issue_category: 'Kampas rem aus', estimated_min: 150000, estimated_max: 350000 },
  { keyword: 'mesin overheat', issue_category: 'Sistem pendingin', estimated_min: 300000, estimated_max: 1200000 },
  { keyword: 'mesin getar ac', issue_category: 'Kompresor AC / mounting mesin', estimated_min: 250000, estimated_max: 900000 },
  { keyword: 'ban bocor', issue_category: 'Tambal ban / ganti ban', estimated_min: 20000, estimated_max: 400000 },
];

describe('matchRules (Smart Cost Estimator)', () => {
  test('mengembalikan matched=false jika tidak ada kata kunci cocok sama sekali', () => {
    const result = matchRules('lampu depan mati sebelah', sampleRules);
    expect(result.matched).toBe(false);
    expect(result.alternatives).toEqual([]);
  });

  test('mencocokkan gejala persis dengan salah satu keyword', () => {
    const result = matchRules('rem bunyi berdecit terus', sampleRules);
    expect(result.matched).toBe(true);
    expect(result.issue_category).toBe('Kampas rem aus');
    expect(result.estimated_min).toBe(150000);
    expect(result.estimated_max).toBe(350000);
  });

  test('mencocokkan gejala dari blueprint: "mesin getar saat AC nyala"', () => {
    const result = matchRules('mesin getar saat AC nyala', sampleRules);
    expect(result.matched).toBe(true);
    expect(result.issue_category).toBe('Kompresor AC / mounting mesin');
  });

  test('tidak peka huruf besar/kecil (case-insensitive)', () => {
    const result = matchRules('MESIN OVERHEAT PARAH', sampleRules);
    expect(result.matched).toBe(true);
    expect(result.issue_category).toBe('Sistem pendingin');
  });

  test('memilih kecocokan dengan skor tertinggi dan menyertakan alternatif lain', () => {
    // "mesin" muncul di 2 rule (overheat & getar ac), tapi hanya salah satu
    // yang lebih lengkap kata kuncinya cocok -> harus pilih skor tertinggi.
    const result = matchRules('mesin overheat dan mesin juga getar', sampleRules);
    expect(result.matched).toBe(true);
    expect(result.issue_category).toBe('Sistem pendingin');
    expect(Array.isArray(result.alternatives)).toBe(true);
  });

  test('menangani teks kosong tanpa error', () => {
    const result = matchRules('', sampleRules);
    expect(result.matched).toBe(false);
  });

  test('menangani daftar rules kosong tanpa error', () => {
    const result = matchRules('ban bocor', []);
    expect(result.matched).toBe(false);
  });
});
