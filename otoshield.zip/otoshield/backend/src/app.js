require('dotenv').config();
const path = require('path');
const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const compression = require('compression');
const morgan = require('morgan');

const { resolveCorsOrigin } = require('./config/corsOrigin');
const { generalApiLimiter } = require('./middleware/rateLimit.middleware');

const authRoutes = require('./routes/auth.routes');
const vehiclesRoutes = require('./routes/vehicles.routes');
const workshopsRoutes = require('./routes/workshops.routes');
const emergencyRoutes = require('./routes/emergency.routes');
const estimatorRoutes = require('./routes/estimator.routes');
const paymentsRoutes = require('./routes/payments.routes');
const adminRoutes = require('./routes/admin.routes');
const staffRoutes = require('./routes/staff.routes');

/**
 * Dipisah dari server.js (Sesi 4) supaya bisa di-`require` langsung oleh
 * test integrasi (supertest) tanpa perlu benar-benar bind ke port TCP atau
 * membuat instance Socket.IO. `io` (dipakai fitur realtime SOS) di-attach
 * lewat `app.set('io', ...)` oleh server.js saat boot sungguhan; kalau app
 * ini dipakai tanpa `server.js` (mis. di test), `req.app.get('io')` akan
 * bernilai `undefined` dan controller yang memanggil `io.to(...).emit(...)`
 * perlu io ada — lihat catatan di emergency.controller.js/test integrasi.
 */
function createApp() {
  const app = express();
  const isTestEnv = process.env.NODE_ENV === 'test';

  // Perlu untuk deployment di belakang reverse proxy (Nginx, Render, Railway,
  // dll) - tanpa ini, express-rate-limit & req.ip akan membaca IP proxy itu
  // sendiri (selalu sama), bukan IP klien asli, sehingga rate limit per-IP
  // jadi tidak berarti (Sesi 9 - production hardening).
  app.set('trust proxy', 1);

  // Header keamanan HTTP standar (X-Content-Type-Options, HSTS, dst).
  // CSP default helmet ("self" only) sudah dicek cocok dengan dashboard
  // /mechanic - tidak ada inline <script>/<style>, dan satu-satunya request
  // (fetch API + Socket.IO) semuanya same-origin. Lihat catatan #memory Sesi 9.
  app.use(helmet());

  // Kompres response JSON/HTML/JS - murni optimisasi bandwidth, tidak mengubah
  // kontrak API (Content-Encoding ditangani otomatis oleh browser/HTTP client).
  app.use(compression());

  // Log tiap request HTTP ke stdout - dimatikan saat test supaya output
  // `npm test` tetap bersih dan tidak butuh mock console tambahan.
  if (!isTestEnv) {
    app.use(morgan(process.env.NODE_ENV === 'production' ? 'combined' : 'dev'));
  }

  // Origin CORS: default '*' (semua origin, cocok development), atau daftar
  // domain spesifik lewat env var CORS_ORIGIN di production - lihat
  // config/corsOrigin.js. Dipakai juga oleh Socket.IO di server.js supaya
  // konsisten (satu sumber kebenaran, bukan dua konfigurasi terpisah).
  app.use(cors({ origin: resolveCorsOrigin() }));
  app.use(express.json());

  // Jaring pengaman terakhir untuk semua endpoint /api/* - limiter yang lebih
  // ketat & spesifik (login, SOS) dipasang langsung di masing-masing route
  // (lihat routes/auth.routes.js, routes/staff.routes.js, routes/emergency.routes.js).
  app.use('/api', generalApiLimiter);

  // Foto kerusakan kendaraan yang diunggah lewat POST /api/emergency/:id/photo
  app.use('/uploads', express.static(path.join(__dirname, '..', 'uploads')));

  // Dashboard statis untuk mekanik/operator
  app.use('/mechanic', express.static(path.join(__dirname, '..', 'public', 'mechanic-dashboard')));

  app.get('/', (req, res) => {
    res.json({ status: 'ok', message: 'OtoShield API berjalan.' });
  });

  app.get('/health', (req, res) => res.json({ status: 'healthy', timestamp: new Date().toISOString() }));

  app.use('/api/auth', authRoutes);
  app.use('/api/vehicles', vehiclesRoutes);
  app.use('/api/workshops', workshopsRoutes);
  app.use('/api/emergency', emergencyRoutes);
  app.use('/api/estimator', estimatorRoutes);
  app.use('/api/payments', paymentsRoutes);
  app.use('/api/admin', adminRoutes);
  app.use('/api/staff', staffRoutes);

  // 404 handler
  app.use((req, res) => {
    res.status(404).json({ message: 'Endpoint tidak ditemukan.' });
  });

  // Error handler umum
  // eslint-disable-next-line no-unused-vars
  app.use((err, req, res, next) => {
    console.error(err.stack);
    res.status(500).json({ message: 'Terjadi kesalahan pada server.' });
  });

  return app;
}

module.exports = createApp;
