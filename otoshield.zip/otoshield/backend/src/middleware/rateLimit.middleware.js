/**
 * Rate limiting (Sesi 9 - production hardening).
 *
 * LATAR BELAKANG: sebelum ada file ini, TIDAK ADA batasan jumlah request sama
 * sekali - endpoint login/register bisa di-brute-force tanpa batas, dan
 * `POST /api/emergency` (SOS) bisa dipakai untuk spam permintaan darurat palsu
 * yang membebani mekanik/bengkel sungguhan.
 *
 * Di-skip total saat `NODE_ENV === 'test'` supaya test integrasi (yang memukul
 * endpoint yang sama puluhan kali secara sengaja dalam satu `describe` block)
 * tidak ikut kena limit dan gagal karena alasan yang tidak relevan dengan
 * yang sedang dites - lihat `test-helpers/integrationSetup.js` yang men-set
 * `NODE_ENV` lewat Jest (`package.json` -> `jest` berjalan dengan
 * `NODE_ENV=test` secara default).
 *
 * CATATAN JUJUR: `express-rate-limit` versi default menyimpan hitungan di
 * memori proses (in-memory store) - cukup untuk single-instance deployment,
 * TAPI kalau nanti backend di-scale ke lebih dari satu instance (mis. di
 * belakang load balancer), setiap instance akan punya hitungannya sendiri-
 * sendiri (limit efektif jadi N x limit-per-instance). Upgrade ke store
 * bersama (mis. `rate-limit-redis`) baru diperlukan saat itu terjadi.
 */

const rateLimit = require('express-rate-limit');

const isTestEnv = process.env.NODE_ENV === 'test';

// Dipakai kalau isTestEnv true - middleware "kosong" yang langsung `next()`,
// supaya urutan middleware tetap sama persis antara test & production
// (tidak ada percabangan if/else di app.js), hanya perilakunya yang beda.
function noopLimiter(req, res, next) {
  next();
}

function buildLimiter(options) {
  if (isTestEnv) return noopLimiter;
  return rateLimit({
    standardHeaders: true, // kirim info limit lewat header `RateLimit-*`
    legacyHeaders: false,
    message: { message: options.message },
    ...options,
  });
}

// Limiter umum untuk semua route /api/* - jaring pengaman terakhir, longgar
// karena tujuannya cuma menahan abuse kasar, bukan membatasi pemakaian normal.
const generalApiLimiter = buildLimiter({
  windowMs: 15 * 60 * 1000, // 15 menit
  max: 300,
  message: 'Terlalu banyak request dari IP ini, coba lagi beberapa saat lagi.',
});

// Limiter ketat untuk login/register - target utamanya brute-force password.
const authLimiter = buildLimiter({
  windowMs: 15 * 60 * 1000,
  max: 20,
  message: 'Terlalu banyak percobaan login/registrasi, coba lagi dalam 15 menit.',
  skipSuccessfulRequests: true, // request yang SUKSES (login benar) tidak ikut dihitung ke limit
});

// Limiter untuk pembuatan SOS baru - mencegah spam permintaan darurat palsu
// yang membebani mekanik/bengkel sungguhan. Lebih longgar dari authLimiter
// karena pengguna asli yang panik bisa saja submit ulang beberapa kali.
const emergencyCreateLimiter = buildLimiter({
  windowMs: 10 * 60 * 1000, // 10 menit
  max: 10,
  message: 'Terlalu banyak permintaan SOS dari akun ini dalam waktu singkat, coba lagi sebentar lagi.',
});

module.exports = { generalApiLimiter, authLimiter, emergencyCreateLimiter };
