const jwt = require('jsonwebtoken');
require('dotenv').config();

/**
 * Middleware JWT khusus akun staf (staff_accounts) - dibuat di Sesi 3 untuk
 * menjawab item "belum dikerjakan" #2: login/role staf bengkel & mekanik.
 *
 * Berbeda dari auth.middleware.js (untuk pengguna biasa), token di sini
 * ditandai dengan claim `type: 'staff'` supaya token staf TIDAK bisa dipakai
 * untuk mengakses endpoint pengguna biasa, dan sebaliknya. Payload token:
 * { id, phone, role, workshop_id, type: 'staff' }.
 */
function staffMiddleware(req, res, next) {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ message: 'Token staf tidak ditemukan.' });
  }

  const token = authHeader.split(' ')[1];
  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    if (decoded.type !== 'staff') {
      return res.status(403).json({ message: 'Token ini bukan token staf.' });
    }
    req.staff = decoded; // { id, phone, role, workshop_id, type }
    next();
  } catch (err) {
    return res.status(401).json({ message: 'Token staf tidak valid atau sudah kedaluwarsa.' });
  }
}

/**
 * Factory middleware untuk membatasi endpoint hanya untuk role tertentu.
 * Contoh: router.post('/', staffMiddleware, requireRole('ADMIN'), createStaff)
 */
function requireRole(...allowedRoles) {
  return (req, res, next) => {
    if (!req.staff || !allowedRoles.includes(req.staff.role)) {
      return res.status(403).json({ message: 'Anda tidak punya izin untuk aksi ini.' });
    }
    next();
  };
}

module.exports = staffMiddleware;
module.exports.requireRole = requireRole;
