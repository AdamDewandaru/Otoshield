const jwt = require('jsonwebtoken');

process.env.JWT_SECRET = 'test-secret-key-for-unit-tests';
const authMiddleware = require('./auth.middleware');

function mockRes() {
  const res = {};
  res.status = jest.fn().mockReturnValue(res);
  res.json = jest.fn().mockReturnValue(res);
  return res;
}

describe('authMiddleware', () => {
  test('menolak request tanpa header Authorization', () => {
    const req = { headers: {} };
    const res = mockRes();
    const next = jest.fn();

    authMiddleware(req, res, next);

    expect(res.status).toHaveBeenCalledWith(401);
    expect(next).not.toHaveBeenCalled();
  });

  test('menolak header yang tidak berformat "Bearer <token>"', () => {
    const req = { headers: { authorization: 'Token abc123' } };
    const res = mockRes();
    const next = jest.fn();

    authMiddleware(req, res, next);

    expect(res.status).toHaveBeenCalledWith(401);
    expect(next).not.toHaveBeenCalled();
  });

  test('menolak token yang tidak valid/kedaluwarsa', () => {
    const req = { headers: { authorization: 'Bearer token-palsu' } };
    const res = mockRes();
    const next = jest.fn();

    authMiddleware(req, res, next);

    expect(res.status).toHaveBeenCalledWith(401);
    expect(next).not.toHaveBeenCalled();
  });

  test('meloloskan token valid dan mengisi req.user', () => {
    const token = jwt.sign({ id: 'user-123', phone: '08123456789' }, process.env.JWT_SECRET, {
      expiresIn: '1h',
    });
    const req = { headers: { authorization: `Bearer ${token}` } };
    const res = mockRes();
    const next = jest.fn();

    authMiddleware(req, res, next);

    expect(next).toHaveBeenCalled();
    expect(req.user).toMatchObject({ id: 'user-123', phone: '08123456789' });
  });

  // Sesi 3: token pengguna sekarang punya claim type: 'user'. Token tanpa claim
  // sama sekali (dibuat sebelum Sesi 3) tetap harus diterima demi kompatibilitas.
  test('meloloskan token lama tanpa claim type sama sekali (kompatibilitas mundur)', () => {
    const token = jwt.sign({ id: 'user-legacy', phone: '0800' }, process.env.JWT_SECRET, {
      expiresIn: '1h',
    });
    const req = { headers: { authorization: `Bearer ${token}` } };
    const res = mockRes();
    const next = jest.fn();

    authMiddleware(req, res, next);

    expect(next).toHaveBeenCalled();
  });

  // Sesi 3: token staf (staff_accounts, claim type: 'staff') tidak boleh dipakai
  // untuk mengakses endpoint pengguna biasa.
  test('menolak token staf (type: staff) di endpoint pengguna', () => {
    const token = jwt.sign(
      { id: 'staff-1', phone: '0812', role: 'MECHANIC', type: 'staff' },
      process.env.JWT_SECRET,
      { expiresIn: '1h' }
    );
    const req = { headers: { authorization: `Bearer ${token}` } };
    const res = mockRes();
    const next = jest.fn();

    authMiddleware(req, res, next);

    expect(res.status).toHaveBeenCalledWith(403);
    expect(next).not.toHaveBeenCalled();
  });
});
