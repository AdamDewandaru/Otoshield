const jwt = require('jsonwebtoken');
require('dotenv').config();

/**
 * Middleware untuk memverifikasi JWT pada header:
 * Authorization: Bearer <token>
 */
function authMiddleware(req, res, next) {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ message: 'Token otorisasi tidak ditemukan.' });
  }

  const token = authHeader.split(' ')[1];
  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    // Sesi 3: token staf (staff_accounts) sekarang punya claim type: 'staff' dan
    // TIDAK boleh dipakai untuk mengakses endpoint pengguna biasa. Token pengguna
    // lama (sebelum Sesi 3) tidak punya claim `type` sama sekali - tetap diterima
    // di sini agar pengguna yang sudah login sebelumnya tidak mendadak ter-logout.
    if (decoded.type && decoded.type !== 'user') {
      return res.status(403).json({ message: 'Token ini bukan token pengguna.' });
    }
    req.user = decoded; // { id, phone }
    next();
  } catch (err) {
    return res.status(401).json({ message: 'Token tidak valid atau sudah kedaluwarsa.' });
  }
}

module.exports = authMiddleware;
