process.env.ADMIN_API_KEY = 'super-secret-admin-key';
const adminMiddleware = require('./admin.middleware');

function mockRes() {
  const res = {};
  res.status = jest.fn().mockReturnValue(res);
  res.json = jest.fn().mockReturnValue(res);
  return res;
}

describe('adminMiddleware', () => {
  test('menolak jika header x-admin-key tidak ada', () => {
    const req = { headers: {} };
    const res = mockRes();
    const next = jest.fn();

    adminMiddleware(req, res, next);

    expect(res.status).toHaveBeenCalledWith(401);
    expect(next).not.toHaveBeenCalled();
  });

  test('menolak jika key salah', () => {
    const req = { headers: { 'x-admin-key': 'kunci-salah' } };
    const res = mockRes();
    const next = jest.fn();

    adminMiddleware(req, res, next);

    expect(res.status).toHaveBeenCalledWith(401);
    expect(next).not.toHaveBeenCalled();
  });

  test('meloloskan jika key benar', () => {
    const req = { headers: { 'x-admin-key': 'super-secret-admin-key' } };
    const res = mockRes();
    const next = jest.fn();

    adminMiddleware(req, res, next);

    expect(next).toHaveBeenCalled();
    expect(res.status).not.toHaveBeenCalled();
  });
});
