const multer = require('multer');
const { getDriver } = require('../services/storage');

/**
 * Upload foto kerusakan kendaraan (Bagian 3.B blueprint: Cloud Storage).
 *
 * Sesi 4: storage engine sekarang dipilih lewat abstraksi di
 * `services/storage/` (`STORAGE_DRIVER=local` default, atau `s3`) alih-alih
 * hardcode ke disk lokal - lihat `services/storage/s3Driver.js` untuk
 * catatan jujur soal apa yang sudah/belum dites terhadap AWS sungguhan.
 */

const driver = getDriver();

const allowedMimeTypes = ['image/jpeg', 'image/png', 'image/webp'];

function fileFilter(req, file, cb) {
  if (!allowedMimeTypes.includes(file.mimetype)) {
    return cb(new Error('Format file tidak didukung. Gunakan JPEG, PNG, atau WEBP.'));
  }
  cb(null, true);
}

const uploadEmergencyPhoto = multer({
  storage: driver.multerStorage,
  fileFilter,
  limits: { fileSize: 5 * 1024 * 1024 }, // maks 5MB
});

module.exports = { uploadEmergencyPhoto };
