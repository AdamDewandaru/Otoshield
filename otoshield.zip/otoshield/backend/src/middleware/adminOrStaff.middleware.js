const jwt = require('jsonwebtoken');
require('dotenv').config();

/**
 * Middleware hybrid untuk /api/admin/* (Sesi 3).
 *
 * Sesi 2 hanya punya satu cara masuk ke dashboard mekanik: shared secret
 * `ADMIN_API_KEY` lewat header `x-admin-key`. Sesi 3 menambahkan login staf
 * per-orang (lihat staff.middleware.js), TAPI supaya tidak memutus dashboard
 * lama secara tiba-tiba, middleware ini menerima SALAH SATU dari:
 *   1. Header `x-admin-key` yang cocok dengan ADMIN_API_KEY (cara lama, tetap
 *      didukung untuk kompatibilitas / darurat jika staf lupa password), ATAU
 *   2. Header `Authorization: Bearer <token staf>` yang valid.
 *
 * `req.staff` diisi jika login lewat token staf (punya id/role/workshop_id
 * untuk audit "siapa mengubah apa"), atau null jika lewat shared key lama
 * (masih anonim, sesuai keterbatasan yang sudah dicatat di admin.middleware.js).
 */
function adminOrStaffMiddleware(req, res, next) {
  const adminKey = req.headers['x-admin-key'];
  if (adminKey && process.env.ADMIN_API_KEY && adminKey === process.env.ADMIN_API_KEY) {
    req.staff = null; // shared-key lama, tidak ada identitas staf individual
    return next();
  }

  const authHeader = req.headers.authorization;
  if (authHeader && authHeader.startsWith('Bearer ')) {
    const token = authHeader.split(' ')[1];
    try {
      const decoded = jwt.verify(token, process.env.JWT_SECRET);
      if (decoded.type === 'staff') {
        req.staff = decoded;
        return next();
      }
    } catch (err) {
      // jatuh ke penolakan di bawah
    }
  }

  return res.status(401).json({ message: 'Autentikasi admin/staf tidak valid.' });
}

module.exports = adminOrStaffMiddleware;
