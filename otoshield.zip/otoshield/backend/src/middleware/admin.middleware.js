require('dotenv').config();

/**
 * Middleware otorisasi untuk dashboard mekanik/operator (Point #2 di daftar
 * "belum dikerjakan"). Ini adalah pendekatan MVP: satu shared secret key
 * (`ADMIN_API_KEY` di .env) dikirim lewat header `x-admin-key`.
 *
 * KETERBATASAN YANG DISADARI (dicatat agar sesi berikutnya tahu ini bukan
 * solusi akhir): tidak ada tabel akun staf/mekanik dengan role & password
 * masing-masing, jadi semua operator berbagi satu key yang sama dan tidak
 * ada audit trail "siapa yang mengubah status ini". Untuk produksi, ganti
 * dengan tabel `staff_accounts` (punya workshop_id, role, password_hash)
 * + JWT seperti auth.middleware.js, supaya setiap bengkel/mekanik punya
 * login sendiri dan aksinya bisa dilacak.
 */
function adminMiddleware(req, res, next) {
  const key = req.headers['x-admin-key'];
  if (!process.env.ADMIN_API_KEY) {
    return res.status(500).json({ message: 'ADMIN_API_KEY belum dikonfigurasi di server.' });
  }
  if (!key || key !== process.env.ADMIN_API_KEY) {
    return res.status(401).json({ message: 'Admin key tidak valid.' });
  }
  next();
}

module.exports = adminMiddleware;
