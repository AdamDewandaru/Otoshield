const jwt = require('jsonwebtoken');

process.env.JWT_SECRET = 'test-secret-key-for-unit-tests';
const staffMiddleware = require('./staff.middleware');
const { requireRole } = require('./staff.middleware');

function mockRes() {
  const res = {};
  res.status = jest.fn().mockReturnValue(res);
  res.json = jest.fn().mockReturnValue(res);
  return res;
}

function signStaffToken(payload, opts = {}) {
  return jwt.sign(payload, process.env.JWT_SECRET, { expiresIn: '1h', ...opts });
}

describe('staffMiddleware', () => {
  test('menolak request tanpa header Authorization', () => {
    const req = { headers: {} };
    const res = mockRes();
    const next = jest.fn();

    staffMiddleware(req, res, next);

    expect(res.status).toHaveBeenCalledWith(401);
    expect(next).not.toHaveBeenCalled();
  });

  test('menolak token yang valid tapi bukan bertipe staff (mis. token pengguna biasa)', () => {
    const token = signStaffToken({ id: 'user-1', phone: '0812', type: 'user' });
    const req = { headers: { authorization: `Bearer ${token}` } };
    const res = mockRes();
    const next = jest.fn();

    staffMiddleware(req, res, next);

    expect(res.status).toHaveBeenCalledWith(403);
    expect(next).not.toHaveBeenCalled();
  });

  test('menolak token tanpa claim type sama sekali', () => {
    const token = signStaffToken({ id: 'staff-1', phone: '0812' });
    const req = { headers: { authorization: `Bearer ${token}` } };
    const res = mockRes();
    const next = jest.fn();

    staffMiddleware(req, res, next);

    expect(res.status).toHaveBeenCalledWith(403);
    expect(next).not.toHaveBeenCalled();
  });

  test('meloloskan token staf yang valid dan mengisi req.staff', () => {
    const token = signStaffToken({
      id: 'staff-1',
      phone: '081200000000',
      role: 'MECHANIC',
      workshop_id: 'workshop-1',
      type: 'staff',
    });
    const req = { headers: { authorization: `Bearer ${token}` } };
    const res = mockRes();
    const next = jest.fn();

    staffMiddleware(req, res, next);

    expect(next).toHaveBeenCalled();
    expect(req.staff).toMatchObject({ id: 'staff-1', role: 'MECHANIC' });
  });
});

describe('requireRole', () => {
  test('menolak jika req.staff tidak ada', () => {
    const req = {};
    const res = mockRes();
    const next = jest.fn();

    requireRole('ADMIN')(req, res, next);

    expect(res.status).toHaveBeenCalledWith(403);
    expect(next).not.toHaveBeenCalled();
  });

  test('menolak jika role staf tidak termasuk yang diizinkan', () => {
    const req = { staff: { role: 'MECHANIC' } };
    const res = mockRes();
    const next = jest.fn();

    requireRole('ADMIN', 'WORKSHOP_STAFF')(req, res, next);

    expect(res.status).toHaveBeenCalledWith(403);
    expect(next).not.toHaveBeenCalled();
  });

  test('meloloskan jika role staf termasuk yang diizinkan', () => {
    const req = { staff: { role: 'ADMIN' } };
    const res = mockRes();
    const next = jest.fn();

    requireRole('ADMIN')(req, res, next);

    expect(next).toHaveBeenCalled();
    expect(res.status).not.toHaveBeenCalled();
  });
});
