/**
 * Test untuk `rateLimit.middleware.js` (Sesi 9).
 *
 * CATATAN JUJUR: yang dites otomatis di sini HANYA perilaku saat
 * `NODE_ENV === 'test'` (limiter jadi no-op/`next()` langsung) - karena
 * itulah kondisi sungguhan saat `npm test` berjalan (Jest men-set
 * `NODE_ENV=test` secara default kalau belum diset), dan karena semua test
 * integrasi lain di proyek ini (supertest, banyak request beruntun ke
 * endpoint yang sama) BERGANTUNG pada bypass ini supaya tidak flaky/gagal
 * karena kena limit yang tidak relevan dengan yang sedang mereka uji.
 *
 * Perilaku SUNGGUHAN `express-rate-limit` (menghitung request, membalas 429
 * setelah `max` terlampaui, header `RateLimit-*`) TIDAK dites lewat Jest di
 * sini - itu sudah diverifikasi MANUAL lewat `curl` melawan server yang
 * benar-benar di-boot dengan `NODE_ENV=development` (lihat catatan #memory
 * Sesi 9 di blueprint: 22 percobaan login beruntun, request ke-21 & ke-22
 * dikonfirmasi balas 429). Mensimulasikan itu lewat Jest butuh memaksa
 * `NODE_ENV` bukan `'test'` di tengah proses Jest yang sama - berisiko
 * mengubah perilaku SEMUA test lain di suite yang jalan `--runInBand` di
 * proses yang sama, jadi sengaja tidak dilakukan.
 */
describe('rateLimit.middleware - perilaku saat NODE_ENV=test (kondisi npm test sungguhan)', () => {
  // Tidak override process.env.NODE_ENV di sini secara sengaja - test ini
  // justru membuktikan module bekerja benar di lingkungan npm test APA ADANYA.
  const { generalApiLimiter, authLimiter, emergencyCreateLimiter } = require('./rateLimit.middleware');

  function mockRes() {
    const res = {};
    res.status = jest.fn().mockReturnValue(res);
    res.json = jest.fn().mockReturnValue(res);
    res.set = jest.fn().mockReturnValue(res);
    return res;
  }

  test.each([
    ['generalApiLimiter', generalApiLimiter],
    ['authLimiter', authLimiter],
    ['emergencyCreateLimiter', emergencyCreateLimiter],
  ])('%s memanggil next() langsung tanpa menyentuh res, walau dipanggil berkali-kali', (_name, limiter) => {
    for (let i = 0; i < 50; i += 1) {
      const req = { ip: '127.0.0.1', headers: {} };
      const res = mockRes();
      const next = jest.fn();

      limiter(req, res, next);

      expect(next).toHaveBeenCalledTimes(1);
      expect(res.status).not.toHaveBeenCalled();
      expect(res.json).not.toHaveBeenCalled();
    }
  });
});
