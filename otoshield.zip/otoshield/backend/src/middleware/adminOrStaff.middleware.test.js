const jwt = require('jsonwebtoken');

process.env.JWT_SECRET = 'test-secret-key-for-unit-tests';
process.env.ADMIN_API_KEY = 'super-secret-admin-key';
const adminOrStaffMiddleware = require('./adminOrStaff.middleware');

function mockRes() {
  const res = {};
  res.status = jest.fn().mockReturnValue(res);
  res.json = jest.fn().mockReturnValue(res);
  return res;
}

describe('adminOrStaffMiddleware', () => {
  test('menolak jika tidak ada x-admin-key maupun Authorization', () => {
    const req = { headers: {} };
    const res = mockRes();
    const next = jest.fn();

    adminOrStaffMiddleware(req, res, next);

    expect(res.status).toHaveBeenCalledWith(401);
    expect(next).not.toHaveBeenCalled();
  });

  test('meloloskan lewat x-admin-key lama (cara Sesi 2) dan req.staff diisi null', () => {
    const req = { headers: { 'x-admin-key': 'super-secret-admin-key' } };
    const res = mockRes();
    const next = jest.fn();

    adminOrStaffMiddleware(req, res, next);

    expect(next).toHaveBeenCalled();
    expect(req.staff).toBeNull();
  });

  test('menolak x-admin-key yang salah', () => {
    const req = { headers: { 'x-admin-key': 'salah' } };
    const res = mockRes();
    const next = jest.fn();

    adminOrStaffMiddleware(req, res, next);

    expect(res.status).toHaveBeenCalledWith(401);
    expect(next).not.toHaveBeenCalled();
  });

  test('meloloskan lewat token staf JWT yang valid dan mengisi req.staff', () => {
    const token = jwt.sign(
      { id: 'staff-1', phone: '0812', role: 'MECHANIC', type: 'staff' },
      process.env.JWT_SECRET,
      { expiresIn: '1h' }
    );
    const req = { headers: { authorization: `Bearer ${token}` } };
    const res = mockRes();
    const next = jest.fn();

    adminOrStaffMiddleware(req, res, next);

    expect(next).toHaveBeenCalled();
    expect(req.staff).toMatchObject({ id: 'staff-1', role: 'MECHANIC' });
  });

  test('menolak token JWT bertipe user (bukan staff)', () => {
    const token = jwt.sign({ id: 'user-1', phone: '0812', type: 'user' }, process.env.JWT_SECRET, {
      expiresIn: '1h',
    });
    const req = { headers: { authorization: `Bearer ${token}` } };
    const res = mockRes();
    const next = jest.fn();

    adminOrStaffMiddleware(req, res, next);

    expect(res.status).toHaveBeenCalledWith(401);
    expect(next).not.toHaveBeenCalled();
  });
});
