const fs = require('fs');
const path = require('path');
const { Client } = require('pg');

/**
 * Setup bersama untuk test integrasi (item "belum dikerjakan" #6).
 *
 * Beda dengan `*.controller.test.js` (yang mock `pool.query`), file-file di
 * `src/__tests__/integration/` ini betul-betul membuka koneksi ke PostgreSQL
 * SUNGGUHAN dan memukul endpoint HTTP asli lewat `supertest`, bukan
 * memanggil fungsi controller langsung.
 *
 * Supaya tidak mengotori database development (`otoshield_db`, dipakai untuk
 * `npm run seed` / boot manual), test ini pakai DATABASE_URL TERPISAH yang
 * menunjuk ke `otoshield_test_db` - di-set di sini SEBELUM `require('../../app')`
 * atau `require('../../config/db')` di mana pun dipanggil, supaya pool `pg`
 * yang dibuat saat modul itu di-require memakai koneksi test, bukan koneksi dev.
 *
 * CATATAN JUJUR: test ini butuh PostgreSQL sungguhan berjalan di
 * localhost:5432 dengan user/db seperti di bawah (dibuat manual sekali via
 * `psql` di sandbox sesi ini - lihat catatan #memory Sesi 4 di blueprint
 * untuk perintah persisnya). Kalau dijalankan di mesin/CI lain, DB test ini
 * perlu dibuat dulu (`CREATE DATABASE otoshield_test_db;`) - belum ada
 * automasi pembuatan database-nya sendiri, hanya automasi schema di
 * dalamnya (lihat `resetSchema` di bawah).
 */

const TEST_DATABASE_URL =
  process.env.TEST_DATABASE_URL || 'postgres://otoshield:otoshield@localhost:5432/otoshield_test_db';

process.env.DATABASE_URL = TEST_DATABASE_URL;
process.env.JWT_SECRET = process.env.JWT_SECRET || 'test-jwt-secret-integration';
process.env.ADMIN_API_KEY = process.env.ADMIN_API_KEY || 'test-admin-key-integration';
// STORAGE_DRIVER sengaja TIDAK di-set -> default 'local', supaya test upload foto
// (kalau ada) tidak butuh kredensial AWS.

const createApp = require('../app');
const pool = require('../config/db');

const schemaSql = fs.readFileSync(path.join(__dirname, '..', 'db', 'schema.sql'), 'utf8');

/**
 * Drop semua tabel lalu jalankan ulang schema.sql, supaya setiap file test
 * integrasi mulai dari keadaan bersih & independen satu sama lain (tidak
 * saling bergantung urutan `describe`/file).
 */
async function resetSchema() {
  const client = new Client({ connectionString: TEST_DATABASE_URL });
  await client.connect();
  try {
    await client.query('DROP SCHEMA public CASCADE');
    await client.query('CREATE SCHEMA public');
    await client.query(schemaSql);
  } finally {
    await client.end();
  }
}

async function closePool() {
  await pool.end();
}

function buildApp() {
  return createApp();
}

module.exports = { resetSchema, closePool, buildApp, TEST_DATABASE_URL };
