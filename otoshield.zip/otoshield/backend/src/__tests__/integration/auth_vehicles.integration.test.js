const request = require('supertest');
const { resetSchema, closePool, buildApp } = require('../../test-helpers/integrationSetup');

/**
 * Test integrasi otomatis (item "belum dikerjakan" #6) - HTTP end-to-end
 * lewat supertest, melawan PostgreSQL SUNGGUHAN (bukan mock `pool.query`
 * seperti `auth.controller.test.js`). Lihat `setup.js` untuk detail
 * konfigurasi database test terpisah.
 */
describe('Integrasi: Auth & Vehicles (Postgres sungguhan)', () => {
  let app;

  beforeAll(async () => {
    await resetSchema();
    app = buildApp();
  });

  afterAll(async () => {
    await closePool();
  });

  let token;
  let userId;

  test('POST /api/auth/register -> 201, mengembalikan user & JWT', async () => {
    const res = await request(app).post('/api/auth/register').send({
      name: 'Siti Integrasi',
      phone: '081200000001',
      email: 'siti.integrasi@example.com',
      password: 'sandiaman123',
    });
    expect(res.status).toBe(201);
    expect(res.body.user.phone).toBe('081200000001');
    expect(res.body.token).toEqual(expect.any(String));
    token = res.body.token;
    userId = res.body.user.id;
  });

  test('POST /api/auth/register dengan nomor sama -> 409', async () => {
    const res = await request(app).post('/api/auth/register').send({
      name: 'Siti Duplikat',
      phone: '081200000001',
      password: 'lainnya123',
    });
    expect(res.status).toBe(409);
  });

  test('POST /api/auth/login dengan password salah -> 401', async () => {
    const res = await request(app).post('/api/auth/login').send({
      phone: '081200000001',
      password: 'password-salah',
    });
    expect(res.status).toBe(401);
  });

  test('POST /api/auth/login sukses -> 200 dengan token baru', async () => {
    const res = await request(app).post('/api/auth/login').send({
      phone: '081200000001',
      password: 'sandiaman123',
    });
    expect(res.status).toBe(200);
    expect(res.body.token).toEqual(expect.any(String));
  });

  test('GET /api/auth/me tanpa token -> 401', async () => {
    const res = await request(app).get('/api/auth/me');
    expect(res.status).toBe(401);
  });

  test('GET /api/auth/me dengan token -> 200, data cocok dengan yang didaftarkan', async () => {
    const res = await request(app).get('/api/auth/me').set('Authorization', `Bearer ${token}`);
    expect(res.status).toBe(200);
    expect(res.body.id).toBe(userId);
    expect(res.body.name).toBe('Siti Integrasi');
  });

  test('PUT /api/auth/me mengubah email -> tersimpan sungguhan di Postgres', async () => {
    const res = await request(app)
      .put('/api/auth/me')
      .set('Authorization', `Bearer ${token}`)
      .send({ email: 'siti.baru@example.com' });
    expect(res.status).toBe(200);
    expect(res.body.email).toBe('siti.baru@example.com');

    // Verifikasi independen: GET ulang harus mencerminkan perubahan (bukan cuma response PUT)
    const check = await request(app).get('/api/auth/me').set('Authorization', `Bearer ${token}`);
    expect(check.body.email).toBe('siti.baru@example.com');
  });

  test('POST /api/vehicles menambah kendaraan -> tersimpan di Postgres', async () => {
    const res = await request(app)
      .post('/api/vehicles')
      .set('Authorization', `Bearer ${token}`)
      .send({ brand: 'Honda', model: 'Beat', year: 2021, license_plate: 'P 1234 AB', current_kilometer: 5000 });
    expect(res.status).toBe(201);
    expect(res.body.license_plate).toBe('P 1234 AB');
  });

  test('GET /api/vehicles mengembalikan kendaraan yang baru ditambahkan', async () => {
    const res = await request(app).get('/api/vehicles').set('Authorization', `Bearer ${token}`);
    expect(res.status).toBe(200);
    expect(res.body.length).toBe(1);
    expect(res.body[0].brand).toBe('Honda');
  });

  test('PUT /api/vehicles/:id mengubah plat nomor -> perubahan persisten', async () => {
    const list = await request(app).get('/api/vehicles').set('Authorization', `Bearer ${token}`);
    const vehicleId = list.body[0].id;

    const res = await request(app)
      .put(`/api/vehicles/${vehicleId}`)
      .set('Authorization', `Bearer ${token}`)
      .send({ license_plate: 'P 9999 ZZ' });
    expect(res.status).toBe(200);
    expect(res.body.license_plate).toBe('P 9999 ZZ');

    const recheck = await request(app).get('/api/vehicles').set('Authorization', `Bearer ${token}`);
    expect(recheck.body[0].license_plate).toBe('P 9999 ZZ');
  });

  test('DELETE /api/vehicles/:id menghapus kendaraan -> daftar jadi kosong', async () => {
    const list = await request(app).get('/api/vehicles').set('Authorization', `Bearer ${token}`);
    const vehicleId = list.body[0].id;

    const res = await request(app).delete(`/api/vehicles/${vehicleId}`).set('Authorization', `Bearer ${token}`);
    expect(res.status).toBe(204);

    const recheck = await request(app).get('/api/vehicles').set('Authorization', `Bearer ${token}`);
    expect(recheck.body.length).toBe(0);
  });

  test('Kendaraan milik pengguna lain tidak bisa diakses -> 404', async () => {
    // pengguna kedua
    const other = await request(app).post('/api/auth/register').send({
      name: 'Pengguna Lain',
      phone: '081200000002',
      password: 'lainnya123',
    });
    const otherToken = other.body.token;

    const addRes = await request(app)
      .post('/api/vehicles')
      .set('Authorization', `Bearer ${otherToken}`)
      .send({ brand: 'Yamaha', model: 'NMAX', year: 2022, license_plate: 'B 1 XY' });
    const otherVehicleId = addRes.body.id;

    // pengguna pertama (token lama) coba akses kendaraan pengguna kedua
    const res = await request(app)
      .put(`/api/vehicles/${otherVehicleId}`)
      .set('Authorization', `Bearer ${token}`)
      .send({ license_plate: 'CURI 1' });
    expect(res.status).toBe(404);
  });
});
