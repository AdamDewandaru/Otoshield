const request = require('supertest');
const { resetSchema, closePool, buildApp } = require('../../test-helpers/integrationSetup');

/**
 * Integrasi: dashboard mekanik/operator (`/api/admin/*`), dilindungi
 * `adminOrStaff.middleware.js` (Sesi 3: menerima shared key `x-admin-key`
 * LAMA *atau* token staf JWT baru). Ditambahkan Sesi 6, mengisi kekosongan
 * yang dicatat di blueprint (item #6): sebelumnya `admin.controller` (fungsi
 * `listEmergencies`/`updateStatus` di emergency.controller.js dan
 * `listWorkshops` di workshops.controller.js dipakai ulang oleh admin.routes.js)
 * TIDAK ADA test end-to-end sama sekali lewat dashboard, baik mock maupun
 * integrasi sungguhan.
 *
 * ADMIN_API_KEY dites di sini sama dengan yang di-set integrationSetup.js
 * ('test-admin-key-integration') - lihat file itu untuk detail kenapa nilainya
 * konsisten dipakai lintas semua file test integrasi.
 */
describe('Integrasi: Admin/mechanic dashboard (Postgres sungguhan)', () => {
  let app;
  const ADMIN_KEY = 'test-admin-key-integration';

  beforeAll(async () => {
    await resetSchema();
    app = buildApp();
  });

  afterAll(async () => {
    await closePool();
  });

  async function registerUserAndEmergency() {
    const user = await request(app).post('/api/auth/register').send({
      name: 'Pengendara Test',
      phone: `0813${Math.floor(Math.random() * 1e8)}`,
      password: 'password123',
    });
    const emergency = await request(app)
      .post('/api/emergency')
      .set('Authorization', `Bearer ${user.body.token}`)
      .send({ latitude: -6.2, longitude: 106.8, issue_description: 'Ban bocor' });
    return { user, emergencyId: emergency.body.emergency.id };
  }

  test('GET /api/admin/emergency tanpa auth apa pun -> 401', async () => {
    const res = await request(app).get('/api/admin/emergency');
    expect(res.status).toBe(401);
  });

  test('GET /api/admin/emergency dengan x-admin-key salah -> 401', async () => {
    const res = await request(app).get('/api/admin/emergency').set('x-admin-key', 'salah-sekali');
    expect(res.status).toBe(401);
  });

  test('GET /api/admin/emergency dengan x-admin-key benar (cara lama) -> 200, daftar SOS', async () => {
    await registerUserAndEmergency();
    const res = await request(app).get('/api/admin/emergency').set('x-admin-key', ADMIN_KEY);
    expect(res.status).toBe(200);
    expect(Array.isArray(res.body)).toBe(true);
    expect(res.body.length).toBeGreaterThanOrEqual(1);
    // JOIN ke users harus menyertakan nama/telepon pemohon
    expect(res.body[0]).toHaveProperty('user_name');
    expect(res.body[0]).toHaveProperty('user_phone');
  });

  test('GET /api/admin/emergency?status=PENDING -> hanya yang berstatus PENDING', async () => {
    const res = await request(app)
      .get('/api/admin/emergency?status=PENDING')
      .set('x-admin-key', ADMIN_KEY);
    expect(res.status).toBe(200);
    expect(res.body.every((e) => e.status === 'PENDING')).toBe(true);
  });

  test('PUT /api/admin/emergency/:id/status tanpa auth -> 401, status di DB tidak berubah', async () => {
    const { emergencyId } = await registerUserAndEmergency();
    const res = await request(app)
      .put(`/api/admin/emergency/${emergencyId}/status`)
      .send({ status: 'ACCEPTED' });
    expect(res.status).toBe(401);

    // GET /api/emergency/:id butuh auth user (auth.middleware.js), jadi verifikasi
    // lewat dashboard admin (x-admin-key) alih-alih endpoint user di sini.
    const check = await request(app).get('/api/admin/emergency').set('x-admin-key', ADMIN_KEY);
    const found = check.body.find((e) => e.id === emergencyId);
    expect(found.status).toBe('PENDING');
  });

  test('PUT /api/admin/emergency/:id/status dengan x-admin-key -> 200, status berubah', async () => {
    const { emergencyId } = await registerUserAndEmergency();
    const res = await request(app)
      .put(`/api/admin/emergency/${emergencyId}/status`)
      .set('x-admin-key', ADMIN_KEY)
      .send({ status: 'ACCEPTED' });
    expect(res.status).toBe(200);
    expect(res.body.status).toBe('ACCEPTED');
  });

  test('PUT /api/admin/emergency/:id/status dengan status tidak valid -> 400', async () => {
    const { emergencyId } = await registerUserAndEmergency();
    const res = await request(app)
      .put(`/api/admin/emergency/${emergencyId}/status`)
      .set('x-admin-key', ADMIN_KEY)
      .send({ status: 'STATUS_NGAWUR' });
    expect(res.status).toBe(400);
  });

  test('GET /api/admin/workshops dengan x-admin-key -> 200', async () => {
    const res = await request(app).get('/api/admin/workshops').set('x-admin-key', ADMIN_KEY);
    expect(res.status).toBe(200);
    expect(Array.isArray(res.body)).toBe(true);
  });

  describe('Alur token staf (login individual, Sesi 3)', () => {
    let adminToken;
    let mechanicToken;
    let workshopStaffToken;

    test('bootstrap: buat staf ADMIN pertama pakai x-admin-key lama -> 201', async () => {
      const res = await request(app).post('/api/staff').set('x-admin-key', ADMIN_KEY).send({
        name: 'Operator Utama',
        phone: '081399900001',
        password: 'adminpass123',
        role: 'ADMIN',
      });
      expect(res.status).toBe(201);
      expect(res.body.role).toBe('ADMIN');
      // password_hash tidak boleh pernah bocor ke response
      expect(res.body.password_hash).toBeUndefined();
    });

    test('staf ADMIN login -> dapat token JWT bertipe staff', async () => {
      const res = await request(app)
        .post('/api/staff/login')
        .send({ phone: '081399900001', password: 'adminpass123' });
      expect(res.status).toBe(200);
      expect(res.body.token).toBeTruthy();
      adminToken = res.body.token;
    });

    test('login staf dengan password salah -> 401', async () => {
      const res = await request(app)
        .post('/api/staff/login')
        .send({ phone: '081399900001', password: 'salahpassword' });
      expect(res.status).toBe(401);
    });

    test('token staf ADMIN dipakai untuk akses dashboard admin -> 200 (bukan cuma x-admin-key)', async () => {
      const res = await request(app)
        .get('/api/admin/emergency')
        .set('Authorization', `Bearer ${adminToken}`);
      expect(res.status).toBe(200);
    });

    test('staf ADMIN membuat staf MECHANIC baru lewat token (bukan x-admin-key) -> 201', async () => {
      const res = await request(app)
        .post('/api/staff')
        .set('Authorization', `Bearer ${adminToken}`)
        .send({ name: 'Montir Lapangan', phone: '081399900002', password: 'mechpass123', role: 'MECHANIC' });
      expect(res.status).toBe(201);
    });

    test('staf MECHANIC login lalu coba akses dashboard admin -> 200 (adminOrStaff tidak batasi role)', async () => {
      const login = await request(app)
        .post('/api/staff/login')
        .send({ phone: '081399900002', password: 'mechpass123' });
      expect(login.status).toBe(200);
      mechanicToken = login.body.token;

      const res = await request(app)
        .get('/api/admin/emergency')
        .set('Authorization', `Bearer ${mechanicToken}`);
      expect(res.status).toBe(200);
    });

    test('staf MECHANIC (bukan ADMIN) mencoba membuat staf baru -> 403', async () => {
      const res = await request(app)
        .post('/api/staff')
        .set('Authorization', `Bearer ${mechanicToken}`)
        .send({ name: 'Staf Lain', phone: '081399900003', password: 'pass12345', role: 'MECHANIC' });
      expect(res.status).toBe(403);
    });

    test('staf MECHANIC (bukan ADMIN) mencoba GET daftar staf -> 403', async () => {
      const res = await request(app)
        .get('/api/staff')
        .set('Authorization', `Bearer ${mechanicToken}`);
      expect(res.status).toBe(403);
    });

    test('staf ADMIN GET daftar staf -> 200, berisi kedua staf yang dibuat', async () => {
      const res = await request(app)
        .get('/api/staff')
        .set('Authorization', `Bearer ${adminToken}`);
      expect(res.status).toBe(200);
      const phones = res.body.map((s) => s.phone);
      expect(phones).toEqual(expect.arrayContaining(['081399900001', '081399900002']));
    });

    // Ditambahkan Sesi 7: role WORKSHOP_STAFF baru tercatat di skema & enum sejak Sesi 3,
    // tapi belum pernah dites secara spesifik lewat test integrasi (hanya ADMIN & MECHANIC
    // yang punya test end-to-end sampai Sesi 6) - dicatat sebagai kandidat lanjutan di blueprint.
    test('staf ADMIN membuat staf WORKSHOP_STAFF baru lewat token -> 201', async () => {
      const res = await request(app)
        .post('/api/staff')
        .set('Authorization', `Bearer ${adminToken}`)
        .send({ name: 'Staf Bengkel Mitra', phone: '081399900004', password: 'wspass123', role: 'WORKSHOP_STAFF' });
      expect(res.status).toBe(201);
      expect(res.body.role).toBe('WORKSHOP_STAFF');
      expect(res.body.password_hash).toBeUndefined();
    });

    test('staf WORKSHOP_STAFF login lalu akses dashboard admin -> 200 (adminOrStaff tidak batasi role, sama seperti MECHANIC)', async () => {
      const login = await request(app)
        .post('/api/staff/login')
        .send({ phone: '081399900004', password: 'wspass123' });
      expect(login.status).toBe(200);
      workshopStaffToken = login.body.token;

      const res = await request(app)
        .get('/api/admin/emergency')
        .set('Authorization', `Bearer ${workshopStaffToken}`);
      expect(res.status).toBe(200);
    });

    test('staf WORKSHOP_STAFF (bukan ADMIN) mencoba membuat staf baru -> 403', async () => {
      const res = await request(app)
        .post('/api/staff')
        .set('Authorization', `Bearer ${workshopStaffToken}`)
        .send({ name: 'Staf Lain 2', phone: '081399900005', password: 'pass12345', role: 'MECHANIC' });
      expect(res.status).toBe(403);
    });

    test('staf WORKSHOP_STAFF (bukan ADMIN) mencoba GET daftar staf -> 403', async () => {
      const res = await request(app)
        .get('/api/staff')
        .set('Authorization', `Bearer ${workshopStaffToken}`);
      expect(res.status).toBe(403);
    });

    test('token staf WORKSHOP_STAFF dipakai di endpoint user biasa (/api/auth/me) -> 403', async () => {
      const res = await request(app).get('/api/auth/me').set('Authorization', `Bearer ${workshopStaffToken}`);
      expect(res.status).toBe(403);
    });

    test('token user biasa (bukan staf) mencoba akses dashboard admin -> 401', async () => {
      const user = await request(app).post('/api/auth/register').send({
        name: 'Pengguna Biasa',
        phone: '081399900099',
        password: 'password123',
      });
      const res = await request(app)
        .get('/api/admin/emergency')
        .set('Authorization', `Bearer ${user.body.token}`);
      expect(res.status).toBe(401);
    });

    test('token staf dipakai untuk akses endpoint user biasa (mis. /api/auth/me) -> 403', async () => {
      const res = await request(app).get('/api/auth/me').set('Authorization', `Bearer ${adminToken}`);
      expect(res.status).toBe(403);
    });
  });
});
