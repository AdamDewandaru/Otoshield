const request = require('supertest');
const { resetSchema, closePool, buildApp } = require('../../test-helpers/integrationSetup');
const { Client } = require('pg');
const { TEST_DATABASE_URL } = require('../../test-helpers/integrationSetup');

/**
 * Integrasi: Smart Cost Estimator (POST /api/estimator/estimate).
 *
 * Ditambahkan Sesi 6, mengisi kekosongan yang dicatat di blueprint (item #6):
 * `estimator.routes.js` sebelumnya hanya punya unit test murni untuk
 * `matchRules()` (estimatorRules.test.js, tidak menyentuh DB sama sekali) -
 * belum ada test yang benar-benar memukul endpoint HTTP melalui `estimateCost()`
 * (yang query ke tabel `cost_estimate_rules` lewat `pool.query`, lihat
 * utils/estimatorRules.js). Test ini insert rules langsung lewat `pg` di
 * `beforeAll` (bukan `seed.sql` penuh) supaya kata kunci & rentang biaya yang
 * dites diketahui persis.
 */
describe('Integrasi: Smart Cost Estimator (Postgres sungguhan)', () => {
  let app;
  let client;

  beforeAll(async () => {
    await resetSchema();
    app = buildApp();

    client = new Client({ connectionString: TEST_DATABASE_URL });
    await client.connect();

    await client.query(
      `INSERT INTO cost_estimate_rules (keyword, issue_category, estimated_min, estimated_max) VALUES
       ('rem berdecit', 'Kampas Rem Aus', 150000, 350000),
       ('mesin overheat', 'Sistem Pendingin', 300000, 900000),
       ('ban bocor', 'Ban & Pelek', 20000, 100000)`
    );
  });

  afterAll(async () => {
    await client.end();
    await closePool();
  });

  test('POST /api/estimator/estimate tanpa symptom_text -> 400', async () => {
    const res = await request(app).post('/api/estimator/estimate').send({});
    expect(res.status).toBe(400);
  });

  test('POST /api/estimator/estimate dengan symptom_text < 3 karakter -> 400', async () => {
    const res = await request(app).post('/api/estimator/estimate').send({ symptom_text: 'ab' });
    expect(res.status).toBe(400);
  });

  test('POST /api/estimator/estimate tanpa login (publik) dengan gejala dikenal -> 200, kecocokan benar', async () => {
    const res = await request(app)
      .post('/api/estimator/estimate')
      .send({ symptom_text: 'rem saya bunyi berdecit terus' });
    expect(res.status).toBe(200);
    expect(res.body.matched).toBe(true);
    expect(res.body.issue_category).toBe('Kampas Rem Aus');
    expect(res.body.estimated_min).toBe(150000);
    expect(res.body.estimated_max).toBe(350000);
  });

  test('POST /api/estimator/estimate dengan gejala tidak dikenal -> 200, matched=false + alternatives kosong', async () => {
    const res = await request(app)
      .post('/api/estimator/estimate')
      .send({ symptom_text: 'suara aneh dari radio mobil' });
    expect(res.status).toBe(200);
    expect(res.body.matched).toBe(false);
    expect(res.body.alternatives).toEqual([]);
  });

  test('POST /api/estimator/estimate dengan gejala menyebut 2 masalah -> yang skor tertinggi jadi hasil utama, sisanya di alternatives', async () => {
    const res = await request(app)
      .post('/api/estimator/estimate')
      .send({ symptom_text: 'ban bocor dan mesin overheat sekaligus' });
    expect(res.status).toBe(200);
    expect(res.body.matched).toBe(true);
    // "ban bocor" (2 kata cocok penuh) dan "mesin overheat" (2 kata cocok penuh) sama-sama skor 1.0;
    // salah satu jadi hasil utama, yang lain masuk alternatives - keduanya harus tetap muncul di respons.
    const categories = [res.body.issue_category, ...res.body.alternatives.map((a) => a.issue_category)];
    expect(categories).toEqual(expect.arrayContaining(['Ban & Pelek', 'Sistem Pendingin']));
  });
});
