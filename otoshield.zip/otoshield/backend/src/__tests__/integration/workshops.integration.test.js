const request = require('supertest');
const { resetSchema, closePool, buildApp } = require('../../test-helpers/integrationSetup');
const { Client } = require('pg');
const { TEST_DATABASE_URL } = require('../../test-helpers/integrationSetup');

/**
 * Integrasi: direktori bengkel (workshops). Karena workshops butuh data awal
 * (tidak dibuat lewat endpoint API publik), test ini insert langsung lewat
 * `pg` di `beforeAll` - bukan lewat `seed.sql` penuh (supaya nilai lat/lng
 * dan jarak antar bengkel diketahui persis untuk membuat assertion presisi).
 */
describe('Integrasi: Workshops directory (Postgres sungguhan)', () => {
  let app;
  let client;
  const jemberWorkshopId = () => workshopIds.jember;
  let workshopIds = {};

  beforeAll(async () => {
    await resetSchema();
    app = buildApp();

    client = new Client({ connectionString: TEST_DATABASE_URL });
    await client.connect();

    const jember = await client.query(
      `INSERT INTO workshops (name, address, latitude, longitude, phone, is_verified, rating)
       VALUES ('Bengkel Jember Test', 'Jl. Test, Jember', -8.1844, 113.6681, '081300000001', true, 4.5)
       RETURNING id`
    );
    workshopIds.jember = jember.rows[0].id;

    const jakarta = await client.query(
      `INSERT INTO workshops (name, address, latitude, longitude, phone, is_verified, rating)
       VALUES ('Bengkel Jakarta Test', 'Jl. Test, Jakarta', -6.2088, 106.8456, '081300000002', false, 3.9)
       RETURNING id`
    );
    workshopIds.jakarta = jakarta.rows[0].id;
  });

  afterAll(async () => {
    await client.end();
    await closePool();
  });

  test('GET /api/workshops (tanpa auth, publik) -> 200 mengembalikan semua bengkel', async () => {
    const res = await request(app).get('/api/workshops');
    expect(res.status).toBe(200);
    expect(res.body.length).toBe(2);
  });

  test('GET /api/workshops?verified_only=true -> hanya bengkel terverifikasi', async () => {
    const res = await request(app).get('/api/workshops?verified_only=true');
    expect(res.status).toBe(200);
    expect(res.body.length).toBe(1);
    expect(res.body[0].name).toBe('Bengkel Jember Test');
  });

  test('GET /api/workshops?lat=&lng=&radius= dekat Jember -> hanya bengkel Jember, ada distance_km', async () => {
    const res = await request(app).get('/api/workshops?lat=-8.1844&lng=113.6681&radius=5');
    expect(res.status).toBe(200);
    expect(res.body.length).toBe(1);
    expect(res.body[0].name).toBe('Bengkel Jember Test');
    expect(res.body[0].distance_km).toBeLessThan(1);
  });

  test('GET /api/workshops/:id -> detail bengkel', async () => {
    const res = await request(app).get(`/api/workshops/${jemberWorkshopId()}`);
    expect(res.status).toBe(200);
    expect(res.body.name).toBe('Bengkel Jember Test');
  });

  test('GET /api/workshops/:id dengan id tidak ada -> 404', async () => {
    const res = await request(app).get('/api/workshops/00000000-0000-0000-0000-000000000000');
    expect(res.status).toBe(404);
  });

  test('POST /api/workshops/:id/reviews tanpa login -> 401', async () => {
    const res = await request(app).post(`/api/workshops/${jemberWorkshopId()}/reviews`).send({ rating: 5 });
    expect(res.status).toBe(401);
  });

  test('POST /api/workshops/:id/reviews dengan login -> 201, rating bengkel ter-update', async () => {
    const user = await request(app).post('/api/auth/register').send({
      name: 'Reviewer Test',
      phone: '081300000099',
      password: 'reviewpass123',
    });
    const res = await request(app)
      .post(`/api/workshops/${jemberWorkshopId()}/reviews`)
      .set('Authorization', `Bearer ${user.body.token}`)
      .send({ rating: 5, comment: 'Pelayanan sangat memuaskan' });
    expect(res.status).toBe(201);

    const detail = await request(app).get(`/api/workshops/${jemberWorkshopId()}`);
    expect(detail.status).toBe(200);
    // rating awal 4.5 dengan 1 review baru rating 5 -> rata-rata harus naik atau tetap masuk akal
    expect(Number(detail.body.rating)).toBeGreaterThanOrEqual(4.5);
  });
});
