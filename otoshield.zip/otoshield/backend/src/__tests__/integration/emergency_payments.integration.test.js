const request = require('supertest');
const crypto = require('crypto');
const { resetSchema, closePool, buildApp } = require('../../test-helpers/integrationSetup');

/**
 * Integrasi: alur SOS darurat (emergency), upload foto (storage abstraction
 * Sesi 4), dan pembayaran (payment gateway pattern Sesi 4, termasuk webhook
 * signature verification) - semua lewat HTTP asli & Postgres sungguhan.
 */
describe('Integrasi: Emergency SOS + Payments (Postgres sungguhan)', () => {
  let app;
  let token;
  let emergencyId;

  beforeAll(async () => {
    await resetSchema();
    app = buildApp();

    const user = await request(app).post('/api/auth/register').send({
      name: 'Rudi SOS Test',
      phone: '081400000001',
      password: 'sospass123',
    });
    token = user.body.token;
  });

  afterAll(async () => {
    await closePool();
  });

  test('POST /api/emergency membuat permintaan SOS baru -> tersimpan di Postgres', async () => {
    const res = await request(app)
      .post('/api/emergency')
      .set('Authorization', `Bearer ${token}`)
      .send({ issue_description: 'Ban bocor & mesin overheat', latitude: -8.1844, longitude: 113.6681 });
    expect(res.status).toBe(201);
    expect(res.body.emergency.status).toBe('PENDING');
    emergencyId = res.body.emergency.id;
  });

  test('GET /api/emergency/:id -> data cocok dengan yang dibuat', async () => {
    const res = await request(app).get(`/api/emergency/${emergencyId}`).set('Authorization', `Bearer ${token}`);
    expect(res.status).toBe(200);
    expect(res.body.issue_description).toBe('Ban bocor & mesin overheat');
  });

  test('POST /api/emergency/:id/photo (storage driver local) -> photo_url tersimpan & file bisa diunduh', async () => {
    // PNG 1x1 valid minimal, cukup untuk lolos filter mimetype multer
    const pngBuffer = Buffer.from(
      'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNk+A8AAQUBAScY42YAAAAASUVORK5CYII=',
      'base64'
    );

    const res = await request(app)
      .post(`/api/emergency/${emergencyId}/photo`)
      .set('Authorization', `Bearer ${token}`)
      .attach('photo', pngBuffer, { filename: 'kerusakan.png', contentType: 'image/png' });

    expect(res.status).toBe(200);
    expect(res.body.photo_url).toMatch(/^\/uploads\/emergency\/.+\.png$/);

    // Verifikasi file BENAR-BENAR ada dan bisa diunduh lewat static file serving,
    // bukan cuma kolom DB terisi string.
    const download = await request(app).get(res.body.photo_url);
    expect(download.status).toBe(200);
    expect(Buffer.compare(download.body, pngBuffer)).toBe(0);
  });

  test('POST /api/emergency/:id/photo dengan file bukan gambar -> ditolak', async () => {
    const res = await request(app)
      .post(`/api/emergency/${emergencyId}/photo`)
      .set('Authorization', `Bearer ${token}`)
      .attach('photo', Buffer.from('bukan gambar'), { filename: 'file.txt', contentType: 'text/plain' });
    expect(res.status).toBe(400);
  });

  describe('Payments: gateway pattern + webhook signature (Sesi 4)', () => {
    let paymentId;
    let orderId;
    const SERVER_KEY = 'dev-simulated-server-key-DO-NOT-USE-IN-PRODUCTION';

    function computeSig({ order_id, status_code, gross_amount }) {
      return crypto.createHash('sha512').update(`${order_id}${status_code}${gross_amount}${SERVER_KEY}`).digest('hex');
    }

    test('POST /api/payments membuat tagihan -> status PENDING, ada payment_reference dari gateway', async () => {
      const res = await request(app)
        .post('/api/payments')
        .set('Authorization', `Bearer ${token}`)
        .send({ emergency_request_id: emergencyId, amount: 175000, method: 'VIRTUAL_ACCOUNT' });
      expect(res.status).toBe(201);
      expect(res.body.status).toBe('PENDING');
      expect(res.body.payment_reference).toMatch(/^OTS-/);
      paymentId = res.body.id;
      orderId = res.body.payment_reference;
    });

    test('Endpoint lama PUT /:id/pay TIDAK ADA lagi (dihapus demi keamanan, Sesi 4) -> 404', async () => {
      const res = await request(app).put(`/api/payments/${paymentId}/pay`).set('Authorization', `Bearer ${token}`);
      expect(res.status).toBe(404);
    });

    test('Webhook dengan signature PALSU -> 403, status TETAP PENDING', async () => {
      const res = await request(app).post('/api/payments/webhook/midtrans').send({
        order_id: orderId,
        status_code: '200',
        gross_amount: '175000.00',
        signature_key: 'signature-palsu-tidak-valid',
        transaction_status: 'settlement',
      });
      expect(res.status).toBe(403);

      const check = await request(app).get(`/api/payments/${paymentId}`).set('Authorization', `Bearer ${token}`);
      expect(check.body.status).toBe('PENDING');
    });

    test('Webhook dengan signature VALID -> 200, status jadi PAID', async () => {
      const validSig = computeSig({ order_id: orderId, status_code: '200', gross_amount: '175000.00' });
      const res = await request(app).post('/api/payments/webhook/midtrans').send({
        order_id: orderId,
        status_code: '200',
        gross_amount: '175000.00',
        signature_key: validSig,
        transaction_status: 'settlement',
      });
      expect(res.status).toBe(200);

      const check = await request(app).get(`/api/payments/${paymentId}`).set('Authorization', `Bearer ${token}`);
      expect(check.body.status).toBe('PAID');
      expect(check.body.paid_at).not.toBeNull();
    });

    test('PUT /:id/confirm-cash pada pembayaran VIRTUAL_ACCOUNT -> 403 (bukan CASH)', async () => {
      const res = await request(app)
        .put(`/api/payments/${paymentId}/confirm-cash`)
        .set('Authorization', `Bearer ${token}`);
      expect(res.status).toBe(403);
    });

    test('Alur pembayaran CASH: create -> confirm-cash -> PAID', async () => {
      const create = await request(app)
        .post('/api/payments')
        .set('Authorization', `Bearer ${token}`)
        .send({ emergency_request_id: emergencyId, amount: 50000, method: 'CASH' });
      expect(create.status).toBe(201);

      const confirm = await request(app)
        .put(`/api/payments/${create.body.id}/confirm-cash`)
        .set('Authorization', `Bearer ${token}`);
      expect(confirm.status).toBe(200);
      expect(confirm.body.status).toBe('PAID');
    });

    test('GET /api/payments mengembalikan riwayat, terurut dari terbaru', async () => {
      const res = await request(app).get('/api/payments').set('Authorization', `Bearer ${token}`);
      expect(res.status).toBe(200);
      expect(res.body.length).toBe(2);
    });

    // Ditambahkan Sesi 7: item "belum dikerjakan" dari blueprint - transaction_status
    // 'expire'/'cancel' punya logic di controller (map ke status FAILED) sejak Sesi 4,
    // tapi belum ada test integrasi spesifik untuk jalur itu (hanya 'settlement' yang dites
    // sampai Sesi 6). Test-test di bawah dijalankan SETELAH test riwayat di atas supaya
    // tidak mengubah hitungan `length).toBe(2)` pada test tersebut.
    describe('Webhook: transaction_status expire/cancel (belum dites sampai Sesi 6)', () => {
      test('transaction_status "expire" -> 200, status jadi FAILED, paid_at tetap null', async () => {
        const create = await request(app)
          .post('/api/payments')
          .set('Authorization', `Bearer ${token}`)
          .send({ emergency_request_id: emergencyId, amount: 90000, method: 'VIRTUAL_ACCOUNT' });
        expect(create.status).toBe(201);
        const expireOrderId = create.body.payment_reference;

        const sig = computeSig({ order_id: expireOrderId, status_code: '200', gross_amount: '90000.00' });
        const res = await request(app).post('/api/payments/webhook/midtrans').send({
          order_id: expireOrderId,
          status_code: '200',
          gross_amount: '90000.00',
          signature_key: sig,
          transaction_status: 'expire',
        });
        expect(res.status).toBe(200);

        const check = await request(app)
          .get(`/api/payments/${create.body.id}`)
          .set('Authorization', `Bearer ${token}`);
        expect(check.body.status).toBe('FAILED');
        expect(check.body.paid_at).toBeNull();
      });

      test('transaction_status "cancel" -> 200, status jadi FAILED', async () => {
        const create = await request(app)
          .post('/api/payments')
          .set('Authorization', `Bearer ${token}`)
          .send({ emergency_request_id: emergencyId, amount: 65000, method: 'E_WALLET' });
        expect(create.status).toBe(201);
        const cancelOrderId = create.body.payment_reference;

        const sig = computeSig({ order_id: cancelOrderId, status_code: '200', gross_amount: '65000.00' });
        const res = await request(app).post('/api/payments/webhook/midtrans').send({
          order_id: cancelOrderId,
          status_code: '200',
          gross_amount: '65000.00',
          signature_key: sig,
          transaction_status: 'cancel',
        });
        expect(res.status).toBe(200);

        const check = await request(app)
          .get(`/api/payments/${create.body.id}`)
          .set('Authorization', `Bearer ${token}`);
        expect(check.body.status).toBe('FAILED');
      });

      test('webhook "cancel" yang datang TERLAMBAT setelah pembayaran sudah PAID -> status TETAP PAID, tidak boleh anjlok', async () => {
        // `paymentId`/`orderId` di sini adalah pembayaran VA yang SUDAH di-PAID-kan lewat
        // test "signature VALID -> 200, status jadi PAID" di atas. Ini mensimulasikan webhook
        // gateway yang datang out-of-order (mis. retry lama dari gateway sungguhan) - status
        // yang sudah lunas tidak boleh berubah jadi FAILED hanya karena webhook basi/telat.
        const sig = computeSig({ order_id: orderId, status_code: '200', gross_amount: '175000.00' });
        const res = await request(app).post('/api/payments/webhook/midtrans').send({
          order_id: orderId,
          status_code: '200',
          gross_amount: '175000.00',
          signature_key: sig,
          transaction_status: 'cancel',
        });
        expect(res.status).toBe(200);

        const check = await request(app).get(`/api/payments/${paymentId}`).set('Authorization', `Bearer ${token}`);
        expect(check.body.status).toBe('PAID');
      });
    });
  });
});
