// OtoShield - Dashboard Mekanik/Operator
// Vanilla JS, tanpa framework - memanggil endpoint /api/admin/* yang
// dilindungi header x-admin-key (lihat backend/src/middleware/admin.middleware.js).
// Ini adalah dashboard operator/dispatcher, sengaja disimpan sesederhana
// mungkin (bukan Artifact/prototype) karena dijalankan dari server Express-nya
// sendiri, jadi localStorage aman dipakai untuk menyimpan admin key di sesi
// browser operator.

const els = {
  adminKey: document.getElementById('adminKey'),
  saveKeyBtn: document.getElementById('saveKeyBtn'),
  keyStatus: document.getElementById('keyStatus'),
  staffPhone: document.getElementById('staffPhone'),
  staffPassword: document.getElementById('staffPassword'),
  staffLoginBtn: document.getElementById('staffLoginBtn'),
  staffLoginBox: document.getElementById('staffLoginBox'),
  staffInfoBox: document.getElementById('staffInfoBox'),
  staffInfoText: document.getElementById('staffInfoText'),
  staffLogoutBtn: document.getElementById('staffLogoutBtn'),
  statusFilter: document.getElementById('statusFilter'),
  refreshBtn: document.getElementById('refreshBtn'),
  autoRefresh: document.getElementById('autoRefresh'),
  tbody: document.getElementById('emergencyTableBody'),
  modal: document.getElementById('actionModal'),
  modalEmergencyId: document.getElementById('modalEmergencyId'),
  modalStatus: document.getElementById('modalStatus'),
  modalWorkshop: document.getElementById('modalWorkshop'),
  modalLat: document.getElementById('modalLat'),
  modalLng: document.getElementById('modalLng'),
  sendLocationBtn: document.getElementById('sendLocationBtn'),
  cancelModalBtn: document.getElementById('cancelModalBtn'),
  submitModalBtn: document.getElementById('submitModalBtn'),
};

let activeEmergencyId = null;
let refreshTimer = null;
let socket = null;
let staffToken = null;
let staffInfo = null;

function adminKey() {
  return els.adminKey.value.trim();
}

function setConnected(isLive) {
  els.keyStatus.classList.toggle('live', !!isLive);
}

// Sesi 3: dashboard sekarang punya DUA cara autentikasi ke /api/admin/* dan
// /api/staff (lihat backend/src/middleware/adminOrStaff.middleware.js):
//   1. Login staf per-orang (Authorization: Bearer <token>) - DIUTAMAKAN,
//      supaya setiap perubahan status tercatat atas nama staf yang login.
//   2. Admin API Key lama (x-admin-key) - mode darurat/bootstrap.
// apiFetch() otomatis memilih salah satu, prioritas ke token staf jika ada.
async function apiFetch(pathname, options = {}) {
  const headers = { 'Content-Type': 'application/json', ...(options.headers || {}) };
  if (staffToken) {
    headers['Authorization'] = `Bearer ${staffToken}`;
  } else {
    headers['x-admin-key'] = adminKey();
  }
  const res = await fetch(pathname, { ...options, headers });
  if (!res.ok) {
    const body = await res.json().catch(() => ({}));
    throw new Error(body.message || `Request gagal (${res.status})`);
  }
  if (res.status === 204) return null;
  return res.json();
}

function fmtTime(iso) {
  const d = new Date(iso);
  return d.toLocaleString('id-ID', { dateStyle: 'short', timeStyle: 'short' });
}

function fmtMoney(min, max) {
  if (min == null || max == null) return '<span class="muted">-</span>';
  const f = (n) => 'Rp' + Number(n).toLocaleString('id-ID');
  return `${f(min)} - ${f(max)}`;
}

function renderRows(rows) {
  if (!rows.length) {
    els.tbody.innerHTML = '<tr><td colspan="7" class="empty">Tidak ada permintaan SOS untuk filter ini.</td></tr>';
    return;
  }

  els.tbody.innerHTML = rows
    .map((r) => `
      <tr>
        <td class="mono small">${fmtTime(r.created_at)}</td>
        <td>${r.user_name}<br><span class="muted small mono">${r.user_phone}</span></td>
        <td>${r.issue_description ? escapeHtml(r.issue_description) : '<span class="muted">-</span>'}</td>
        <td class="mono small">${Number(r.latitude).toFixed(5)}, ${Number(r.longitude).toFixed(5)}</td>
        <td class="small">${fmtMoney(r.estimated_cost_min, r.estimated_cost_max)}</td>
        <td><span class="badge ${r.status}">${r.status}</span></td>
        <td><button class="secondary small" data-action-id="${r.id}">Kelola</button></td>
      </tr>
    `)
    .join('');

  els.tbody.querySelectorAll('[data-action-id]').forEach((btn) => {
    btn.addEventListener('click', () => openModal(btn.getAttribute('data-action-id')));
  });
}

function escapeHtml(str) {
  const div = document.createElement('div');
  div.textContent = str;
  return div.innerHTML;
}

async function loadEmergencies() {
  if (!adminKey()) return;
  try {
    const qs = els.statusFilter.value ? `?status=${els.statusFilter.value}` : '';
    const rows = await apiFetch(`/api/admin/emergency${qs}`);
    renderRows(rows);
    setConnected(true);
  } catch (err) {
    setConnected(false);
    els.tbody.innerHTML = `<tr><td colspan="7" class="empty">${escapeHtml(err.message)}</td></tr>`;
  }
}

async function loadWorkshopsIntoModal() {
  try {
    const workshops = await apiFetch('/api/admin/workshops');
    els.modalWorkshop.innerHTML =
      '<option value="">(tidak diubah)</option>' +
      workshops.map((w) => `<option value="${w.id}">${escapeHtml(w.name)}</option>`).join('');
  } catch (err) {
    // Non-fatal: modal masih bisa dipakai untuk ubah status tanpa memilih bengkel
    console.warn('Gagal memuat daftar bengkel:', err.message);
  }
}

function openModal(emergencyId) {
  activeEmergencyId = emergencyId;
  els.modalEmergencyId.textContent = `ID: ${emergencyId}`;
  els.modalLat.value = '';
  els.modalLng.value = '';
  loadWorkshopsIntoModal();
  els.modal.classList.remove('hidden');
}

function closeModal() {
  els.modal.classList.add('hidden');
  activeEmergencyId = null;
}

async function submitStatusChange() {
  if (!activeEmergencyId) return;
  try {
    await apiFetch(`/api/admin/emergency/${activeEmergencyId}/status`, {
      method: 'PUT',
      body: JSON.stringify({
        status: els.modalStatus.value,
        workshop_id: els.modalWorkshop.value || undefined,
      }),
    });
    closeModal();
    loadEmergencies();
  } catch (err) {
    alert(err.message);
  }
}

function sendMechanicLocation() {
  if (!activeEmergencyId) return;
  const latitude = parseFloat(els.modalLat.value);
  const longitude = parseFloat(els.modalLng.value);
  if (Number.isNaN(latitude) || Number.isNaN(longitude)) {
    alert('Isi latitude dan longitude yang valid.');
    return;
  }
  ensureSocket();
  socket.emit('emergency:location:update', { emergencyId: activeEmergencyId, latitude, longitude });
}

function ensureSocket() {
  if (socket) return;
  socket = io(); // terhubung ke server yang sama (lihat backend/src/sockets/emergency.socket.js)
}

function scheduleAutoRefresh() {
  clearInterval(refreshTimer);
  if (els.autoRefresh.checked) {
    refreshTimer = setInterval(loadEmergencies, 5000);
  }
}

// --- Login staf ---
async function loginStaff() {
  const phone = els.staffPhone.value.trim();
  const password = els.staffPassword.value;
  if (!phone || !password) {
    alert('Isi nomor telepon dan password staf.');
    return;
  }
  try {
    const res = await fetch('/api/staff/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ phone, password }),
    });
    const body = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(body.message || 'Login gagal.');

    staffToken = body.token;
    staffInfo = body.staff;
    localStorage.setItem('otoshield_staff_token', staffToken);
    localStorage.setItem('otoshield_staff_info', JSON.stringify(staffInfo));
    showStaffLoggedIn();
    loadEmergencies();
  } catch (err) {
    alert(err.message);
  }
}

function logoutStaff() {
  staffToken = null;
  staffInfo = null;
  localStorage.removeItem('otoshield_staff_token');
  localStorage.removeItem('otoshield_staff_info');
  els.staffLoginBox.classList.remove('hidden');
  els.staffInfoBox.classList.add('hidden');
  setConnected(false);
}

function showStaffLoggedIn() {
  els.staffLoginBox.classList.add('hidden');
  els.staffInfoBox.classList.remove('hidden');
  els.staffInfoText.textContent = staffInfo ? `${staffInfo.name} (${staffInfo.role})` : 'Staf login';
  setConnected(true);
}

// --- Wiring ---
els.staffLoginBtn.addEventListener('click', loginStaff);
els.staffLogoutBtn.addEventListener('click', logoutStaff);
els.saveKeyBtn.addEventListener('click', () => {
  localStorage.setItem('otoshield_admin_key', adminKey());
  loadEmergencies();
});
els.refreshBtn.addEventListener('click', loadEmergencies);
els.statusFilter.addEventListener('change', loadEmergencies);
els.autoRefresh.addEventListener('change', scheduleAutoRefresh);
els.cancelModalBtn.addEventListener('click', closeModal);
els.submitModalBtn.addEventListener('click', submitStatusChange);
els.sendLocationBtn.addEventListener('click', sendMechanicLocation);

// Muat sesi tersimpan saat halaman dibuka: utamakan token staf, admin key sebagai fallback
const savedStaffToken = localStorage.getItem('otoshield_staff_token');
const savedStaffInfo = localStorage.getItem('otoshield_staff_info');
const savedKey = localStorage.getItem('otoshield_admin_key');
if (savedStaffToken) {
  staffToken = savedStaffToken;
  staffInfo = savedStaffInfo ? JSON.parse(savedStaffInfo) : null;
  showStaffLoggedIn();
  loadEmergencies();
} else if (savedKey) {
  els.adminKey.value = savedKey;
  loadEmergencies();
}
scheduleAutoRefresh();
