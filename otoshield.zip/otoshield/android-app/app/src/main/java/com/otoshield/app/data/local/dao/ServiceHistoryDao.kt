package com.otoshield.app.data.local.dao

import androidx.room.*
import com.otoshield.app.data.local.entity.ServiceHistoryEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface ServiceHistoryDao {
    @Query("SELECT * FROM service_history WHERE vehicleId = :vehicleId ORDER BY serviceDate DESC")
    fun observeForVehicle(vehicleId: String): Flow<List<ServiceHistoryEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(items: List<ServiceHistoryEntity>)
}
