package com.otoshield.app.ui.screens.servicebook

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.otoshield.app.data.local.entity.VehicleEntity
import com.otoshield.app.data.remote.dto.AddVehicleRequest
import com.otoshield.app.data.remote.dto.ReminderDto
import com.otoshield.app.data.remote.dto.UpdateVehicleRequest
import com.otoshield.app.data.repository.VehicleRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class ServiceBookUiState(
    val isSyncing: Boolean = true,
    val selectedVehicleId: String? = null,
    val reminders: List<ReminderDto> = emptyList(),
    val error: String? = null
)

/**
 * Fitur 4 blueprint: Digital Service Book.
 * Data kendaraan diambil dari Room (cache lokal, offline-friendly) dan
 * disinkronkan dari server saat init(). Pengingat servis dihitung backend
 * berdasarkan odometer & tanggal servis terakhir.
 */
class ServiceBookViewModel(private val repository: VehicleRepository) : ViewModel() {

    var uiState by mutableStateOf(ServiceBookUiState())
        private set

    val vehicles = repository.observeVehicles()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    init {
        viewModelScope.launch {
            val result = repository.refreshVehicles()
            uiState = uiState.copy(
                isSyncing = false,
                error = result.exceptionOrNull()?.message
            )
        }
    }

    fun addVehicle(brand: String, model: String, year: Int?, plate: String?, km: Int) {
        viewModelScope.launch {
            repository.addVehicle(AddVehicleRequest(brand, model, year, plate, km))
        }
    }

    // Edit & hapus kendaraan (item "belum dikerjakan" #8 - Sesi 3)
    fun updateVehicle(vehicleId: String, brand: String, model: String, year: Int?, plate: String?) {
        viewModelScope.launch {
            val result = repository.updateVehicle(
                vehicleId,
                UpdateVehicleRequest(brand = brand, model = model, year = year, license_plate = plate)
            )
            result.onFailure { e -> uiState = uiState.copy(error = e.message) }
        }
    }

    fun deleteVehicle(vehicleId: String) {
        viewModelScope.launch {
            val result = repository.deleteVehicle(vehicleId)
            result.onFailure { e -> uiState = uiState.copy(error = e.message) }
            if (uiState.selectedVehicleId == vehicleId) {
                uiState = uiState.copy(selectedVehicleId = null, reminders = emptyList())
            }
        }
    }

    fun loadReminders(vehicleId: String) {
        viewModelScope.launch {
            uiState = uiState.copy(selectedVehicleId = vehicleId)
            val result = repository.getReminders(vehicleId)
            result.fold(
                onSuccess = { res -> uiState = uiState.copy(reminders = res.reminders) },
                onFailure = { e -> uiState = uiState.copy(error = e.message) }
            )
        }
    }
}
