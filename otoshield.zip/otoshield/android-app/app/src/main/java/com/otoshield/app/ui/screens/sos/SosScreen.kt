package com.otoshield.app.ui.screens.sos

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.google.accompanist.permissions.ExperimentalPermissionsApi
import com.google.accompanist.permissions.rememberPermissionState
import com.google.accompanist.permissions.isGranted
import com.otoshield.app.di.ServiceLocator
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.ViewModel
import android.Manifest

@OptIn(ExperimentalPermissionsApi::class)
@Composable
fun SosScreen(onSosSent: (String) -> Unit, onBack: () -> Unit) {
    val viewModel: SosViewModel = viewModel(factory = object : ViewModelProvider.Factory {
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            @Suppress("UNCHECKED_CAST")
            return SosViewModel(ServiceLocator.emergencyRepository, ServiceLocator.locationHelper) as T
        }
    })

    val locationPermission = rememberPermissionState(Manifest.permission.ACCESS_FINE_LOCATION)
    var issueText by remember { mutableStateOf("") }
    val state = viewModel.uiState

    LaunchedEffect(state.emergencyId) {
        state.emergencyId?.let { onSosSent(it) }
    }

    Scaffold(topBar = { TopAppBar(title = { Text("SOS Darurat") }) }) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize()
                .padding(20.dp)
        ) {
            Text("Ceritakan singkat kerusakan yang dialami:", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(
                value = issueText,
                onValueChange = { issueText = it },
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("Contoh: Ban bocor & mesin overheat") },
                minLines = 3
            )

            Spacer(Modifier.height(16.dp))

            if (!locationPermission.status.isGranted) {
                Text(
                    "Aplikasi memerlukan izin lokasi untuk mencari bantuan terdekat.",
                    color = MaterialTheme.colorScheme.error
                )
                Spacer(Modifier.height(8.dp))
                Button(onClick = { locationPermission.launchPermissionRequest() }) {
                    Text("Izinkan Akses Lokasi")
                }
            } else {
                Button(
                    onClick = { viewModel.submitSos(issueText) },
                    enabled = !state.isSubmitting,
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    if (state.isSubmitting) {
                        CircularProgressIndicator(modifier = Modifier.size(20.dp), color = MaterialTheme.colorScheme.onPrimary)
                        Spacer(Modifier.width(8.dp))
                        Text(if (state.isLoadingLocation) "Mengambil lokasi GPS..." else "Mengirim...")
                    } else {
                        Text("Kirim Permintaan SOS")
                    }
                }
            }

            state.error?.let {
                Spacer(Modifier.height(12.dp))
                Text(it, color = MaterialTheme.colorScheme.error)
            }

            Spacer(Modifier.weight(1f))
            TextButton(onClick = onBack) { Text("Kembali") }
        }
    }
}
