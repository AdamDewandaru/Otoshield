package com.otoshield.app.ui.screens.workshop

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewmodel.compose.viewModel
import com.otoshield.app.data.remote.dto.WorkshopDto
import com.otoshield.app.di.ServiceLocator
import com.otoshield.app.ui.theme.OtoBlue
import androidx.compose.foundation.clickable

@Composable
fun WorkshopListScreen(onWorkshopClick: (String) -> Unit, onBack: () -> Unit) {
    val viewModel: WorkshopListViewModel = viewModel(factory = object : ViewModelProvider.Factory {
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            @Suppress("UNCHECKED_CAST")
            return WorkshopListViewModel(ServiceLocator.workshopRepository, ServiceLocator.locationHelper) as T
        }
    })
    val state = viewModel.uiState

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Direktori Bengkel") },
                actions = {
                    FilterChip(
                        selected = state.verifiedOnly,
                        onClick = { viewModel.toggleVerifiedOnly() },
                        label = { Text("Terverifikasi") }
                    )
                    Spacer(Modifier.width(8.dp))
                }
            )
        }
    ) { padding ->
        when {
            state.isLoading -> Box(Modifier.padding(padding).fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }
            state.error != null -> Box(Modifier.padding(padding).fillMaxSize(), contentAlignment = Alignment.Center) {
                Text(state.error, color = MaterialTheme.colorScheme.error)
            }
            else -> LazyColumn(modifier = Modifier.padding(padding).fillMaxSize()) {
                items(state.workshops) { workshop ->
                    WorkshopRow(workshop, onClick = { onWorkshopClick(workshop.id) })
                    Divider()
                }
            }
        }
    }
}

@Composable
private fun WorkshopRow(workshop: WorkshopDto, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(workshop.name, style = MaterialTheme.typography.titleMedium)
                if (workshop.is_verified) {
                    Spacer(Modifier.width(4.dp))
                    Icon(Icons.Default.Verified, contentDescription = "Terverifikasi", tint = OtoBlue, modifier = Modifier.size(16.dp))
                }
            }
            workshop.address?.let {
                Text(it, style = MaterialTheme.typography.bodyMedium, maxLines = 1)
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Star, contentDescription = null, tint = MaterialTheme.colorScheme.tertiary, modifier = Modifier.size(14.dp))
                Spacer(Modifier.width(2.dp))
                Text("${"%.1f".format(workshop.rating)} (${workshop.rating_count})", style = MaterialTheme.typography.bodyMedium)
                workshop.distance_km?.let {
                    Text(" · ${"%.1f".format(it)} km", style = MaterialTheme.typography.bodyMedium)
                }
            }
        }
    }
}
