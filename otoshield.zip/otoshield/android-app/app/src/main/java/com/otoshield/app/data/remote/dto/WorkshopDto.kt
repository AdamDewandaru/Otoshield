package com.otoshield.app.data.remote.dto

data class WorkshopDto(
    val id: String,
    val name: String,
    val address: String?,
    val latitude: Double,
    val longitude: Double,
    val phone: String?,
    val is_verified: Boolean,
    val rating: Double,
    val rating_count: Int,
    val offers_towing: Boolean,
    val distance_km: Double? = null
)

data class WorkshopServiceDto(
    val id: String,
    val service_name: String,
    val labor_fee_min: Int,
    val labor_fee_max: Int,
    val part_price_min: Int?,
    val part_price_max: Int?
)

data class ReviewDto(val id: String, val rating: Int, val comment: String?, val created_at: String, val user_name: String)

data class WorkshopDetailDto(
    val id: String,
    val name: String,
    val address: String?,
    val latitude: Double,
    val longitude: Double,
    val phone: String?,
    val is_verified: Boolean,
    val rating: Double,
    val rating_count: Int,
    val services: List<WorkshopServiceDto>,
    val reviews: List<ReviewDto>
)

data class AddReviewRequest(val rating: Int, val comment: String?)
