package com.otoshield.app.ui.screens.estimator

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewmodel.compose.viewModel
import com.otoshield.app.di.ServiceLocator

/**
 * Fitur 3 blueprint: input gejala kerusakan bebas teks -> munculkan
 * kisaran estimasi biaya wajar di pasaran (dicocokkan lewat backend).
 */
@Composable
fun CostEstimatorScreen(onBack: () -> Unit) {
    val viewModel: EstimatorViewModel = viewModel(factory = object : ViewModelProvider.Factory {
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            @Suppress("UNCHECKED_CAST")
            return EstimatorViewModel(ServiceLocator.estimatorRepository) as T
        }
    })
    var symptomText by remember { mutableStateOf("") }
    val state = viewModel.uiState

    Scaffold(topBar = { TopAppBar(title = { Text("Estimator Biaya Cerdas") }) }) { padding ->
        Column(modifier = Modifier.padding(padding).fillMaxSize().padding(20.dp)) {
            Text("Gejala kerusakan apa yang dialami?", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(
                value = symptomText,
                onValueChange = { symptomText = it },
                placeholder = { Text("Contoh: Rem bunyi berdecit") },
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(12.dp))
            Button(onClick = { viewModel.estimate(symptomText) }, modifier = Modifier.fillMaxWidth()) {
                Text("Hitung Estimasi")
            }

            Spacer(Modifier.height(20.dp))

            if (state.isLoading) {
                CircularProgressIndicator()
            }

            state.error?.let { Text(it, color = MaterialTheme.colorScheme.error) }

            state.result?.let { result ->
                if (result.matched) {
                    Card(modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(16.dp)) {
                            Text("Kemungkinan: ${result.issue_category}", style = MaterialTheme.typography.titleMedium)
                            Spacer(Modifier.height(4.dp))
                            Text(
                                "Estimasi biaya: Rp${result.estimated_min} - Rp${result.estimated_max}",
                                style = MaterialTheme.typography.headlineMedium
                            )
                            if (result.alternatives.isNotEmpty()) {
                                Spacer(Modifier.height(12.dp))
                                Text("Kemungkinan lain:", style = MaterialTheme.typography.bodyMedium)
                                result.alternatives.forEach { alt ->
                                    Text("• ${alt.issue_category}: Rp${alt.estimated_min} - Rp${alt.estimated_max}")
                                }
                            }
                        }
                    }
                } else {
                    Text(result.message ?: "Gejala tidak dikenali.", color = MaterialTheme.colorScheme.error)
                }
            }

            Spacer(Modifier.weight(1f))
            TextButton(onClick = onBack) { Text("Kembali") }
        }
    }
}
