package com.otoshield.app.data.remote.dto

data class VehicleDto(
    val id: String,
    val brand: String,
    val model: String,
    val year: Int?,
    val license_plate: String?,
    val current_kilometer: Int,
    val last_service_km: Int,
    val last_service_date: String?
)

data class AddVehicleRequest(
    val brand: String,
    val model: String,
    val year: Int?,
    val license_plate: String?,
    val current_kilometer: Int
)

// Edit kendaraan (item "belum dikerjakan" #8 - Sesi 3): semua field opsional,
// hanya field yang diisi yang akan diperbarui di backend (lihat updateVehicle
// di vehicles.controller.js, pakai COALESCE).
data class UpdateVehicleRequest(
    val brand: String? = null,
    val model: String? = null,
    val year: Int? = null,
    val license_plate: String? = null
)

data class ReminderDto(val type: String, val message: String, val urgent: Boolean)
data class ReminderResponse(val vehicle: VehicleDto, val reminders: List<ReminderDto>)

data class ServiceHistoryDto(
    val id: String,
    val vehicle_id: String,
    val workshop_id: String?,
    val service_type: String,
    val odometer: Int,
    val cost: Int?,
    val notes: String?,
    val service_date: String
)

data class AddServiceHistoryRequest(
    val workshop_id: String?,
    val service_type: String,
    val odometer: Int,
    val cost: Int?,
    val notes: String?
)
