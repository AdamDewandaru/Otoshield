package com.otoshield.app.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.otoshield.app.data.local.dao.ServiceHistoryDao
import com.otoshield.app.data.local.dao.VehicleDao
import com.otoshield.app.data.local.entity.ServiceHistoryEntity
import com.otoshield.app.data.local.entity.VehicleEntity

@Database(
    entities = [VehicleEntity::class, ServiceHistoryEntity::class],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun vehicleDao(): VehicleDao
    abstract fun serviceHistoryDao(): ServiceHistoryDao

    companion object {
        @Volatile private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "otoshield.db"
                ).build().also { INSTANCE = it }
            }
        }
    }
}
