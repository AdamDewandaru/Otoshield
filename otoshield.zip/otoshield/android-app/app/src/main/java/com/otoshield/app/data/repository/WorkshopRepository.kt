package com.otoshield.app.data.repository

import com.otoshield.app.data.remote.ApiService
import com.otoshield.app.data.remote.dto.AddReviewRequest
import com.otoshield.app.data.remote.dto.WorkshopDetailDto
import com.otoshield.app.data.remote.dto.WorkshopDto

class WorkshopRepository(private val api: ApiService) {

    suspend fun getNearbyWorkshops(
        lat: Double?,
        lng: Double?,
        radiusKm: Double? = 10.0,
        verifiedOnly: Boolean = false
    ): Result<List<WorkshopDto>> = try {
        val response = api.getWorkshops(lat, lng, radiusKm, verifiedOnly)
        if (response.isSuccessful && response.body() != null) {
            Result.success(response.body()!!)
        } else {
            Result.failure(Exception("Gagal memuat daftar bengkel (${response.code()})"))
        }
    } catch (e: Exception) {
        Result.failure(e)
    }

    suspend fun getWorkshopDetail(id: String): Result<WorkshopDetailDto> = try {
        val response = api.getWorkshopDetail(id)
        if (response.isSuccessful && response.body() != null) {
            Result.success(response.body()!!)
        } else {
            Result.failure(Exception("Gagal memuat detail bengkel (${response.code()})"))
        }
    } catch (e: Exception) {
        Result.failure(e)
    }

    suspend fun addReview(token: String, workshopId: String, rating: Int, comment: String?): Result<Unit> = try {
        val response = api.addReview(token, workshopId, AddReviewRequest(rating, comment))
        if (response.isSuccessful) Result.success(Unit)
        else Result.failure(Exception("Gagal mengirim ulasan (${response.code()})"))
    } catch (e: Exception) {
        Result.failure(e)
    }
}
