package com.otoshield.app.data.remote

import com.otoshield.app.BuildConfig
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.util.concurrent.TimeUnit

/**
 * Singleton penyedia instance Retrofit + OkHttp.
 * BASE_API_URL didefinisikan di app/build.gradle.kts (buildConfigField).
 * Default: http://10.0.2.2:4000/api/  (alamat localhost host machine dari emulator Android)
 */
object RetrofitInstance {

    private val loggingInterceptor = HttpLoggingInterceptor().apply {
        level = if (BuildConfig.DEBUG) HttpLoggingInterceptor.Level.BODY else HttpLoggingInterceptor.Level.NONE
    }

    private val okHttpClient = OkHttpClient.Builder()
        .addInterceptor(loggingInterceptor)
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .build()

    val api: ApiService by lazy {
        Retrofit.Builder()
            .baseUrl(BuildConfig.BASE_API_URL)
            .client(okHttpClient)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(ApiService::class.java)
    }

    /**
     * Item "belum dikerjakan" #10: `photo_url` dari backend BUKAN selalu URL absolut.
     * Driver lokal (default, lihat backend/src/services/storage/localDriver.js) mengembalikan
     * path relatif seperti "/uploads/emergency/xxx.jpg" yang di-serve statis oleh Express di
     * ROOT server (bukan di bawah "/api/" - lihat app.js `app.use('/uploads', express.static(...))`),
     * sedangkan driver S3 (STORAGE_DRIVER=s3) mengembalikan URL absolut penuh (https://...).
     * Fungsi ini menyamakan keduanya jadi URL yang bisa langsung dipakai Coil/AsyncImage.
     */
    fun resolveMediaUrl(path: String?): String? {
        if (path.isNullOrBlank()) return null
        if (path.startsWith("http://") || path.startsWith("https://")) return path
        val serverRoot = BuildConfig.BASE_API_URL.removeSuffix("api/").trimEnd('/')
        return serverRoot + path
    }
}
