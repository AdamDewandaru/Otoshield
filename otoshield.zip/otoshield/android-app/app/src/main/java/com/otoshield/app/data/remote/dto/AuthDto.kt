package com.otoshield.app.data.remote.dto

data class RegisterRequest(val name: String, val phone: String, val email: String?, val password: String)
data class LoginRequest(val phone: String, val password: String)
data class AuthResponse(val user: UserDto, val token: String)
data class UserDto(val id: String, val name: String, val phone: String, val email: String?)

// Profil pengguna (item "belum dikerjakan" #8 di otoshield_blueprint.md - Sesi 3)
data class UpdateProfileRequest(val name: String? = null, val email: String? = null, val phone: String? = null)
