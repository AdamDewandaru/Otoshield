package com.otoshield.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import com.otoshield.app.di.ServiceLocator
import com.otoshield.app.navigation.OtoShieldNavGraph
import com.otoshield.app.ui.theme.OtoShieldTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ServiceLocator.init(applicationContext)

        setContent {
            OtoShieldTheme {
                OtoShieldNavGraph()
            }
        }
    }
}
