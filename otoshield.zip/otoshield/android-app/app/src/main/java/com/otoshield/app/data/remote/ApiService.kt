package com.otoshield.app.data.remote

import com.otoshield.app.data.remote.dto.*
import okhttp3.MultipartBody
import retrofit2.Response
import retrofit2.http.*

/**
 * Kontrak komunikasi ke backend OtoShield (lihat folder /backend).
 * Base URL dikonfigurasi di RetrofitInstance.kt / BuildConfig.BASE_API_URL.
 */
interface ApiService {

    // ---- Auth ----
    @POST("auth/register")
    suspend fun register(@Body body: RegisterRequest): Response<AuthResponse>

    @POST("auth/login")
    suspend fun login(@Body body: LoginRequest): Response<AuthResponse>

    // Profil pengguna (item "belum dikerjakan" #8 - Sesi 3)
    @GET("auth/me")
    suspend fun getProfile(@Header("Authorization") token: String): Response<UserDto>

    @PUT("auth/me")
    suspend fun updateProfile(@Header("Authorization") token: String, @Body body: UpdateProfileRequest): Response<UserDto>

    // ---- Vehicles / Digital Service Book ----
    @GET("vehicles")
    suspend fun getVehicles(@Header("Authorization") token: String): Response<List<VehicleDto>>

    @POST("vehicles")
    suspend fun addVehicle(@Header("Authorization") token: String, @Body body: AddVehicleRequest): Response<VehicleDto>

    // Edit & hapus kendaraan (item "belum dikerjakan" #8 - Sesi 3)
    @PUT("vehicles/{id}")
    suspend fun updateVehicle(
        @Header("Authorization") token: String,
        @Path("id") vehicleId: String,
        @Body body: UpdateVehicleRequest
    ): Response<VehicleDto>

    @DELETE("vehicles/{id}")
    suspend fun deleteVehicle(@Header("Authorization") token: String, @Path("id") vehicleId: String): Response<Unit>

    @PUT("vehicles/{id}/odometer")
    suspend fun updateOdometer(
        @Header("Authorization") token: String,
        @Path("id") vehicleId: String,
        @Body body: Map<String, Int>
    ): Response<VehicleDto>

    @GET("vehicles/{id}/reminders")
    suspend fun getReminders(@Header("Authorization") token: String, @Path("id") vehicleId: String): Response<ReminderResponse>

    @GET("vehicles/{id}/history")
    suspend fun getServiceHistory(@Header("Authorization") token: String, @Path("id") vehicleId: String): Response<List<ServiceHistoryDto>>

    @POST("vehicles/{id}/history")
    suspend fun addServiceHistory(
        @Header("Authorization") token: String,
        @Path("id") vehicleId: String,
        @Body body: AddServiceHistoryRequest
    ): Response<ServiceHistoryDto>

    // ---- Workshops / Direktori Bengkel ----
    @GET("workshops")
    suspend fun getWorkshops(
        @Query("lat") lat: Double? = null,
        @Query("lng") lng: Double? = null,
        @Query("radius") radiusKm: Double? = null,
        @Query("verified_only") verifiedOnly: Boolean? = null
    ): Response<List<WorkshopDto>>

    @GET("workshops/{id}")
    suspend fun getWorkshopDetail(@Path("id") id: String): Response<WorkshopDetailDto>

    @POST("workshops/{id}/reviews")
    suspend fun addReview(
        @Header("Authorization") token: String,
        @Path("id") id: String,
        @Body body: AddReviewRequest
    ): Response<ReviewDto>

    // ---- Emergency / SOS ----
    @POST("emergency")
    suspend fun createEmergency(@Header("Authorization") token: String, @Body body: CreateEmergencyRequest): Response<CreateEmergencyResponse>

    @GET("emergency/{id}")
    suspend fun getEmergency(@Header("Authorization") token: String, @Path("id") id: String): Response<EmergencyRequestDto>

    // Upload foto kerusakan (item "belum dikerjakan" #10). Field form-data HARUS bernama "photo"
    // - lihat uploadEmergencyPhoto.single('photo') di backend/src/routes/emergency.routes.js.
    @Multipart
    @POST("emergency/{id}/photo")
    suspend fun uploadEmergencyPhoto(
        @Header("Authorization") token: String,
        @Path("id") id: String,
        @Part photo: MultipartBody.Part
    ): Response<EmergencyRequestDto>

    // ---- Smart Cost Estimator ----
    @POST("estimator/estimate")
    suspend fun estimateCost(@Body body: EstimateRequest): Response<EstimateResponse>

    // ---- Pembayaran Digital (Sesi 4: pola gateway Midtrans-style, lihat PaymentDto.kt) ----
    @POST("payments")
    suspend fun createPayment(
        @Header("Authorization") token: String,
        @Body body: CreatePaymentRequest
    ): Response<CreatePaymentResponse>

    @GET("payments/{id}")
    suspend fun getPayment(@Header("Authorization") token: String, @Path("id") id: String): Response<PaymentDto>

    @GET("payments")
    suspend fun listPayments(@Header("Authorization") token: String): Response<List<PaymentDto>>

    // Khusus method CASH - VA/E-WALLET ditolak 403 oleh backend, harus lewat webhook gateway.
    @PUT("payments/{id}/confirm-cash")
    suspend fun confirmCashPayment(@Header("Authorization") token: String, @Path("id") id: String): Response<PaymentDto>
}
