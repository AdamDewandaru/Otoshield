package com.otoshield.app.di

import android.content.Context
import com.otoshield.app.data.local.AppDatabase
import com.otoshield.app.data.remote.RetrofitInstance
import com.otoshield.app.data.repository.EmergencyRepository
import com.otoshield.app.data.repository.EstimatorRepository
import com.otoshield.app.data.repository.PaymentRepository
import com.otoshield.app.data.repository.VehicleRepository
import com.otoshield.app.data.repository.WorkshopRepository
import com.otoshield.app.util.LocationHelper
import com.otoshield.app.util.SessionManager

/**
 * Service Locator manual (pengganti Hilt/Dagger yang lebih ringkas untuk MVP ini).
 * Cukup panggil ServiceLocator.init(context) sekali di Application/MainActivity.
 */
object ServiceLocator {
    private lateinit var appContext: Context

    lateinit var sessionManager: SessionManager
        private set
    lateinit var locationHelper: LocationHelper
        private set
    lateinit var workshopRepository: WorkshopRepository
        private set
    lateinit var estimatorRepository: EstimatorRepository
        private set
    lateinit var emergencyRepository: EmergencyRepository
        private set
    lateinit var vehicleRepository: VehicleRepository
        private set
    lateinit var paymentRepository: PaymentRepository
        private set

    fun init(context: Context) {
        if (::appContext.isInitialized) return
        appContext = context.applicationContext

        sessionManager = SessionManager(appContext)
        locationHelper = LocationHelper(appContext)

        val api = RetrofitInstance.api
        val db = AppDatabase.getInstance(appContext)

        workshopRepository = WorkshopRepository(api)
        estimatorRepository = EstimatorRepository(api)
        emergencyRepository = EmergencyRepository(api, sessionManager)
        vehicleRepository = VehicleRepository(api, db.vehicleDao(), db.serviceHistoryDao(), sessionManager)
        paymentRepository = PaymentRepository(api, sessionManager)
    }
}
