package com.otoshield.app.util

import android.content.Context
import android.net.Uri
import okhttp3.MultipartBody
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.RequestBody.Companion.asRequestBody
import java.io.File

/**
 * Item "belum dikerjakan" #10: konversi Uri hasil Photo Picker jadi
 * MultipartBody.Part untuk field "photo" (lihat ApiService.uploadEmergencyPhoto
 * dan backend/src/middleware/upload.middleware.js - field WAJIB bernama "photo").
 *
 * Backend membatasi tipe file ke JPEG/PNG/WEBP dan ukuran maks 5MB (lihat
 * allowedMimeTypes & limits di upload.middleware.js) - validasi itu tetap
 * dilakukan di server, fungsi ini hanya menyalin byte apa adanya. Kalau
 * pengguna memilih format lain (mis. GIF), server akan menolak dengan 400
 * dan pesan yang jelas, bukan error 500 (lihat catatan wrapper multer di
 * emergency.routes.js).
 */
fun uriToPhotoPart(context: Context, uri: Uri, partName: String = "photo"): MultipartBody.Part? {
    val contentResolver = context.contentResolver
    val mimeType = contentResolver.getType(uri) ?: "image/jpeg"
    val extension = when (mimeType) {
        "image/png" -> "png"
        "image/webp" -> "webp"
        else -> "jpg"
    }

    // Salin ke file cache sementara dulu - MultipartBody.Part butuh RequestBody dengan
    // panjang konten yang diketahui di muka, dan streaming langsung dari InputStream
    // content:// tidak selalu menyediakan itu dengan aman di semua ROM/provider.
    val tempFile = File(context.cacheDir, "upload_${System.currentTimeMillis()}.$extension")
    contentResolver.openInputStream(uri)?.use { input ->
        tempFile.outputStream().use { output -> input.copyTo(output) }
    } ?: return null

    val requestBody = tempFile.asRequestBody(mimeType.toMediaTypeOrNull())
    return MultipartBody.Part.createFormData(partName, tempFile.name, requestBody)
}
