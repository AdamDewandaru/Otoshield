package com.otoshield.app.ui.screens.sos

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.otoshield.app.data.remote.dto.EmergencyRequestDto
import com.otoshield.app.data.repository.EmergencyRepository
import com.otoshield.app.util.LocationHelper
import com.otoshield.app.util.SocketManager
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import okhttp3.MultipartBody

data class SosUiState(
    val isSubmitting: Boolean = false,
    val isLoadingLocation: Boolean = false,
    val error: String? = null,
    val emergencyId: String? = null
)

data class SosTrackingUiState(
    val emergency: EmergencyRequestDto? = null,
    val isLoading: Boolean = true,
    val error: String? = null,
    val isUploadingPhoto: Boolean = false,
    val photoUploadError: String? = null
)

/**
 * ViewModel untuk alur SOS Darurat (Bagian 5 blueprint):
 * 1) ambil lokasi GPS -> 2) kirim deskripsi kerusakan -> 3) kirim ke server -> 4) dapat emergencyId untuk tracking.
 */
class SosViewModel(
    private val emergencyRepository: EmergencyRepository,
    private val locationHelper: LocationHelper
) : ViewModel() {

    var uiState by mutableStateOf(SosUiState())
        private set

    fun submitSos(issueDescription: String) {
        viewModelScope.launch {
            uiState = uiState.copy(isSubmitting = true, isLoadingLocation = true, error = null)

            val location = locationHelper.getCurrentLocation()
            if (location == null) {
                uiState = uiState.copy(
                    isSubmitting = false,
                    isLoadingLocation = false,
                    error = "Tidak dapat mengambil lokasi GPS. Pastikan GPS & izin lokasi aktif."
                )
                return@launch
            }
            uiState = uiState.copy(isLoadingLocation = false)

            val (lat, lng) = location
            val result = emergencyRepository.createSos(lat, lng, issueDescription)
            result.fold(
                onSuccess = { response ->
                    uiState = uiState.copy(isSubmitting = false, emergencyId = response.emergency.id)
                },
                onFailure = { e ->
                    uiState = uiState.copy(isSubmitting = false, error = e.message ?: "Gagal mengirim SOS.")
                }
            )
        }
    }
}

/**
 * ViewModel untuk memantau status permintaan SOS setelah dikirim.
 * Realtime lewat Socket.IO (event "emergency:updated" & "emergency:mechanic_location",
 * lihat backend/src/sockets/emergency.socket.js dan util/SocketManager.kt). Polling tiap
 * 15 detik tetap dijaga sebagai jaring pengaman jika koneksi socket sempat terputus.
 */
class SosTrackingViewModel(
    private val emergencyId: String,
    private val emergencyRepository: EmergencyRepository
) : ViewModel() {

    private val socketManager = SocketManager()

    var uiState by mutableStateOf(SosTrackingUiState())
        private set

    init {
        fetchOnce()
        connectRealtime()
        startFallbackPolling()
    }

    private fun fetchOnce() {
        viewModelScope.launch {
            val result = emergencyRepository.getStatus(emergencyId)
            result.fold(
                onSuccess = { emergency -> uiState = uiState.copy(emergency = emergency, isLoading = false, error = null) },
                onFailure = { e -> uiState = uiState.copy(isLoading = false, error = e.message) }
            )
        }
    }

    private fun connectRealtime() {
        socketManager.connectAndJoin(emergencyId)

        socketManager.onEmergencyUpdated { json ->
            val current = uiState.emergency ?: return@onEmergencyUpdated
            val updated = current.copy(
                status = json.optString("status", current.status),
                mechanic_latitude = if (json.has("mechanic_latitude") && !json.isNull("mechanic_latitude")) json.optDouble("mechanic_latitude") else current.mechanic_latitude,
                mechanic_longitude = if (json.has("mechanic_longitude") && !json.isNull("mechanic_longitude")) json.optDouble("mechanic_longitude") else current.mechanic_longitude,
                updated_at = json.optString("updated_at", current.updated_at)
            )
            uiState = uiState.copy(emergency = updated, isLoading = false, error = null)
        }

        socketManager.onMechanicLocationUpdated { lat, lng ->
            val current = uiState.emergency ?: return@onMechanicLocationUpdated
            uiState = uiState.copy(emergency = current.copy(mechanic_latitude = lat, mechanic_longitude = lng))
        }
    }

    /** Jaring pengaman: tetap sinkron via REST jika event socket terlewat/koneksi putus sementara. */
    private fun startFallbackPolling() {
        viewModelScope.launch {
            while (true) {
                delay(15000)
                val status = uiState.emergency?.status
                if (status == "COMPLETED" || status == "CANCELLED") return@launch
                emergencyRepository.getStatus(emergencyId).onSuccess { emergency ->
                    uiState = uiState.copy(emergency = emergency, isLoading = false, error = null)
                }
            }
        }
    }

    /** Item "belum dikerjakan" #10. Dipanggil dari SosTrackingScreen setelah pengguna memilih
     * foto lewat Photo Picker dan `uriToPhotoPart()` berhasil menyiapkan MultipartBody.Part. */
    fun uploadPhoto(photoPart: MultipartBody.Part) {
        viewModelScope.launch {
            uiState = uiState.copy(isUploadingPhoto = true, photoUploadError = null)
            emergencyRepository.uploadPhoto(emergencyId, photoPart).fold(
                onSuccess = { emergency ->
                    uiState = uiState.copy(isUploadingPhoto = false, emergency = emergency)
                },
                onFailure = { e ->
                    uiState = uiState.copy(isUploadingPhoto = false, photoUploadError = e.message ?: "Gagal mengunggah foto.")
                }
            )
        }
    }

    override fun onCleared() {
        super.onCleared()
        socketManager.disconnect()
    }
}
