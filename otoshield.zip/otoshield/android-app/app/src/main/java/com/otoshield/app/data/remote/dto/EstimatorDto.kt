package com.otoshield.app.data.remote.dto

data class EstimateRequest(val symptom_text: String)

data class EstimateAlternativeDto(val issue_category: String, val estimated_min: Int, val estimated_max: Int)

data class EstimateResponse(
    val matched: Boolean,
    val message: String? = null,
    val issue_category: String? = null,
    val estimated_min: Int? = null,
    val estimated_max: Int? = null,
    val alternatives: List<EstimateAlternativeDto> = emptyList()
)
