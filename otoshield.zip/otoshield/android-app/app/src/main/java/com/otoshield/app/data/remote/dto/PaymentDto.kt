package com.otoshield.app.data.remote.dto

/**
 * DTO untuk fitur pembayaran digital (Bagian 5 blueprint, User Flow SOS langkah 6).
 *
 * Sinkron dengan backend Sesi 4 (lihat backend/src/controllers/payments.controller.js):
 * - Endpoint lama `PUT /:id/pay` (simulasi bebas panggil siapa saja) SUDAH DIHAPUS di backend.
 * - `POST /api/payments` sekarang mengembalikan `gateway_redirect_url` + `gateway_mode`
 *   (field baru, lihat CreatePaymentResponse) alih-alih langsung berstatus PAID.
 * - Status PAID untuk method VIRTUAL_ACCOUNT/E_WALLET HANYA berubah lewat webhook gateway
 *   di sisi server (Midtrans-style) - app TIDAK bisa langsung set status jadi PAID untuk
 *   method tersebut. App hanya bisa refresh (GET) untuk melihat status terbaru.
 * - Method CASH tetap punya jalur konfirmasi manual dari app: `PUT /:id/confirm-cash`.
 */

data class CreatePaymentRequest(
    val emergency_request_id: String? = null,
    val workshop_id: String? = null,
    val amount: Int,
    val method: String // "VIRTUAL_ACCOUNT" | "E_WALLET" | "CASH"
)

data class PaymentDto(
    val id: String,
    val user_id: String,
    val emergency_request_id: String?,
    val workshop_id: String?,
    val amount: Int,
    val method: String,
    val status: String, // PENDING, PAID, FAILED, CANCELLED
    val payment_reference: String?,
    val created_at: String,
    val paid_at: String?
)

/**
 * Response `POST /api/payments`: sama seperti PaymentDto + dua field tambahan dari gateway
 * yang HANYA muncul saat pembuatan tagihan (tidak disimpan ulang di GET/list biasa).
 * `gateway_mode` bernilai "sandbox" selama backend belum diisi kredensial Midtrans sungguhan
 * (lihat CATATAN JUJUR di paymentGateway.js) - app bisa memakainya untuk menampilkan label
 * "Mode uji coba" ke pengguna supaya tidak salah kira ini gateway produksi.
 */
data class CreatePaymentResponse(
    val id: String,
    val user_id: String,
    val emergency_request_id: String?,
    val workshop_id: String?,
    val amount: Int,
    val method: String,
    val status: String,
    val payment_reference: String?,
    val created_at: String,
    val paid_at: String?,
    val gateway_redirect_url: String?,
    val gateway_mode: String?
)
