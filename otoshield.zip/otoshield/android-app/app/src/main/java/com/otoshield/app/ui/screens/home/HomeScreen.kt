package com.otoshield.app.ui.screens.home

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.otoshield.app.ui.theme.OtoBlue
import com.otoshield.app.ui.theme.OtoGreen
import com.otoshield.app.ui.theme.OtoRed

/**
 * Halaman utama OtoShield: tombol SOS besar + akses cepat ke 3 fitur inti lainnya
 * sesuai Bagian 2 & 5 blueprint.
 */
@Composable
fun HomeScreen(
    onSosClick: () -> Unit,
    onWorkshopsClick: () -> Unit,
    onEstimatorClick: () -> Unit,
    onServiceBookClick: () -> Unit,
    onProfileClick: () -> Unit = {},
    onLogout: () -> Unit = {}
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("OtoShield") },
                actions = {
                    IconButton(onClick = onProfileClick) {
                        Icon(Icons.Default.Person, contentDescription = "Profil Saya")
                    }
                    IconButton(onClick = onLogout) {
                        Icon(Icons.Default.Logout, contentDescription = "Keluar")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                "Ada masalah di jalan?",
                style = MaterialTheme.typography.headlineMedium
            )
            Spacer(Modifier.height(8.dp))
            Text(
                "Tekan tombol di bawah untuk bantuan darurat 24/7",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(Modifier.height(32.dp))

            // Tombol panik SOS
            Box(
                modifier = Modifier
                    .size(180.dp)
                    .clip(CircleShape)
                    .background(OtoRed)
                    .clickable(onClick = onSosClick),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.Warning, contentDescription = null, tint = Color.White, modifier = Modifier.size(48.dp))
                    Spacer(Modifier.height(4.dp))
                    Text("SOS DARURAT", color = Color.White, style = MaterialTheme.typography.titleMedium)
                }
            }

            Spacer(Modifier.height(40.dp))

            FeatureRow(
                icon = Icons.Default.Build,
                label = "Direktori Bengkel Terverifikasi",
                accent = OtoBlue,
                onClick = onWorkshopsClick
            )
            Spacer(Modifier.height(12.dp))
            FeatureRow(
                icon = Icons.Default.Calculate,
                label = "Estimator Biaya Cerdas",
                accent = OtoGreen,
                onClick = onEstimatorClick
            )
            Spacer(Modifier.height(12.dp))
            FeatureRow(
                icon = Icons.Default.MenuBook,
                label = "Buku Servis Digital",
                accent = OtoBlue,
                onClick = onServiceBookClick
            )
        }
    }
}

@Composable
private fun FeatureRow(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    accent: Color,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(16.dp)
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(icon, contentDescription = null, tint = accent)
            Spacer(Modifier.width(16.dp))
            Text(label, style = MaterialTheme.typography.bodyLarge)
            Spacer(Modifier.weight(1f))
            Icon(Icons.Default.ChevronRight, contentDescription = null)
        }
    }
}
