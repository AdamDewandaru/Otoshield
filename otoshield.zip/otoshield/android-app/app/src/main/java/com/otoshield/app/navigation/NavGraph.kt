package com.otoshield.app.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.otoshield.app.di.ServiceLocator
import com.otoshield.app.ui.screens.auth.LoginScreen
import com.otoshield.app.ui.screens.auth.RegisterScreen
import com.otoshield.app.ui.screens.estimator.CostEstimatorScreen
import com.otoshield.app.ui.screens.home.HomeScreen
import com.otoshield.app.ui.screens.payment.PaymentScreen
import com.otoshield.app.ui.screens.profile.ProfileScreen
import com.otoshield.app.ui.screens.servicebook.ServiceBookScreen
import com.otoshield.app.ui.screens.sos.SosScreen
import com.otoshield.app.ui.screens.sos.SosTrackingScreen
import com.otoshield.app.ui.screens.workshop.WorkshopDetailScreen
import com.otoshield.app.ui.screens.workshop.WorkshopListScreen

@Composable
fun OtoShieldNavGraph(navController: NavHostController = rememberNavController()) {
    // Jika sudah pernah login (token tersimpan di SessionManager), langsung ke Home.
    val startDestination = if (ServiceLocator.sessionManager.isLoggedIn()) Screen.Home.route else Screen.Login.route

    NavHost(navController = navController, startDestination = startDestination) {

        composable(Screen.Login.route) {
            LoginScreen(
                onLoggedIn = {
                    navController.navigate(Screen.Home.route) {
                        popUpTo(Screen.Login.route) { inclusive = true }
                    }
                },
                onGoToRegister = { navController.navigate(Screen.Register.route) }
            )
        }

        composable(Screen.Register.route) {
            RegisterScreen(
                onRegistered = {
                    navController.navigate(Screen.Home.route) {
                        popUpTo(Screen.Login.route) { inclusive = true }
                    }
                },
                onGoToLogin = { navController.popBackStack() }
            )
        }

        composable(Screen.Home.route) {
            HomeScreen(
                onSosClick = { navController.navigate(Screen.Sos.route) },
                onWorkshopsClick = { navController.navigate(Screen.WorkshopList.route) },
                onEstimatorClick = { navController.navigate(Screen.Estimator.route) },
                onServiceBookClick = { navController.navigate(Screen.ServiceBook.route) },
                onProfileClick = { navController.navigate(Screen.Profile.route) },
                onLogout = {
                    ServiceLocator.sessionManager.clear()
                    navController.navigate(Screen.Login.route) {
                        popUpTo(0) { inclusive = true }
                    }
                }
            )
        }

        composable(Screen.Profile.route) {
            ProfileScreen(onBack = { navController.popBackStack() })
        }

        composable(Screen.Sos.route) {
            SosScreen(
                onSosSent = { emergencyId ->
                    navController.navigate(Screen.SosTracking.createRoute(emergencyId))
                },
                onBack = { navController.popBackStack() }
            )
        }

        composable(Screen.SosTracking.route) { backStackEntry ->
            val emergencyId = backStackEntry.arguments?.getString("emergencyId") ?: return@composable
            SosTrackingScreen(
                emergencyId = emergencyId,
                onBack = { navController.popBackStack() },
                onPayClick = { amount ->
                    navController.navigate(Screen.Payment.createRoute(emergencyId, amount))
                }
            )
        }

        composable(
            route = Screen.Payment.route,
            arguments = listOf(
                navArgument("amount") { type = NavType.IntType; defaultValue = 0 }
            )
        ) { backStackEntry ->
            val emergencyId = backStackEntry.arguments?.getString("emergencyId")
            val amount = backStackEntry.arguments?.getInt("amount") ?: 0
            PaymentScreen(
                emergencyRequestId = emergencyId,
                amountDefault = amount,
                onBack = { navController.popBackStack() }
            )
        }

        composable(Screen.WorkshopList.route) {
            WorkshopListScreen(
                onWorkshopClick = { id -> navController.navigate(Screen.WorkshopDetail.createRoute(id)) },
                onBack = { navController.popBackStack() }
            )
        }

        composable(Screen.WorkshopDetail.route) { backStackEntry ->
            val workshopId = backStackEntry.arguments?.getString("workshopId") ?: return@composable
            WorkshopDetailScreen(workshopId = workshopId, onBack = { navController.popBackStack() })
        }

        composable(Screen.Estimator.route) {
            CostEstimatorScreen(onBack = { navController.popBackStack() })
        }

        composable(Screen.ServiceBook.route) {
            ServiceBookScreen(onBack = { navController.popBackStack() })
        }
    }
}
