package com.otoshield.app.ui.screens.sos

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewmodel.compose.viewModel
import coil.compose.AsyncImage
import com.google.android.gms.maps.model.CameraPosition
import com.google.android.gms.maps.model.LatLng
import com.google.maps.android.compose.*
import com.otoshield.app.data.remote.RetrofitInstance
import com.otoshield.app.di.ServiceLocator
import com.otoshield.app.util.uriToPhotoPart

/** Label status dalam Bahasa Indonesia agar mudah dipahami pengguna saat panik. */
private fun statusLabel(status: String) = when (status) {
    "PENDING" -> "Mencari mekanik terdekat..."
    "ACCEPTED" -> "Mekanik telah menerima permintaan Anda"
    "ON_THE_WAY" -> "Mekanik sedang dalam perjalanan"
    "COMPLETED" -> "Perbaikan selesai"
    "CANCELLED" -> "Permintaan dibatalkan"
    else -> status
}

@Composable
fun SosTrackingScreen(
    emergencyId: String,
    onBack: () -> Unit,
    onPayClick: (amount: Int) -> Unit = {}
) {
    val viewModel: SosTrackingViewModel = viewModel(factory = object : ViewModelProvider.Factory {
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            @Suppress("UNCHECKED_CAST")
            return SosTrackingViewModel(emergencyId, ServiceLocator.emergencyRepository) as T
        }
    })

    val state = viewModel.uiState
    val context = LocalContext.current

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            val part = uriToPhotoPart(context, uri)
            if (part != null) {
                viewModel.uploadPhoto(part)
            }
        }
    }

    Scaffold(topBar = { TopAppBar(title = { Text("Melacak Bantuan") }) }) { padding ->
        Column(modifier = Modifier.padding(padding).fillMaxSize()) {
            if (state.isLoading && state.emergency == null) {
                Box(Modifier.fillMaxSize(), contentAlignment = androidx.compose.ui.Alignment.Center) {
                    CircularProgressIndicator()
                }
            } else {
                state.emergency?.let { emergency ->
                    val userLatLng = LatLng(emergency.latitude, emergency.longitude)
                    val cameraState = rememberCameraPositionState {
                        position = CameraPosition.fromLatLngZoom(userLatLng, 14f)
                    }

                    GoogleMap(
                        modifier = Modifier.fillMaxWidth().weight(1f),
                        cameraPositionState = cameraState
                    ) {
                        Marker(state = MarkerState(position = userLatLng), title = "Lokasi Anda")
                        if (emergency.mechanic_latitude != null && emergency.mechanic_longitude != null) {
                            Marker(
                                state = MarkerState(
                                    position = LatLng(emergency.mechanic_latitude, emergency.mechanic_longitude)
                                ),
                                title = "Mekanik"
                            )
                        }
                    }

                    Column(Modifier.padding(20.dp)) {
                        Text(statusLabel(emergency.status), style = MaterialTheme.typography.titleMedium)
                        Spacer(Modifier.height(4.dp))
                        emergency.issue_description?.let {
                            Text("Keluhan: $it", style = MaterialTheme.typography.bodyMedium)
                        }
                        if (emergency.estimated_cost_min != null && emergency.estimated_cost_max != null) {
                            Spacer(Modifier.height(4.dp))
                            Text(
                                "Estimasi biaya awal: Rp${emergency.estimated_cost_min} - Rp${emergency.estimated_cost_max}",
                                style = MaterialTheme.typography.bodyMedium
                            )
                        }

                        // Item "belum dikerjakan" #10: foto kerusakan kendaraan.
                        Spacer(Modifier.height(12.dp))
                        val resolvedPhotoUrl = RetrofitInstance.resolveMediaUrl(emergency.photo_url)
                        if (resolvedPhotoUrl != null) {
                            AsyncImage(
                                model = resolvedPhotoUrl,
                                contentDescription = "Foto kerusakan kendaraan",
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxWidth().height(180.dp)
                            )
                            Spacer(Modifier.height(8.dp))
                        }
                        OutlinedButton(
                            onClick = {
                                photoPickerLauncher.launch(
                                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                )
                            },
                            enabled = !state.isUploadingPhoto,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            if (state.isUploadingPhoto) {
                                CircularProgressIndicator(modifier = Modifier.size(20.dp))
                            } else {
                                Text(if (resolvedPhotoUrl != null) "Ganti Foto Kerusakan" else "Tambahkan Foto Kerusakan")
                            }
                        }
                        state.photoUploadError?.let {
                            Spacer(Modifier.height(4.dp))
                            Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                        }

                        if (emergency.status == "COMPLETED") {
                            Spacer(Modifier.height(12.dp))
                            Button(
                                onClick = { onPayClick(emergency.estimated_cost_max ?: 0) },
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text("Bayar Sekarang")
                            }
                        }
                        Spacer(Modifier.height(12.dp))
                        TextButton(onClick = onBack) { Text("Kembali ke Beranda") }
                    }
                }
            }

            state.error?.let {
                Text(it, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(16.dp))
            }
        }
    }
}
