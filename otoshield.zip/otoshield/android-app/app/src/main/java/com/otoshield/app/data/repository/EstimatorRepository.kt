package com.otoshield.app.data.repository

import com.otoshield.app.data.remote.ApiService
import com.otoshield.app.data.remote.dto.EstimateRequest
import com.otoshield.app.data.remote.dto.EstimateResponse

class EstimatorRepository(private val api: ApiService) {
    suspend fun estimate(symptomText: String): Result<EstimateResponse> = try {
        val response = api.estimateCost(EstimateRequest(symptomText))
        if (response.isSuccessful && response.body() != null) {
            Result.success(response.body()!!)
        } else {
            Result.failure(Exception("Gagal menghitung estimasi (${response.code()})"))
        }
    } catch (e: Exception) {
        Result.failure(e)
    }
}
