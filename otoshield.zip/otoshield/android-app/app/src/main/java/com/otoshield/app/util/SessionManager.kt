package com.otoshield.app.util

import android.content.Context
import android.content.SharedPreferences

/**
 * Penyimpanan sederhana untuk token JWT & data user yang sedang login,
 * menggunakan SharedPreferences (cukup untuk skala MVP).
 */
class SessionManager(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("otoshield_session", Context.MODE_PRIVATE)

    fun saveToken(token: String) = prefs.edit().putString(KEY_TOKEN, token).apply()

    fun getToken(): String? = prefs.getString(KEY_TOKEN, null)

    /** Token dalam format siap pakai untuk header Authorization: "Bearer xxx" */
    fun getBearerToken(): String = "Bearer ${getToken().orEmpty()}"

    fun saveUser(id: String, name: String) {
        prefs.edit().putString(KEY_USER_ID, id).putString(KEY_USER_NAME, name).apply()
    }

    fun getUserName(): String? = prefs.getString(KEY_USER_NAME, null)

    fun isLoggedIn(): Boolean = getToken() != null

    fun clear() = prefs.edit().clear().apply()

    companion object {
        private const val KEY_TOKEN = "token"
        private const val KEY_USER_ID = "user_id"
        private const val KEY_USER_NAME = "user_name"
    }
}
