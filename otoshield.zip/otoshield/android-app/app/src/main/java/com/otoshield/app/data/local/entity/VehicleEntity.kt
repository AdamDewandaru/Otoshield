package com.otoshield.app.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Cache lokal data kendaraan agar Digital Service Book tetap bisa
 * dibuka meski koneksi internet sedang tidak tersedia.
 */
@Entity(tableName = "vehicles")
data class VehicleEntity(
    @PrimaryKey val id: String,
    val brand: String,
    val model: String,
    val year: Int?,
    val licensePlate: String?,
    val currentKilometer: Int,
    val lastServiceKm: Int,
    val lastServiceDate: String?
)
