package com.otoshield.app.ui.screens.payment

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.otoshield.app.data.remote.dto.PaymentDto
import com.otoshield.app.data.repository.PaymentRepository
import kotlinx.coroutines.launch

data class PaymentUiState(
    val isCreating: Boolean = false,
    val isRefreshing: Boolean = false,
    val isConfirmingCash: Boolean = false,
    val payment: PaymentDto? = null,
    val gatewayRedirectUrl: String? = null,
    val gatewayMode: String? = null,
    val error: String? = null
)

/**
 * Fitur pembayaran digital (item "belum dikerjakan" #9 di otoshield_blueprint.md).
 *
 * PENTING: untuk method VIRTUAL_ACCOUNT/E_WALLET, ViewModel ini TIDAK PERNAH mengubah status
 * jadi PAID sendiri - status hanya berubah lewat webhook gateway di server. `refreshStatus()`
 * hanya membaca ulang status terbaru (dipanggil mis. saat pengguna kembali ke app setelah
 * membuka gatewayRedirectUrl di browser/WebView). Untuk CASH, `confirmCash()` memang boleh
 * mengubah status langsung karena tidak lewat gateway sama sekali.
 */
class PaymentViewModel(private val repository: PaymentRepository) : ViewModel() {

    var uiState by mutableStateOf(PaymentUiState())
        private set

    fun createPayment(emergencyRequestId: String?, workshopId: String?, amount: Int, method: String) {
        viewModelScope.launch {
            uiState = uiState.copy(isCreating = true, error = null)
            repository.createPayment(emergencyRequestId, workshopId, amount, method)
                .onSuccess { response ->
                    uiState = uiState.copy(
                        isCreating = false,
                        payment = PaymentDto(
                            id = response.id,
                            user_id = response.user_id,
                            emergency_request_id = response.emergency_request_id,
                            workshop_id = response.workshop_id,
                            amount = response.amount,
                            method = response.method,
                            status = response.status,
                            payment_reference = response.payment_reference,
                            created_at = response.created_at,
                            paid_at = response.paid_at
                        ),
                        gatewayRedirectUrl = response.gateway_redirect_url,
                        gatewayMode = response.gateway_mode
                    )
                }
                .onFailure { e ->
                    uiState = uiState.copy(isCreating = false, error = e.message ?: "Terjadi kesalahan jaringan.")
                }
        }
    }

    fun refreshStatus() {
        val paymentId = uiState.payment?.id ?: return
        viewModelScope.launch {
            uiState = uiState.copy(isRefreshing = true, error = null)
            repository.getPayment(paymentId)
                .onSuccess { payment -> uiState = uiState.copy(isRefreshing = false, payment = payment) }
                .onFailure { e -> uiState = uiState.copy(isRefreshing = false, error = e.message ?: "Terjadi kesalahan jaringan.") }
        }
    }

    fun confirmCash() {
        val paymentId = uiState.payment?.id ?: return
        viewModelScope.launch {
            uiState = uiState.copy(isConfirmingCash = true, error = null)
            repository.confirmCashPayment(paymentId)
                .onSuccess { payment -> uiState = uiState.copy(isConfirmingCash = false, payment = payment) }
                .onFailure { e -> uiState = uiState.copy(isConfirmingCash = false, error = e.message ?: "Terjadi kesalahan jaringan.") }
        }
    }
}
