package com.otoshield.app.ui.screens.workshop

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewmodel.compose.viewModel
import com.otoshield.app.di.ServiceLocator

/**
 * Menampilkan transparansi harga jasa (labor fee) & kisaran suku cadang
 * sebelum kendaraan diservis, sesuai Fitur 2 blueprint.
 */
@Composable
fun WorkshopDetailScreen(workshopId: String, onBack: () -> Unit) {
    val viewModel: WorkshopDetailViewModel = viewModel(factory = object : ViewModelProvider.Factory {
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            @Suppress("UNCHECKED_CAST")
            return WorkshopDetailViewModel(workshopId, ServiceLocator.workshopRepository) as T
        }
    })
    val state = viewModel.uiState

    Scaffold(topBar = { TopAppBar(title = { Text("Detail Bengkel") }) }) { padding ->
        when {
            state.isLoading -> Box(Modifier.padding(padding).fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }
            state.error != null -> Box(Modifier.padding(padding).fillMaxSize(), contentAlignment = Alignment.Center) {
                Text(state.error, color = MaterialTheme.colorScheme.error)
            }
            state.detail != null -> {
                val detail = state.detail
                LazyColumn(modifier = Modifier.padding(padding).fillMaxSize().padding(16.dp)) {
                    item {
                        Text(detail.name, style = MaterialTheme.typography.headlineMedium)
                        detail.address?.let { Text(it, style = MaterialTheme.typography.bodyMedium) }
                        Spacer(Modifier.height(4.dp))
                        Text("Rating: ${"%.1f".format(detail.rating)} (${detail.rating_count} ulasan)")
                        Spacer(Modifier.height(16.dp))
                        Text("Daftar Harga Jasa", style = MaterialTheme.typography.titleMedium)
                        Spacer(Modifier.height(8.dp))
                    }
                    items(detail.services) { service ->
                        Card(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                            Column(Modifier.padding(12.dp)) {
                                Text(service.service_name, style = MaterialTheme.typography.titleMedium)
                                Text("Jasa: Rp${service.labor_fee_min} - Rp${service.labor_fee_max}")
                                if (service.part_price_min != null) {
                                    Text("Sparepart: Rp${service.part_price_min} - Rp${service.part_price_max}")
                                }
                            }
                        }
                    }
                    item {
                        Spacer(Modifier.height(16.dp))
                        Text("Ulasan Pengguna", style = MaterialTheme.typography.titleMedium)
                        Spacer(Modifier.height(8.dp))
                    }
                    items(detail.reviews) { review ->
                        Column(Modifier.padding(vertical = 6.dp)) {
                            Text("${review.user_name} · ${review.rating}/5", style = MaterialTheme.typography.bodyLarge)
                            review.comment?.let { Text(it, style = MaterialTheme.typography.bodyMedium) }
                        }
                    }
                }
            }
        }
    }
}
