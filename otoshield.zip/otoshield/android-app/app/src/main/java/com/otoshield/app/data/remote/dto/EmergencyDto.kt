package com.otoshield.app.data.remote.dto

data class CreateEmergencyRequest(
    val latitude: Double,
    val longitude: Double,
    val issue_description: String?
)

data class EmergencyRequestDto(
    val id: String,
    val user_id: String,
    val workshop_id: String?,
    val status: String, // PENDING, ACCEPTED, ON_THE_WAY, COMPLETED, CANCELLED
    val issue_description: String?,
    val latitude: Double,
    val longitude: Double,
    val mechanic_latitude: Double?,
    val mechanic_longitude: Double?,
    val estimated_cost_min: Int?,
    val estimated_cost_max: Int?,
    val photo_url: String?,
    val created_at: String,
    val updated_at: String
)

data class CreateEmergencyResponse(
    val emergency: EmergencyRequestDto,
    val nearby_workshops: List<WorkshopDto>
)
