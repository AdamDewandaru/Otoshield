package com.otoshield.app.ui.screens.workshop

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.otoshield.app.data.remote.dto.WorkshopDetailDto
import com.otoshield.app.data.remote.dto.WorkshopDto
import com.otoshield.app.data.repository.WorkshopRepository
import com.otoshield.app.util.LocationHelper
import kotlinx.coroutines.launch

data class WorkshopListUiState(
    val workshops: List<WorkshopDto> = emptyList(),
    val isLoading: Boolean = true,
    val error: String? = null,
    val verifiedOnly: Boolean = false
)

class WorkshopListViewModel(
    private val repository: WorkshopRepository,
    private val locationHelper: LocationHelper
) : ViewModel() {

    var uiState by mutableStateOf(WorkshopListUiState())
        private set

    init { load() }

    fun toggleVerifiedOnly() {
        uiState = uiState.copy(verifiedOnly = !uiState.verifiedOnly)
        load()
    }

    fun load() {
        viewModelScope.launch {
            uiState = uiState.copy(isLoading = true, error = null)
            val location = locationHelper.getCurrentLocation()
            val result = repository.getNearbyWorkshops(
                lat = location?.first,
                lng = location?.second,
                radiusKm = 15.0,
                verifiedOnly = uiState.verifiedOnly
            )
            result.fold(
                onSuccess = { list -> uiState = uiState.copy(workshops = list, isLoading = false) },
                onFailure = { e -> uiState = uiState.copy(isLoading = false, error = e.message) }
            )
        }
    }
}

data class WorkshopDetailUiState(
    val detail: WorkshopDetailDto? = null,
    val isLoading: Boolean = true,
    val error: String? = null
)

class WorkshopDetailViewModel(
    private val workshopId: String,
    private val repository: WorkshopRepository
) : ViewModel() {

    var uiState by mutableStateOf(WorkshopDetailUiState())
        private set

    init {
        viewModelScope.launch {
            val result = repository.getWorkshopDetail(workshopId)
            result.fold(
                onSuccess = { detail -> uiState = uiState.copy(detail = detail, isLoading = false) },
                onFailure = { e -> uiState = uiState.copy(isLoading = false, error = e.message) }
            )
        }
    }
}
