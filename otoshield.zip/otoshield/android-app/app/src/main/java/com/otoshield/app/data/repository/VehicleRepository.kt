package com.otoshield.app.data.repository

import com.otoshield.app.data.local.dao.ServiceHistoryDao
import com.otoshield.app.data.local.dao.VehicleDao
import com.otoshield.app.data.local.entity.ServiceHistoryEntity
import com.otoshield.app.data.local.entity.VehicleEntity
import com.otoshield.app.data.remote.ApiService
import com.otoshield.app.data.remote.dto.AddServiceHistoryRequest
import com.otoshield.app.data.remote.dto.AddVehicleRequest
import com.otoshield.app.data.remote.dto.ReminderResponse
import com.otoshield.app.data.remote.dto.UpdateVehicleRequest
import com.otoshield.app.data.remote.dto.VehicleDto
import com.otoshield.app.util.SessionManager
import kotlinx.coroutines.flow.Flow

/**
 * Repository untuk fitur Digital Service Book.
 * Strategi: ambil data dari API, simpan ke Room sebagai cache,
 * UI membaca dari Room (Flow) supaya tetap bisa dibuka secara offline.
 */
class VehicleRepository(
    private val api: ApiService,
    private val vehicleDao: VehicleDao,
    private val historyDao: ServiceHistoryDao,
    private val session: SessionManager
) {
    fun observeVehicles(): Flow<List<VehicleEntity>> = vehicleDao.observeAll()

    fun observeHistory(vehicleId: String): Flow<List<ServiceHistoryEntity>> =
        historyDao.observeForVehicle(vehicleId)

    suspend fun refreshVehicles(): Result<Unit> = try {
        val response = api.getVehicles(session.getBearerToken())
        if (response.isSuccessful && response.body() != null) {
            vehicleDao.upsertAll(response.body()!!.map { it.toEntity() })
            Result.success(Unit)
        } else {
            Result.failure(Exception("Gagal memuat kendaraan (${response.code()})"))
        }
    } catch (e: Exception) {
        Result.failure(e)
    }

    suspend fun addVehicle(req: AddVehicleRequest): Result<VehicleDto> = try {
        val response = api.addVehicle(session.getBearerToken(), req)
        if (response.isSuccessful && response.body() != null) {
            vehicleDao.upsert(response.body()!!.toEntity())
            Result.success(response.body()!!)
        } else {
            Result.failure(Exception("Gagal menambah kendaraan (${response.code()})"))
        }
    } catch (e: Exception) {
        Result.failure(e)
    }

    // Edit & hapus kendaraan (item "belum dikerjakan" #8 - Sesi 3)
    suspend fun updateVehicle(vehicleId: String, req: UpdateVehicleRequest): Result<VehicleDto> = try {
        val response = api.updateVehicle(session.getBearerToken(), vehicleId, req)
        if (response.isSuccessful && response.body() != null) {
            vehicleDao.upsert(response.body()!!.toEntity())
            Result.success(response.body()!!)
        } else {
            Result.failure(Exception("Gagal memperbarui kendaraan (${response.code()})"))
        }
    } catch (e: Exception) {
        Result.failure(e)
    }

    suspend fun deleteVehicle(vehicleId: String): Result<Unit> = try {
        val response = api.deleteVehicle(session.getBearerToken(), vehicleId)
        if (response.isSuccessful) {
            vehicleDao.deleteById(vehicleId)
            Result.success(Unit)
        } else {
            Result.failure(Exception("Gagal menghapus kendaraan (${response.code()})"))
        }
    } catch (e: Exception) {
        Result.failure(e)
    }

    suspend fun getReminders(vehicleId: String): Result<ReminderResponse> = try {
        val response = api.getReminders(session.getBearerToken(), vehicleId)
        if (response.isSuccessful && response.body() != null) {
            Result.success(response.body()!!)
        } else {
            Result.failure(Exception("Gagal memuat pengingat servis (${response.code()})"))
        }
    } catch (e: Exception) {
        Result.failure(e)
    }

    suspend fun addServiceHistory(vehicleId: String, req: AddServiceHistoryRequest): Result<Unit> = try {
        val response = api.addServiceHistory(session.getBearerToken(), vehicleId, req)
        if (response.isSuccessful) {
            refreshHistory(vehicleId)
            Result.success(Unit)
        } else {
            Result.failure(Exception("Gagal mencatat servis (${response.code()})"))
        }
    } catch (e: Exception) {
        Result.failure(e)
    }

    private suspend fun refreshHistory(vehicleId: String) {
        val response = api.getServiceHistory(session.getBearerToken(), vehicleId)
        if (response.isSuccessful && response.body() != null) {
            historyDao.upsertAll(response.body()!!.map {
                ServiceHistoryEntity(
                    id = it.id,
                    vehicleId = it.vehicle_id,
                    workshopId = it.workshop_id,
                    serviceType = it.service_type,
                    odometer = it.odometer,
                    cost = it.cost,
                    notes = it.notes,
                    serviceDate = it.service_date
                )
            })
        }
    }

    private fun VehicleDto.toEntity() = VehicleEntity(
        id = id,
        brand = brand,
        model = model,
        year = year,
        licensePlate = license_plate,
        currentKilometer = current_kilometer,
        lastServiceKm = last_service_km,
        lastServiceDate = last_service_date
    )
}
