package com.otoshield.app.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "service_history")
data class ServiceHistoryEntity(
    @PrimaryKey val id: String,
    val vehicleId: String,
    val workshopId: String?,
    val serviceType: String,
    val odometer: Int,
    val cost: Int?,
    val notes: String?,
    val serviceDate: String
)
