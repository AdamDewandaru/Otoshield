package com.otoshield.app.ui.theme

import androidx.compose.ui.graphics.Color

// Warna utama OtoShield: merah untuk kesan darurat/SOS & terpercaya (trust + urgency)
val OtoRed = Color(0xFFE53935)
val OtoRedDark = Color(0xFFB71C1C)
val OtoBlue = Color(0xFF1E3A8A)      // aksen "verified/terpercaya"
val OtoGreen = Color(0xFF2E7D32)     // status sukses / harga wajar
val OtoAmber = Color(0xFFF9A825)     // status peringatan / pending
val OtoBackground = Color(0xFFF7F7F9)
val OtoSurface = Color(0xFFFFFFFF)
val OtoTextPrimary = Color(0xFF1B1B1F)
val OtoTextSecondary = Color(0xFF6E6E76)
