package com.otoshield.app.navigation

sealed class Screen(val route: String) {
    data object Login : Screen("login")
    data object Register : Screen("register")
    data object Home : Screen("home")
    data object Sos : Screen("sos")
    data object SosTracking : Screen("sos_tracking/{emergencyId}") {
        fun createRoute(emergencyId: String) = "sos_tracking/$emergencyId"
    }
    data object WorkshopList : Screen("workshops")
    data object WorkshopDetail : Screen("workshops/{workshopId}") {
        fun createRoute(workshopId: String) = "workshops/$workshopId"
    }
    data object Estimator : Screen("estimator")
    data object ServiceBook : Screen("service_book")
    data object Profile : Screen("profile")
    data object Payment : Screen("payment/{emergencyId}?amount={amount}") {
        fun createRoute(emergencyId: String, amount: Int) = "payment/$emergencyId?amount=$amount"
    }
}
