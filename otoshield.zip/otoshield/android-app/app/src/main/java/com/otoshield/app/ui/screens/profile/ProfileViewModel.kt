package com.otoshield.app.ui.screens.profile

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.otoshield.app.data.remote.ApiService
import com.otoshield.app.data.remote.dto.UpdateProfileRequest
import com.otoshield.app.data.remote.dto.UserDto
import com.otoshield.app.util.SessionManager
import kotlinx.coroutines.launch

data class ProfileUiState(
    val isLoading: Boolean = true,
    val isSaving: Boolean = false,
    val user: UserDto? = null,
    val error: String? = null,
    val saveSuccess: Boolean = false
)

/**
 * Fitur profil pengguna (Bagian "belum dikerjakan" #8 di otoshield_blueprint.md,
 * Sesi 3): lihat & edit nama/email/telepon lewat GET/PUT /api/auth/me.
 */
class ProfileViewModel(
    private val api: ApiService,
    private val session: SessionManager
) : ViewModel() {

    var uiState by mutableStateOf(ProfileUiState())
        private set

    init {
        loadProfile()
    }

    fun loadProfile() {
        viewModelScope.launch {
            uiState = uiState.copy(isLoading = true, error = null)
            try {
                val response = api.getProfile(session.getBearerToken())
                if (response.isSuccessful && response.body() != null) {
                    uiState = uiState.copy(isLoading = false, user = response.body())
                } else {
                    uiState = uiState.copy(isLoading = false, error = "Gagal memuat profil (${response.code()}).")
                }
            } catch (e: Exception) {
                uiState = uiState.copy(isLoading = false, error = e.message ?: "Terjadi kesalahan jaringan.")
            }
        }
    }

    fun updateProfile(name: String, email: String?, phone: String) {
        if (name.isBlank() || phone.isBlank()) {
            uiState = uiState.copy(error = "Nama dan nomor telepon wajib diisi.")
            return
        }
        viewModelScope.launch {
            uiState = uiState.copy(isSaving = true, error = null, saveSuccess = false)
            try {
                val response = api.updateProfile(
                    session.getBearerToken(),
                    UpdateProfileRequest(name = name, email = email?.ifBlank { null }, phone = phone)
                )
                if (response.isSuccessful && response.body() != null) {
                    val updated = response.body()!!
                    session.saveUser(updated.id, updated.name) // sinkronkan cache nama di SessionManager
                    uiState = uiState.copy(isSaving = false, user = updated, saveSuccess = true)
                } else {
                    val msg = if (response.code() == 409) "Nomor telepon sudah dipakai pengguna lain."
                              else "Gagal menyimpan profil (${response.code()})."
                    uiState = uiState.copy(isSaving = false, error = msg)
                }
            } catch (e: Exception) {
                uiState = uiState.copy(isSaving = false, error = e.message ?: "Terjadi kesalahan jaringan.")
            }
        }
    }

    fun clearSaveSuccess() {
        uiState = uiState.copy(saveSuccess = false)
    }
}
