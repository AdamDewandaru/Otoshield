package com.otoshield.app.ui.screens.payment

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewmodel.compose.viewModel
import com.otoshield.app.di.ServiceLocator

private val methodLabels = listOf(
    "VIRTUAL_ACCOUNT" to "Virtual Account",
    "E_WALLET" to "E-Wallet",
    "CASH" to "Tunai ke mekanik"
)

private fun statusLabel(status: String) = when (status) {
    "PENDING" -> "Menunggu pembayaran"
    "PAID" -> "Lunas"
    "FAILED" -> "Gagal / dibatalkan gateway"
    "CANCELLED" -> "Dibatalkan"
    else -> status
}

/**
 * Layar pembayaran digital (Bagian 5 blueprint, User Flow SOS langkah 6; item
 * "belum dikerjakan" #9 di otoshield_blueprint.md - ditulis sesi ini, belum ada sebelumnya).
 *
 * amountDefault biasanya diisi dari `estimated_cost_max` permintaan SOS yang sudah COMPLETED
 * (lihat SosTrackingScreen), tapi tetap bisa diedit pengguna sebelum membuat tagihan.
 */
@Composable
fun PaymentScreen(
    emergencyRequestId: String?,
    amountDefault: Int,
    onBack: () -> Unit
) {
    val viewModel: PaymentViewModel = viewModel(factory = object : ViewModelProvider.Factory {
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            @Suppress("UNCHECKED_CAST")
            return PaymentViewModel(ServiceLocator.paymentRepository) as T
        }
    })
    val state = viewModel.uiState
    val uriHandler = LocalUriHandler.current
    var amountText by remember { mutableStateOf(amountDefault.toString()) }
    var selectedMethod by remember { mutableStateOf("VIRTUAL_ACCOUNT") }

    Scaffold(topBar = { TopAppBar(title = { Text("Pembayaran") }) }) { padding ->
        Column(modifier = Modifier.padding(padding).fillMaxSize().padding(20.dp)) {

            if (state.payment == null) {
                // ---- Tahap 1: pilih metode & buat tagihan ----
                Text("Jumlah Tagihan", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = amountText,
                    onValueChange = { amountText = it.filter { c -> c.isDigit() } },
                    prefix = { Text("Rp") },
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(20.dp))
                Text("Metode Pembayaran", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(8.dp))
                methodLabels.forEach { (value, label) ->
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        RadioButton(selected = selectedMethod == value, onClick = { selectedMethod = value })
                        Text(label)
                    }
                }
                Spacer(Modifier.height(20.dp))
                Button(
                    onClick = {
                        val amount = amountText.toIntOrNull() ?: 0
                        viewModel.createPayment(emergencyRequestId, null, amount, selectedMethod)
                    },
                    enabled = !state.isCreating && (amountText.toIntOrNull() ?: 0) > 0,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    if (state.isCreating) {
                        CircularProgressIndicator(modifier = Modifier.size(20.dp))
                    } else {
                        Text("Buat Tagihan")
                    }
                }
            } else {
                // ---- Tahap 2: tagihan sudah dibuat, tunggu/konfirmasi pembayaran ----
                val payment = state.payment
                Card(modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp)) {
                        Text("Rp${payment.amount}", style = MaterialTheme.typography.headlineMedium)
                        Spacer(Modifier.height(4.dp))
                        Text(statusLabel(payment.status), style = MaterialTheme.typography.titleMedium)
                        Spacer(Modifier.height(4.dp))
                        Text("Metode: ${methodLabels.firstOrNull { it.first == payment.method }?.second ?: payment.method}")
                        if (state.gatewayMode == "simulated") {
                            Spacer(Modifier.height(8.dp))
                            Text(
                                "Mode simulasi - belum terhubung ke gateway Midtrans produksi.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.error
                            )
                        }
                    }
                }

                Spacer(Modifier.height(20.dp))

                if (payment.status == "PENDING" && payment.method != "CASH") {
                    // gatewayRedirectUrl bisa null (mis. mode "simulated" belum punya
                    // kredensial Midtrans - lihat paymentGateway.js). Tombol buka halaman
                    // gateway hanya muncul kalau memang ada URL untuk dibuka; tombol cek
                    // status tetap tersedia supaya pengguna bisa memantau webhook kapan saja.
                    if (state.gatewayRedirectUrl != null) {
                        Button(
                            onClick = { uriHandler.openUri(state.gatewayRedirectUrl) },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Buka Halaman Pembayaran")
                        }
                        Spacer(Modifier.height(12.dp))
                    } else {
                        Text(
                            "Menunggu konfirmasi otomatis dari gateway pembayaran.",
                            style = MaterialTheme.typography.bodySmall
                        )
                        Spacer(Modifier.height(12.dp))
                    }
                    OutlinedButton(
                        onClick = { viewModel.refreshStatus() },
                        enabled = !state.isRefreshing,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        if (state.isRefreshing) {
                            CircularProgressIndicator(modifier = Modifier.size(20.dp))
                        } else {
                            Text("Cek Status Terbaru")
                        }
                    }
                }

                if (payment.status == "PENDING" && payment.method == "CASH") {
                    Button(
                        onClick = { viewModel.confirmCash() },
                        enabled = !state.isConfirmingCash,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        if (state.isConfirmingCash) {
                            CircularProgressIndicator(modifier = Modifier.size(20.dp))
                        } else {
                            Text("Konfirmasi Sudah Bayar Tunai")
                        }
                    }
                }

                if (payment.status == "PAID") {
                    Spacer(Modifier.height(8.dp))
                    Text("Terima kasih, pembayaran sudah lunas.", color = MaterialTheme.colorScheme.primary)
                }
            }

            state.error?.let {
                Spacer(Modifier.height(12.dp))
                Text(it, color = MaterialTheme.colorScheme.error)
            }

            Spacer(Modifier.weight(1f))
            TextButton(onClick = onBack) { Text("Kembali") }
        }
    }
}
