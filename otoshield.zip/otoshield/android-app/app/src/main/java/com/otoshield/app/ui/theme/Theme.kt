package com.otoshield.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

private val OtoColorScheme = lightColorScheme(
    primary = OtoRed,
    onPrimary = OtoSurface,
    secondary = OtoBlue,
    background = OtoBackground,
    surface = OtoSurface,
    onBackground = OtoTextPrimary,
    onSurface = OtoTextPrimary,
    error = OtoRedDark,
)

@Composable
fun OtoShieldTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = OtoColorScheme,
        typography = OtoTypography,
        content = content
    )
}
