package com.otoshield.app.ui.screens.servicebook

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewmodel.compose.viewModel
import com.otoshield.app.data.local.entity.VehicleEntity
import com.otoshield.app.di.ServiceLocator
import com.otoshield.app.ui.theme.OtoRed

@Composable
fun ServiceBookScreen(onBack: () -> Unit) {
    val viewModel: ServiceBookViewModel = viewModel(factory = object : ViewModelProvider.Factory {
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            @Suppress("UNCHECKED_CAST")
            return ServiceBookViewModel(ServiceLocator.vehicleRepository) as T
        }
    })
    val vehicles by viewModel.vehicles.collectAsState()
    val state = viewModel.uiState
    var showAddDialog by remember { mutableStateOf(false) }
    var vehicleBeingEdited by remember { mutableStateOf<VehicleEntity?>(null) }
    var vehiclePendingDelete by remember { mutableStateOf<VehicleEntity?>(null) }

    Scaffold(
        topBar = { TopAppBar(title = { Text("Buku Servis Digital") }) },
        floatingActionButton = {
            FloatingActionButton(onClick = { showAddDialog = true }) {
                Icon(Icons.Default.Add, contentDescription = "Tambah Kendaraan")
            }
        }
    ) { padding ->
        Column(modifier = Modifier.padding(padding).fillMaxSize()) {
            if (state.isSyncing) LinearProgressIndicator(modifier = Modifier.fillMaxWidth())

            if (vehicles.isEmpty() && !state.isSyncing) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("Belum ada kendaraan. Tambahkan lewat tombol + di kanan bawah.")
                }
            } else {
                LazyColumn {
                    items(vehicles) { vehicle ->
                        VehicleRow(
                            vehicle = vehicle,
                            reminders = if (state.selectedVehicleId == vehicle.id) state.reminders else emptyList(),
                            onClick = { viewModel.loadReminders(vehicle.id) },
                            onEditClick = { vehicleBeingEdited = vehicle },
                            onDeleteClick = { vehiclePendingDelete = vehicle }
                        )
                        Divider()
                    }
                }
            }
        }
    }

    if (showAddDialog) {
        AddVehicleDialog(
            onDismiss = { showAddDialog = false },
            onConfirm = { brand, model, year, plate, km ->
                viewModel.addVehicle(brand, model, year, plate, km)
                showAddDialog = false
            }
        )
    }

    // Edit kendaraan (item "belum dikerjakan" #8 di otoshield_blueprint.md - Sesi 3)
    vehicleBeingEdited?.let { vehicle ->
        EditVehicleDialog(
            vehicle = vehicle,
            onDismiss = { vehicleBeingEdited = null },
            onConfirm = { brand, model, year, plate ->
                viewModel.updateVehicle(vehicle.id, brand, model, year, plate)
                vehicleBeingEdited = null
            }
        )
    }

    // Hapus kendaraan dengan konfirmasi (item "belum dikerjakan" #8 - Sesi 3)
    vehiclePendingDelete?.let { vehicle ->
        AlertDialog(
            onDismissRequest = { vehiclePendingDelete = null },
            title = { Text("Hapus Kendaraan?") },
            text = {
                Text("Kendaraan \"${vehicle.brand} ${vehicle.model}\" beserta riwayat servisnya akan dihapus. Tindakan ini tidak bisa dibatalkan.")
            },
            confirmButton = {
                TextButton(onClick = {
                    viewModel.deleteVehicle(vehicle.id)
                    vehiclePendingDelete = null
                }) { Text("Hapus", color = OtoRed) }
            },
            dismissButton = { TextButton(onClick = { vehiclePendingDelete = null }) { Text("Batal") } }
        )
    }
}

@Composable
private fun VehicleRow(
    vehicle: VehicleEntity,
    reminders: List<com.otoshield.app.data.remote.dto.ReminderDto>,
    onClick: () -> Unit,
    onEditClick: () -> Unit,
    onDeleteClick: () -> Unit
) {
    var menuExpanded by remember { mutableStateOf(false) }

    Row(Modifier.fillMaxWidth().clickable(onClick = onClick), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f).padding(16.dp)) {
            Text("${vehicle.brand} ${vehicle.model} ${vehicle.year ?: ""}", style = MaterialTheme.typography.titleMedium)
            vehicle.licensePlate?.let { Text(it, style = MaterialTheme.typography.bodyMedium) }
            Text("Odometer: ${vehicle.currentKilometer} km", style = MaterialTheme.typography.bodyMedium)

            reminders.forEach { reminder ->
                Spacer(Modifier.height(6.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (reminder.urgent) {
                        Icon(Icons.Default.Warning, contentDescription = null, tint = OtoRed, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(4.dp))
                    }
                    Text(
                        "${reminder.type}: ${reminder.message}",
                        color = if (reminder.urgent) OtoRed else MaterialTheme.colorScheme.onSurface,
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
            }
        }

        Box {
            IconButton(onClick = { menuExpanded = true }) {
                Icon(Icons.Default.MoreVert, contentDescription = "Kelola Kendaraan")
            }
            DropdownMenu(expanded = menuExpanded, onDismissRequest = { menuExpanded = false }) {
                DropdownMenuItem(
                    text = { Text("Edit") },
                    leadingIcon = { Icon(Icons.Default.Edit, contentDescription = null) },
                    onClick = {
                        menuExpanded = false
                        onEditClick()
                    }
                )
                DropdownMenuItem(
                    text = { Text("Hapus") },
                    leadingIcon = { Icon(Icons.Default.Delete, contentDescription = null, tint = OtoRed) },
                    onClick = {
                        menuExpanded = false
                        onDeleteClick()
                    }
                )
            }
        }
    }
}

@Composable
private fun AddVehicleDialog(
    onDismiss: () -> Unit,
    onConfirm: (brand: String, model: String, year: Int?, plate: String?, km: Int) -> Unit
) {
    var brand by remember { mutableStateOf("") }
    var model by remember { mutableStateOf("") }
    var year by remember { mutableStateOf("") }
    var plate by remember { mutableStateOf("") }
    var km by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Tambah Kendaraan") },
        text = {
            Column {
                OutlinedTextField(value = brand, onValueChange = { brand = it }, label = { Text("Merek (contoh: Toyota)") })
                OutlinedTextField(value = model, onValueChange = { model = it }, label = { Text("Model (contoh: Avanza)") })
                OutlinedTextField(value = year, onValueChange = { year = it }, label = { Text("Tahun") })
                OutlinedTextField(value = plate, onValueChange = { plate = it }, label = { Text("Plat Nomor") })
                OutlinedTextField(value = km, onValueChange = { km = it }, label = { Text("Kilometer saat ini") })
            }
        },
        confirmButton = {
            TextButton(onClick = {
                onConfirm(brand, model, year.toIntOrNull(), plate.ifBlank { null }, km.toIntOrNull() ?: 0)
            }) { Text("Simpan") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Batal") } }
    )
}

// Dialog edit kendaraan (item "belum dikerjakan" #8 - Sesi 3). Berbeda dari
// AddVehicleDialog, form ini di-prefill dari data kendaraan yang sudah ada dan
// tidak mengubah odometer (odometer punya alur update tersendiri di reminders).
@Composable
private fun EditVehicleDialog(
    vehicle: VehicleEntity,
    onDismiss: () -> Unit,
    onConfirm: (brand: String, model: String, year: Int?, plate: String?) -> Unit
) {
    var brand by remember { mutableStateOf(vehicle.brand) }
    var model by remember { mutableStateOf(vehicle.model) }
    var year by remember { mutableStateOf(vehicle.year?.toString() ?: "") }
    var plate by remember { mutableStateOf(vehicle.licensePlate ?: "") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Edit Kendaraan") },
        text = {
            Column {
                OutlinedTextField(value = brand, onValueChange = { brand = it }, label = { Text("Merek") })
                OutlinedTextField(value = model, onValueChange = { model = it }, label = { Text("Model") })
                OutlinedTextField(value = year, onValueChange = { year = it }, label = { Text("Tahun") })
                OutlinedTextField(value = plate, onValueChange = { plate = it }, label = { Text("Plat Nomor") })
            }
        },
        confirmButton = {
            TextButton(onClick = {
                onConfirm(brand, model, year.toIntOrNull(), plate.ifBlank { null })
            }) { Text("Simpan") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Batal") } }
    )
}
