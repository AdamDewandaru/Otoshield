package com.otoshield.app.ui.screens.estimator

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.otoshield.app.data.remote.dto.EstimateResponse
import com.otoshield.app.data.repository.EstimatorRepository
import kotlinx.coroutines.launch

data class EstimatorUiState(
    val isLoading: Boolean = false,
    val result: EstimateResponse? = null,
    val error: String? = null
)

class EstimatorViewModel(private val repository: EstimatorRepository) : ViewModel() {
    var uiState by mutableStateOf(EstimatorUiState())
        private set

    fun estimate(symptomText: String) {
        if (symptomText.isBlank()) return
        viewModelScope.launch {
            uiState = uiState.copy(isLoading = true, error = null, result = null)
            val result = repository.estimate(symptomText)
            result.fold(
                onSuccess = { res -> uiState = uiState.copy(isLoading = false, result = res) },
                onFailure = { e -> uiState = uiState.copy(isLoading = false, error = e.message) }
            )
        }
    }
}
