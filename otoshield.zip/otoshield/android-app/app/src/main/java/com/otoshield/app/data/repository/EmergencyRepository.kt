package com.otoshield.app.data.repository

import com.otoshield.app.data.remote.ApiService
import com.otoshield.app.data.remote.dto.CreateEmergencyRequest
import com.otoshield.app.data.remote.dto.CreateEmergencyResponse
import com.otoshield.app.data.remote.dto.EmergencyRequestDto
import com.otoshield.app.util.SessionManager
import okhttp3.MultipartBody

class EmergencyRepository(private val api: ApiService, private val session: SessionManager) {

    suspend fun createSos(lat: Double, lng: Double, issueDescription: String?): Result<CreateEmergencyResponse> = try {
        val response = api.createEmergency(session.getBearerToken(), CreateEmergencyRequest(lat, lng, issueDescription))
        if (response.isSuccessful && response.body() != null) {
            Result.success(response.body()!!)
        } else {
            Result.failure(Exception("Gagal mengirim permintaan SOS (${response.code()})"))
        }
    } catch (e: Exception) {
        Result.failure(e)
    }

    /**
     * Polling status SOS. Untuk update posisi mekanik yang lebih realtime,
     * hubungkan Socket.IO client ke event "emergency:mechanic_location"
     * (lihat backend/src/sockets/emergency.socket.js) sebagai peningkatan berikutnya.
     */
    suspend fun getStatus(emergencyId: String): Result<EmergencyRequestDto> = try {
        val response = api.getEmergency(session.getBearerToken(), emergencyId)
        if (response.isSuccessful && response.body() != null) {
            Result.success(response.body()!!)
        } else {
            Result.failure(Exception("Gagal memuat status SOS (${response.code()})"))
        }
    } catch (e: Exception) {
        Result.failure(e)
    }

    /**
     * Upload foto kerusakan (item "belum dikerjakan" #10). Backend menolak dengan 400 kalau
     * tipe file bukan JPEG/PNG/WEBP atau ukuran > 5MB (lihat upload.middleware.js) - pesan
     * error dari body response sudah cukup jelas untuk ditampilkan apa adanya ke pengguna.
     */
    suspend fun uploadPhoto(emergencyId: String, photoPart: MultipartBody.Part): Result<EmergencyRequestDto> = try {
        val response = api.uploadEmergencyPhoto(session.getBearerToken(), emergencyId, photoPart)
        if (response.isSuccessful && response.body() != null) {
            Result.success(response.body()!!)
        } else {
            Result.failure(Exception("Gagal mengunggah foto (${response.code()})"))
        }
    } catch (e: Exception) {
        Result.failure(e)
    }
}
