package com.otoshield.app.ui.screens.auth

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.otoshield.app.data.remote.ApiService
import com.otoshield.app.data.remote.dto.LoginRequest
import com.otoshield.app.data.remote.dto.RegisterRequest
import com.otoshield.app.util.SessionManager
import kotlinx.coroutines.launch

data class AuthUiState(
    val isLoading: Boolean = false,
    val error: String? = null,
    val isLoggedIn: Boolean = false
)

/**
 * ViewModel untuk alur Login & Register.
 * Setelah sukses, token JWT disimpan di SessionManager agar dipakai
 * otomatis oleh fitur lain (SOS, riwayat servis, review) lewat Authorization header.
 */
class AuthViewModel(
    private val api: ApiService,
    private val session: SessionManager
) : ViewModel() {

    var uiState by mutableStateOf(AuthUiState(isLoggedIn = session.isLoggedIn()))
        private set

    fun login(phone: String, password: String) {
        if (phone.isBlank() || password.isBlank()) {
            uiState = uiState.copy(error = "Nomor telepon dan password wajib diisi.")
            return
        }
        viewModelScope.launch {
            uiState = uiState.copy(isLoading = true, error = null)
            try {
                val response = api.login(LoginRequest(phone, password))
                if (response.isSuccessful && response.body() != null) {
                    val body = response.body()!!
                    session.saveToken(body.token)
                    session.saveUser(body.user.id, body.user.name)
                    uiState = uiState.copy(isLoading = false, isLoggedIn = true)
                } else {
                    val msg = if (response.code() == 401) "Nomor telepon atau password salah."
                              else "Gagal login (${response.code()})."
                    uiState = uiState.copy(isLoading = false, error = msg)
                }
            } catch (e: Exception) {
                uiState = uiState.copy(isLoading = false, error = e.message ?: "Terjadi kesalahan jaringan.")
            }
        }
    }

    fun register(name: String, phone: String, email: String?, password: String) {
        if (name.isBlank() || phone.isBlank() || password.isBlank()) {
            uiState = uiState.copy(error = "Nama, nomor telepon, dan password wajib diisi.")
            return
        }
        if (password.length < 6) {
            uiState = uiState.copy(error = "Password minimal 6 karakter.")
            return
        }
        viewModelScope.launch {
            uiState = uiState.copy(isLoading = true, error = null)
            try {
                val response = api.register(RegisterRequest(name, phone, email?.ifBlank { null }, password))
                if (response.isSuccessful && response.body() != null) {
                    val body = response.body()!!
                    session.saveToken(body.token)
                    session.saveUser(body.user.id, body.user.name)
                    uiState = uiState.copy(isLoading = false, isLoggedIn = true)
                } else {
                    val msg = if (response.code() == 409) "Nomor telepon sudah terdaftar."
                              else "Gagal mendaftar (${response.code()})."
                    uiState = uiState.copy(isLoading = false, error = msg)
                }
            } catch (e: Exception) {
                uiState = uiState.copy(isLoading = false, error = e.message ?: "Terjadi kesalahan jaringan.")
            }
        }
    }

    fun logout() {
        session.clear()
        uiState = uiState.copy(isLoggedIn = false)
    }
}
