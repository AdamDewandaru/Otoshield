package com.otoshield.app.util

import android.util.Log
import com.otoshield.app.BuildConfig
import io.socket.client.IO
import io.socket.client.Socket
import org.json.JSONObject

/**
 * Pembungkus Socket.IO client untuk fitur realtime SOS.
 * Menggantikan polling di SosTrackingViewModel dengan event dari server:
 * - "emergency:updated" -> perubahan status (ACCEPTED/ON_THE_WAY/COMPLETED/dll)
 * - "emergency:mechanic_location" -> update posisi GPS mekanik saat menuju lokasi
 *
 * Server side: lihat backend/src/sockets/emergency.socket.js
 */
class SocketManager {
    private var socket: Socket? = null

    fun connectAndJoin(emergencyId: String) {
        try {
            // Base URL socket sama dengan base host backend (tanpa path /api/)
            val socketUrl = BuildConfig.BASE_API_URL.removeSuffix("api/")
            socket = IO.socket(socketUrl)
            socket?.connect()
            socket?.emit("emergency:join", emergencyId)
        } catch (e: Exception) {
            Log.e("SocketManager", "Gagal konek socket: ${e.message}")
        }
    }

    fun onEmergencyUpdated(callback: (JSONObject) -> Unit) {
        socket?.on("emergency:updated") { args ->
            if (args.isNotEmpty() && args[0] is JSONObject) {
                callback(args[0] as JSONObject)
            }
        }
    }

    fun onMechanicLocationUpdated(callback: (lat: Double, lng: Double) -> Unit) {
        socket?.on("emergency:mechanic_location") { args ->
            if (args.isNotEmpty() && args[0] is JSONObject) {
                val obj = args[0] as JSONObject
                callback(obj.optDouble("latitude"), obj.optDouble("longitude"))
            }
        }
    }

    fun disconnect() {
        socket?.disconnect()
        socket?.off()
        socket = null
    }
}
