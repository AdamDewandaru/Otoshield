package com.otoshield.app.data.repository

import com.otoshield.app.data.remote.ApiService
import com.otoshield.app.data.remote.dto.CreatePaymentRequest
import com.otoshield.app.data.remote.dto.CreatePaymentResponse
import com.otoshield.app.data.remote.dto.PaymentDto
import com.otoshield.app.util.SessionManager

/**
 * Repository untuk fitur pembayaran digital (item "belum dikerjakan" #9, ditulis di sesi ini).
 * Mengikuti pola gateway Midtrans-style dari backend Sesi 4 - lihat catatan di PaymentDto.kt.
 */
class PaymentRepository(
    private val api: ApiService,
    private val session: SessionManager
) {
    suspend fun createPayment(
        emergencyRequestId: String?,
        workshopId: String?,
        amount: Int,
        method: String
    ): Result<CreatePaymentResponse> = try {
        val response = api.createPayment(
            session.getBearerToken(),
            CreatePaymentRequest(
                emergency_request_id = emergencyRequestId,
                workshop_id = workshopId,
                amount = amount,
                method = method
            )
        )
        if (response.isSuccessful && response.body() != null) {
            Result.success(response.body()!!)
        } else {
            Result.failure(Exception("Gagal membuat tagihan pembayaran (${response.code()})"))
        }
    } catch (e: Exception) {
        Result.failure(e)
    }

    /** Poll status terbaru - dipakai setelah pengguna kembali dari halaman pembayaran gateway. */
    suspend fun getPayment(paymentId: String): Result<PaymentDto> = try {
        val response = api.getPayment(session.getBearerToken(), paymentId)
        if (response.isSuccessful && response.body() != null) {
            Result.success(response.body()!!)
        } else {
            Result.failure(Exception("Gagal memuat status pembayaran (${response.code()})"))
        }
    } catch (e: Exception) {
        Result.failure(e)
    }

    suspend fun listPayments(): Result<List<PaymentDto>> = try {
        val response = api.listPayments(session.getBearerToken())
        if (response.isSuccessful && response.body() != null) {
            Result.success(response.body()!!)
        } else {
            Result.failure(Exception("Gagal memuat riwayat pembayaran (${response.code()})"))
        }
    } catch (e: Exception) {
        Result.failure(e)
    }

    /**
     * Konfirmasi manual KHUSUS method CASH. Untuk VIRTUAL_ACCOUNT/E_WALLET backend akan
     * menolak dengan 403 (status hanya berubah lewat webhook gateway) - jangan panggil ini
     * untuk method tersebut, arahkan pengguna ke gateway_redirect_url dan lakukan polling.
     */
    suspend fun confirmCashPayment(paymentId: String): Result<PaymentDto> = try {
        val response = api.confirmCashPayment(session.getBearerToken(), paymentId)
        if (response.isSuccessful && response.body() != null) {
            Result.success(response.body()!!)
        } else {
            val msg = if (response.code() == 403)
                "Pembayaran non-tunai hanya bisa dikonfirmasi lewat gateway, bukan tombol ini."
            else "Gagal mengkonfirmasi pembayaran tunai (${response.code()})"
            Result.failure(Exception(msg))
        }
    } catch (e: Exception) {
        Result.failure(e)
    }
}
